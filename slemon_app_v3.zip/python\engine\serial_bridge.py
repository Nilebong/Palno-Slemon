"""
serial_bridge.py — Async Serial Reader for STM32 → Qualcomm Bridge
Palno & Slemon Sleep Tracking System

Reads the CSV-framed data stream from the STM32 co-processor over the
internal UART bridge and dispatches parsed frames to registered callbacks.

Frame formats (from slemon_stm32.ino):
  Radar: "R,<ts>,<state>,<mov_cm>,<mov_e>,<sta_cm>,<sta_e>,<det_cm>,
           <mg0>..<mg8>,<sg0>..<sg5>"
  Temp:  "T,<ts>,<tempC>"
  Event: "E,<ts>,<eventType>,<detail>"

Usage:
    bridge = SerialBridge(on_radar=cb_radar, on_temp=cb_temp, on_event=cb_event)
    asyncio.create_task(bridge.run())
"""

import asyncio
import logging
import time
from typing import Callable, Optional

import serial_asyncio                          # pip install pyserial-asyncio

from engine.config import STM32_SERIAL_PORT, STM32_SERIAL_BAUD

logger = logging.getLogger(__name__)


def _parse_radar_frame(parts: list[str]) -> Optional[dict]:
    """
    Parse a radar CSV frame into a dict.
    parts[0] = 'R', parts[1] = ts, parts[2..] = fields.
    Returns None on parse error.
    """
    try:
        # Minimum 9 fields: R ts state mov_cm mov_e sta_cm sta_e det_cm + at least 1 gate
        if len(parts) < 9:
            return None

        d = {
            "ts":          time.time(),           # local receive timestamp
            "stm32_ts":    int(parts[1]),          # STM32 millis()
            "target_state": int(parts[2]),
            "mov_dist_cm":  float(parts[3]),
            "mov_energy":   float(parts[4]),
            "sta_dist_cm":  float(parts[5]),
            "sta_energy":   float(parts[6]),
            "det_dist_cm":  float(parts[7]),
        }

        # Moving gate energies MG0–MG8 (9 values)
        mg = []
        for i in range(9):
            idx = 8 + i
            mg.append(float(parts[idx]) if idx < len(parts) else 0.0)
        d["mg"] = mg

        # Static gate energies SG3–SG8 (6 values)
        sg = []
        for i in range(6):
            idx = 17 + i
            sg.append(float(parts[idx]) if idx < len(parts) else 0.0)
        d["sg"] = sg

        return d

    except (ValueError, IndexError) as e:
        logger.debug("Radar parse error: %s | parts: %s", e, parts)
        return None


def _parse_temp_frame(parts: list[str]) -> Optional[dict]:
    """Parse a temperature CSV frame."""
    try:
        if len(parts) < 3:
            return None
        return {
            "ts":       time.time(),
            "stm32_ts": int(parts[1]),
            "temp_c":   float(parts[2]),
        }
    except (ValueError, IndexError) as e:
        logger.debug("Temp parse error: %s", e)
        return None


def _parse_event_frame(parts: list[str]) -> Optional[dict]:
    """Parse an event CSV frame."""
    try:
        if len(parts) < 3:
            return None
        return {
            "ts":         time.time(),
            "stm32_ts":   int(parts[1]),
            "event_type": parts[2].strip(),
            "detail":     parts[3].strip() if len(parts) > 3 else "",
        }
    except (ValueError, IndexError) as e:
        logger.debug("Event parse error: %s", e)
        return None


class SerialBridge:
    """
    Async serial reader for the STM32 → Qualcomm internal UART bridge.

    Registered callbacks are called synchronously from the asyncio loop
    for each successfully parsed frame.
    """

    def __init__(
        self,
        on_radar: Optional[Callable[[dict], None]] = None,
        on_temp:  Optional[Callable[[dict], None]] = None,
        on_event: Optional[Callable[[dict], None]] = None,
        port:     str = STM32_SERIAL_PORT,
        baud:     int = STM32_SERIAL_BAUD,
    ):
        self._on_radar  = on_radar
        self._on_temp   = on_temp
        self._on_event  = on_event
        self._port      = port
        self._baud      = baud
        self._running   = False

        # Latest cached values (thread-safe for single asyncio thread)
        self.last_radar: Optional[dict] = None
        self.last_temp:  Optional[dict] = None

        # Write queue for commands back to STM32 (e.g. display updates)
        self._write_queue: asyncio.Queue = asyncio.Queue()
        self._writer: Optional[asyncio.StreamWriter] = None

        # Stats
        self.frames_received = 0
        self.parse_errors    = 0

    def _dispatch(self, line: str):
        """Parse one CSV line and call the appropriate callback."""
        line = line.strip()
        if not line:
            return

        parts = line.split(",")
        frame_type = parts[0] if parts else ""

        if frame_type == "R":
            frame = _parse_radar_frame(parts)
            if frame:
                self.last_radar = frame
                self.frames_received += 1
                if self._on_radar:
                    self._on_radar(frame)
            else:
                self.parse_errors += 1

        elif frame_type == "T":
            frame = _parse_temp_frame(parts)
            if frame:
                self.last_temp = frame
                if self._on_temp:
                    self._on_temp(frame)

        elif frame_type == "E":
            frame = _parse_event_frame(parts)
            if frame:
                logger.info("[BRIDGE] Event from STM32: %s | %s",
                            frame["event_type"], frame["detail"])
                if self._on_event:
                    self._on_event(frame)
        else:
            logger.debug("[BRIDGE] Unknown frame type '%s': %s", frame_type, line)

    async def send_command(self, cmd: str):
        """
        Queue a command string to send to the STM32.
        e.g. "CMD,DISPLAY,SLEEP,14.2,68,98,21.4,N2,02:47"
        The string must NOT contain a newline — it is appended here.
        """
        await self._write_queue.put(cmd + "\n")

    async def _writer_loop(self):
        """Drain the write queue and send commands to STM32."""
        while self._running:
            try:
                cmd = await asyncio.wait_for(self._write_queue.get(), timeout=1.0)
                if self._writer:
                    self._writer.write(cmd.encode("utf-8"))
                    await self._writer.drain()
                    logger.debug("[BRIDGE] → STM32: %s", cmd.strip())
            except asyncio.TimeoutError:
                pass
            except Exception as e:
                logger.error("[BRIDGE] Write error: %s", e)

    async def run(self):
        """
        Main coroutine. Opens the serial port and reads lines continuously.
        Reconnects automatically if the port disappears.
        """
        self._running = True
        reconnect_delay = 5.0

        while self._running:
            try:
                logger.info("[BRIDGE] Opening serial port %s @ %d baud",
                            self._port, self._baud)

                reader, writer = await serial_asyncio.open_serial_connection(
                    url=self._port, baudrate=self._baud
                )
                self._writer = writer
                reconnect_delay = 5.0   # reset on success

                # Launch writer loop as concurrent task
                writer_task = asyncio.create_task(self._writer_loop())

                logger.info("[BRIDGE] Serial port open — reading frames")

                while self._running:
                    try:
                        raw = await asyncio.wait_for(reader.readline(), timeout=2.0)
                        line = raw.decode("utf-8", errors="replace")
                        self._dispatch(line)
                    except asyncio.TimeoutError:
                        # No data for 2s — normal if STM32 is quiet; continue
                        pass

                writer_task.cancel()

            except Exception as e:
                logger.error("[BRIDGE] Serial error: %s — retrying in %.0fs",
                             e, reconnect_delay)
                await asyncio.sleep(reconnect_delay)
                reconnect_delay = min(reconnect_delay * 2, 60.0)
            finally:
                self._writer = None

    async def stop(self):
        """Stop the bridge."""
        self._running = False
        logger.info("[BRIDGE] Stopped")
