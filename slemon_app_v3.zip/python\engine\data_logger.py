"""
data_logger.py — SQLite Database Writer + CSV Exporter
Palno & Slemon Sleep Tracking System

Creates and manages the sleep_log.db SQLite database with 6 tables:
  sensor_raw    — high-freq radar + MPU data (20 Hz, batched)
  biometrics    — HR + SpO2 from BLE (1 Hz)
  environment   — room temperature (every 10 s)
  breath_events — individual breath detections (event-driven)
  sleep_epochs  — 30-second classified sleep epochs
  events        — session markers, alarm events

Features:
  - WAL mode for crash-safe writes
  - Batch inserts (flush every DB_BATCH_INSERT_S)
  - Daily CSV export
  - Async-compatible (runs in executor for blocking DB calls)
"""

import asyncio
import csv
import logging
import os
import sqlite3
import time
from datetime import datetime, date
from typing import Optional

from engine.config import DB_PATH, EXPORTS_DIR, DB_BATCH_INSERT_S, DB_WAL_MODE

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════
# SCHEMA
# ═══════════════════════════════════════════════════════════════════════════════

SCHEMA_SQL = """
PRAGMA journal_mode=WAL;
PRAGMA auto_vacuum=INCREMENTAL;

CREATE TABLE IF NOT EXISTS sensor_raw (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ts          REAL    NOT NULL,
    source      TEXT    NOT NULL,
    target_state INTEGER,
    mov_dist_cm REAL,
    mov_energy  REAL,
    sta_dist_cm REAL,
    sta_energy  REAL,
    det_dist_cm REAL,
    mg0 REAL, mg1 REAL, mg2 REAL, mg3 REAL, mg4 REAL,
    mg5 REAL, mg6 REAL, mg7 REAL, mg8 REAL,
    sg0 REAL, sg1 REAL, sg2 REAL, sg3 REAL, sg4 REAL, sg5 REAL,
    accel_x REAL, accel_y REAL, accel_z REAL,
    gyro_x  REAL, gyro_y  REAL, gyro_z  REAL
);

CREATE TABLE IF NOT EXISTS biometrics (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    ts         REAL    NOT NULL,
    heart_rate INTEGER,
    hr_valid   INTEGER,
    spo2       INTEGER,
    spo2_valid INTEGER
);

CREATE TABLE IF NOT EXISTS environment (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    ts           REAL NOT NULL,
    room_temp_c  REAL
);

CREATE TABLE IF NOT EXISTS breath_events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ts          REAL NOT NULL,
    breath_num  INTEGER,
    intensity   REAL,
    gap_samples INTEGER,
    bpm         REAL
);

CREATE TABLE IF NOT EXISTS sleep_epochs (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    epoch_start  REAL NOT NULL,
    epoch_end    REAL NOT NULL,
    stage        TEXT,
    avg_resp_bpm REAL,
    resp_cov     REAL,
    avg_hr       REAL,
    hr_cov       REAL,
    avg_spo2     REAL,
    disturbance  REAL,
    mpu_motion   REAL,
    room_temp    REAL
);

CREATE TABLE IF NOT EXISTS events (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    ts         REAL NOT NULL,
    event_type TEXT,
    details    TEXT
);

CREATE INDEX IF NOT EXISTS idx_sensor_raw_ts    ON sensor_raw(ts);
CREATE INDEX IF NOT EXISTS idx_biometrics_ts    ON biometrics(ts);
CREATE INDEX IF NOT EXISTS idx_environment_ts   ON environment(ts);
CREATE INDEX IF NOT EXISTS idx_breath_events_ts ON breath_events(ts);
CREATE INDEX IF NOT EXISTS idx_sleep_epochs_ts  ON sleep_epochs(epoch_start);
CREATE INDEX IF NOT EXISTS idx_events_ts        ON events(ts);
"""


# ═══════════════════════════════════════════════════════════════════════════════
# DATA LOGGER
# ═══════════════════════════════════════════════════════════════════════════════

class DataLogger:
    """
    Thread-safe (asyncio-friendly) SQLite logger with batch inserts.

    Rows are queued in memory and flushed to disk every DB_BATCH_INSERT_S.
    """

    def __init__(self, db_path: str = DB_PATH):
        self._db_path = db_path
        self._conn:   Optional[sqlite3.Connection] = None
        self._running = False

        # In-memory batch queues
        self._q_sensor_raw:    list = []
        self._q_biometrics:    list = []
        self._q_environment:   list = []
        self._q_breath_events: list = []
        self._q_sleep_epochs:  list = []
        self._q_events:        list = []

        self.rows_written = 0

    # ─── Init ────────────────────────────────────────────────────────────────

    def _open_db(self):
        os.makedirs(os.path.dirname(self._db_path), exist_ok=True)
        self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
        self._conn.executescript(SCHEMA_SQL)
        self._conn.commit()
        logger.info("[DB] Opened: %s", self._db_path)

    # ─── Public enqueue methods (called from main asyncio loop) ───────────────

    def log_radar(self, d: dict):
        """Queue one radar frame for batch insert."""
        mg = d.get("mg", [0] * 9)
        sg = d.get("sg", [0] * 6)
        self._q_sensor_raw.append((
            d.get("ts", time.time()), "RADAR",
            d.get("target_state", 0),
            d.get("mov_dist_cm",  0.0),
            d.get("mov_energy",   0.0),
            d.get("sta_dist_cm",  0.0),
            d.get("sta_energy",   0.0),
            d.get("det_dist_cm",  0.0),
            *(mg + [0.0] * (9 - len(mg))),
            *(sg + [0.0] * (6 - len(sg))),
            None, None, None,    # accel
            None, None, None,    # gyro
        ))

    def log_motion(self, d: dict):
        """Queue one MPU6050 motion frame for batch insert."""
        self._q_sensor_raw.append((
            d.get("ts", time.time()), "MPU6050",
            None, None, None, None, None, None,
            *([None] * 9),    # mg
            *([None] * 6),    # sg
            d.get("ax", 0.0), d.get("ay", 0.0), d.get("az", 0.0),
            d.get("gx", 0.0), d.get("gy", 0.0), d.get("gz", 0.0),
        ))

    def log_biometrics(self, d: dict):
        """Queue one biometrics reading."""
        self._q_biometrics.append((
            d.get("ts", time.time()),
            d.get("hr",        -999),
            int(d.get("hr_valid",   False)),
            d.get("spo2",      -999),
            int(d.get("spo2_valid", False)),
        ))

    def log_temperature(self, d: dict):
        """Queue one temperature reading."""
        self._q_environment.append((
            d.get("ts", time.time()),
            d.get("temp_c", None),
        ))

    def log_breath_event(self, ts: float, breath_num: int,
                          intensity: float, gap_samples: int, bpm: float):
        """Queue one breath detection event."""
        self._q_breath_events.append((ts, breath_num, intensity, gap_samples, bpm))

    def log_sleep_epoch(self, epoch: dict):
        """Queue one classified 30-second epoch."""
        self._q_sleep_epochs.append((
            epoch.get("epoch_start",  0.0),
            epoch.get("epoch_end",    0.0),
            epoch.get("stage",        "UNKNOWN"),
            epoch.get("avg_resp_bpm", None),
            epoch.get("resp_cov",     None),
            epoch.get("avg_hr",       None),
            epoch.get("hr_cov",       None),
            epoch.get("avg_spo2",     None),
            epoch.get("disturbance",  None),
            epoch.get("mpu_motion",   None),
            epoch.get("room_temp",    None),
        ))

    def log_event(self, event_type: str, details: str = ""):
        """Queue a system event (session start/end, alarm, etc.)."""
        import json as _json
        self._q_events.append((time.time(), event_type, details))
        logger.info("[DB] Event: %s | %s", event_type, details)

    # ─── Flush ───────────────────────────────────────────────────────────────

    def _flush(self):
        """Write all queued rows to SQLite. Called from asyncio executor."""
        if not self._conn:
            return

        cur = self._conn.cursor()
        n = 0

        if self._q_sensor_raw:
            cur.executemany(
                "INSERT INTO sensor_raw VALUES (NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                self._q_sensor_raw,
            )
            n += len(self._q_sensor_raw)
            self._q_sensor_raw.clear()

        if self._q_biometrics:
            cur.executemany(
                "INSERT INTO biometrics VALUES (NULL,?,?,?,?,?)",
                self._q_biometrics,
            )
            n += len(self._q_biometrics)
            self._q_biometrics.clear()

        if self._q_environment:
            cur.executemany(
                "INSERT INTO environment VALUES (NULL,?,?)",
                self._q_environment,
            )
            n += len(self._q_environment)
            self._q_environment.clear()

        if self._q_breath_events:
            cur.executemany(
                "INSERT INTO breath_events VALUES (NULL,?,?,?,?,?)",
                self._q_breath_events,
            )
            n += len(self._q_breath_events)
            self._q_breath_events.clear()

        if self._q_sleep_epochs:
            cur.executemany(
                "INSERT INTO sleep_epochs VALUES (NULL,?,?,?,?,?,?,?,?,?,?,?)",
                self._q_sleep_epochs,
            )
            n += len(self._q_sleep_epochs)
            self._q_sleep_epochs.clear()

        if self._q_events:
            cur.executemany(
                "INSERT INTO events VALUES (NULL,?,?,?)",
                self._q_events,
            )
            n += len(self._q_events)
            self._q_events.clear()

        if n > 0:
            self._conn.commit()
            self.rows_written += n
            logger.debug("[DB] Flushed %d rows (total: %d)", n, self.rows_written)

    # ─── Async run loop ───────────────────────────────────────────────────────

    async def run(self):
        """
        Periodic flush coroutine. Opens DB once, then flushes every
        DB_BATCH_INSERT_S seconds. Run as asyncio.create_task(logger.run()).
        """
        self._running = True
        loop = asyncio.get_event_loop()
        loop.run_in_executor(None, self._open_db)
        await asyncio.sleep(0.5)   # let open_db finish

        while self._running:
            await asyncio.sleep(DB_BATCH_INSERT_S)
            try:
                await loop.run_in_executor(None, self._flush)
            except Exception as e:
                logger.error("[DB] Flush error: %s", e)

    async def stop(self):
        """Final flush and close."""
        self._running = False
        try:
            self._flush()
        except Exception:
            pass
        if self._conn:
            self._conn.close()
        logger.info("[DB] Closed")

    # ─── CSV Export ───────────────────────────────────────────────────────────

    def export_csv(self, date_str: Optional[str] = None) -> str:
        """
        Export sleep_epochs for a given date (YYYY-MM-DD) to a CSV file.
        If date_str is None, exports today.
        Returns the path to the CSV file.
        """
        if date_str is None:
            date_str = date.today().strftime("%Y-%m-%d")

        os.makedirs(EXPORTS_DIR, exist_ok=True)
        csv_path = os.path.join(EXPORTS_DIR, f"{date_str}.csv")

        # Date boundaries as UNIX timestamps
        start_dt = datetime.strptime(date_str, "%Y-%m-%d")
        start_ts = start_dt.timestamp()
        end_ts   = start_ts + 86400

        if not self._conn:
            logger.error("[DB] Cannot export — database not open")
            return csv_path

        cur  = self._conn.cursor()
        rows = cur.execute(
            """SELECT epoch_start, epoch_end, stage,
                      avg_resp_bpm, resp_cov, avg_hr, hr_cov,
                      avg_spo2, disturbance, mpu_motion, room_temp
               FROM sleep_epochs
               WHERE epoch_start >= ? AND epoch_start < ?
               ORDER BY epoch_start""",
            (start_ts, end_ts),
        ).fetchall()

        headers = [
            "epoch_start", "epoch_end", "stage",
            "avg_resp_bpm", "resp_cov", "avg_hr", "hr_cov",
            "avg_spo2", "disturbance", "mpu_motion", "room_temp",
        ]

        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            writer.writerows(rows)

        logger.info("[DB] CSV exported: %s (%d epochs)", csv_path, len(rows))
        return csv_path

    # ─── Query helpers ────────────────────────────────────────────────────────

    def get_epochs_since(self, since_ts: float) -> list:
        """Return all sleep epochs since a UNIX timestamp."""
        if not self._conn:
            return []
        cur = self._conn.cursor()
        return cur.execute(
            "SELECT * FROM sleep_epochs WHERE epoch_start >= ? ORDER BY epoch_start",
            (since_ts,)
        ).fetchall()

    def get_night_summary(self, session_start_ts: float) -> dict:
        """
        Compute aggregated stats for a sleep session.
        Returns dict with duration_min, avg_hr, avg_spo2, avg_breath,
        min_temp, max_temp, stage_counts, cycle_estimate.
        """
        if not self._conn:
            return {}
        cur = self._conn.cursor()

        rows = cur.execute(
            """SELECT stage, avg_resp_bpm, avg_hr, avg_spo2, room_temp
               FROM sleep_epochs WHERE epoch_start >= ?
               ORDER BY epoch_start""",
            (session_start_ts,)
        ).fetchall()

        if not rows:
            return {}

        stages      = [r[0] for r in rows]
        breath_vals = [r[1] for r in rows if r[1] is not None]
        hr_vals     = [r[2] for r in rows if r[2] is not None]
        spo2_vals   = [r[3] for r in rows if r[3] is not None]
        temp_vals   = [r[4] for r in rows if r[4] is not None]

        stage_counts = {}
        for s in stages:
            stage_counts[s] = stage_counts.get(s, 0) + 1

        # Estimate cycles: count Wake→Sleep transitions
        cycle_count = 0
        prev = None
        for s in stages:
            if prev in ("N2", "N3", "REM") and s == "N1":
                cycle_count += 1
            prev = s

        duration_min = len(rows) * 30 // 60

        return {
            "duration_min": duration_min,
            "avg_hr":       round(sum(hr_vals)     / len(hr_vals),     1) if hr_vals     else None,
            "avg_spo2":     round(sum(spo2_vals)   / len(spo2_vals),   1) if spo2_vals   else None,
            "avg_breath":   round(sum(breath_vals) / len(breath_vals), 1) if breath_vals else None,
            "min_temp":     round(min(temp_vals), 2)                       if temp_vals   else None,
            "max_temp":     round(max(temp_vals), 2)                       if temp_vals   else None,
            "stage_counts": stage_counts,
            "cycle_count":  cycle_count,
            "total_epochs": len(rows),
        }
