/*******************************************************************************
 * palno_esp32.ino — Palno Unified Firmware (ESP32)
 *
 * Part of the Palno & Slemon sleep-tracking system.
 * This sketch runs on the ESP32 (Palno node) and integrates:
 *
 *   1. MAX30102 biometric sensor (HR + SpO2) via I2C
 *      - 100-sample buffer, 25-sample sliding window, 1 Hz output
 *      - Uses unmodified Maxim algorithm.h/algorithm.cpp library
 *
 *   2. MPU6050 accelerometer/gyroscope via I2C (shared bus)
 *      - Burst-read at 50 Hz (20 ms interval)
 *      - Shake-to-dismiss: 10 half-cycles at ω_mag ≥ 300°/s in 4 s
 *
 *   3. BLE GATT server with 4 characteristics:
 *      - Biometrics (Notify @ 1 Hz): HR, SpO2, validity flags
 *      - Motion (Notify @ 20 Hz): accel XYZ, gyro XYZ
 *      - Alarm (Notify on-event): shake count, dismissal
 *      - Config (Write): arm/disarm alarm from Slemon
 *
 * Wiring (ESP32):
 *   GPIO 21 = I2C SDA  (shared: MAX30102 addr 0x57, MPU6050 addr 0x68)
 *   GPIO 22 = I2C SCL
 *   GPIO 4  = MAX30102 INT (active-low)
 *   GPIO 2  = Onboard LED (heartbeat)
 *
 * Build: Arduino IDE with ESP32 board package
 ******************************************************************************/

#include <Arduino.h>
#include <Wire.h>

// ─── Project modules ────────────────────────────────────────────────────────
#include "ble_service.h"
#include "biometrics.h"
#include "motion.h"

// ─── Timing constants ───────────────────────────────────────────────────────
// Motion sampling at 50 Hz (20 ms period)
#define MOTION_INTERVAL_MS      20

// BLE motion notification at ~20 Hz (every 50 ms = every 2–3 motion reads)
// We batch 2-3 motion reads and send the latest at 20 Hz
#define BLE_MOTION_INTERVAL_MS  50

// BLE biometrics notification at 1 Hz
// (biometrics_update() itself takes ~1 second to collect 25 samples)
#define BLE_BIO_INTERVAL_MS     1000

// Serial debug output at 1 Hz
#define SERIAL_DEBUG_INTERVAL_MS 1000

// ─── Timing state ───────────────────────────────────────────────────────────
static uint32_t lastMotionReadMs   = 0;
static uint32_t lastBleMotionMs    = 0;
static uint32_t lastBleBioMs       = 0;
static uint32_t lastSerialDebugMs  = 0;

// ─── Task scheduling flags ──────────────────────────────────────────────────
// biometrics_update() is blocking (~1s), so we interleave it carefully
static bool     bioUpdatePending   = false;
static uint32_t bioUpdateDueMs     = 0;

// ─── Shake state ────────────────────────────────────────────────────────────
static uint8_t  lastShakeCount     = 0;
static bool     alarmDismissNotified = false;

// =============================================================================
// SETUP
// =============================================================================
void setup() {
  Serial.begin(115200);
  delay(500);

  Serial.println("╔══════════════════════════════════════════╗");
  Serial.println("║   Palno ESP32 — Sleep Tracking Node     ║");
  Serial.println("║   v1.0  Palno & Slemon Project          ║");
  Serial.println("╚══════════════════════════════════════════╝");
  Serial.println();

  // ── Initialise I2C bus (shared by MAX30102 and MPU6050) ──
  Wire.begin(MPU6050_SDA, MPU6050_SCL);
  Wire.setClock(400000);  // 400 kHz Fast I2C
  Serial.println("[INIT] I2C bus started (SDA=21, SCL=22, 400kHz)");

  // ── Initialise MPU6050 (fast, non-blocking) ──
  motion_init();

  // ── Initialise BLE GATT server ──
  ble_init("Palno-ESP32");

  // ── Initialise MAX30102 biometric sensor ──
  // NOTE: This takes ~4 seconds (fills 100-sample buffer at 25 sps)
  Serial.println("[INIT] Starting MAX30102 initialisation (4s)...");
  biometrics_init();

  // ── Schedule first biometrics update ──
  bioUpdateDueMs = millis() + BLE_BIO_INTERVAL_MS;

  Serial.println();
  Serial.println("[INIT] === ALL SYSTEMS READY ===");
  Serial.println("[INIT] BLE advertising as 'Palno-ESP32'");
  Serial.println("[INIT] Motion: 50 Hz | BLE Motion: 20 Hz | BLE Bio: 1 Hz");
  Serial.println();
}

// =============================================================================
// LOOP
// =============================================================================
void loop() {
  uint32_t now = millis();

  // ── Handle BLE reconnection ───────────────────────────────────────────────
  ble_handle_reconnect();

  // ── Task 1: Read MPU6050 at 50 Hz (every 20 ms) ──────────────────────────
  if (now - lastMotionReadMs >= MOTION_INTERVAL_MS) {
    lastMotionReadMs = now;

    motion_read();

    // ── Shake detection (only when alarm is armed) ──
    if (alarmArmed && !alarmDismissNotified) {
      uint8_t shakeCount = motion_detect_shakes();

      // Report shake progress if count changed
      if (shakeCount != lastShakeCount && shakeCount > 0) {
        lastShakeCount = shakeCount;

        // Debug: show progress
        Serial.print("[SHAKE] Progress: ");
        Serial.print(shakeCount);
        Serial.print("/");
        Serial.println(SHAKE_HALF_CYCLES_REQ);

        // Send intermediate shake count as notification
        char buf[32];
        snprintf(buf, sizeof(buf), "SHAKE:%d", shakeCount);
        ble_notify_alarm(buf);
      }

      // Check if alarm should be dismissed
      if (shakeCount >= SHAKE_HALF_CYCLES_REQ) {
        Serial.println("╔═══════════════════════════════════╗");
        Serial.println("║  🔔 ALARM DISMISSED (10 shakes)  ║");
        Serial.println("╚═══════════════════════════════════╝");

        ble_notify_alarm("SHAKE:10,ALARM_DISMISSED");
        alarmDismissNotified = true;
        alarmArmed = false;

        // Reset shake state for next alarm
        motion_reset_shakes();
        lastShakeCount = 0;

        // After some time, allow re-arming
        // (will be re-armed by Slemon via Config write)
      }
    } else if (!alarmArmed) {
      // Reset notification flag when alarm is disarmed
      alarmDismissNotified = false;
      lastShakeCount = 0;
    }
  }

  // ── Task 2: Send motion data over BLE at ~20 Hz ──────────────────────────
  if (now - lastBleMotionMs >= BLE_MOTION_INTERVAL_MS) {
    lastBleMotionMs = now;

    ble_notify_motion(
      motion_get_ax(), motion_get_ay(), motion_get_az(),
      motion_get_gx(), motion_get_gy(), motion_get_gz()
    );
  }

  // ── Task 3: Biometrics update (~1 Hz, blocking ~1s) ───────────────────────
  // biometrics_update() reads 25 new samples at 25 sps = ~1 second blocking.
  // We run it when the timer expires.
  if (now >= bioUpdateDueMs) {
    biometrics_update();   // ~1 second blocking call

    // Send biometrics over BLE
    ble_notify_biometrics(
      biometrics_get_hr(),
      biometrics_get_hr_valid(),
      biometrics_get_spo2(),
      biometrics_get_spo2_valid()
    );

    // Schedule next update
    bioUpdateDueMs = millis() + BLE_BIO_INTERVAL_MS;
    lastBleBioMs = millis();
  }

  // ── Task 4: Serial debug output at 1 Hz ──────────────────────────────────
  if (now - lastSerialDebugMs >= SERIAL_DEBUG_INTERVAL_MS) {
    lastSerialDebugMs = now;

    Serial.print("[DATA] HR=");
    Serial.print(biometrics_get_hr());
    Serial.print(" v=");
    Serial.print(biometrics_get_hr_valid());
    Serial.print(" | SpO2=");
    Serial.print(biometrics_get_spo2());
    Serial.print(" v=");
    Serial.print(biometrics_get_spo2_valid());
    Serial.print(" | AX=");
    Serial.print(motion_get_ax(), 3);
    Serial.print(" AY=");
    Serial.print(motion_get_ay(), 3);
    Serial.print(" AZ=");
    Serial.print(motion_get_az(), 3);
    Serial.print(" | GX=");
    Serial.print(motion_get_gx(), 1);
    Serial.print(" GY=");
    Serial.print(motion_get_gy(), 1);
    Serial.print(" GZ=");
    Serial.print(motion_get_gz(), 1);
    Serial.print(" | dA=");
    Serial.print(motion_get_dynamic_accel(), 3);
    Serial.print(" | BLE=");
    Serial.print(bleDeviceConnected ? "Y" : "N");
    Serial.print(" Alarm=");
    Serial.println(alarmArmed ? "ARMED" : "off");
  }

  // ── Yield to watchdog ─────────────────────────────────────────────────────
  // Small delay to prevent watchdog reset on ESP32
  // The biometrics_update() blocking call already yields during digitalRead waits
  delay(1);
}
