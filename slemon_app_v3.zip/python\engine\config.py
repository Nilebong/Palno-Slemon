"""
config.py — Single Source of Truth for All Configurable Constants
Palno & Slemon Sleep Tracking System

All thresholds, timings, paths, and tunable parameters live here.
Modify this file to tune the system without touching algorithm code.
"""

import os

# ═══════════════════════════════════════════════════════════════════════════════
# 1. SYSTEM PATHS
# ═══════════════════════════════════════════════════════════════════════════════

# Root of project (adjust if deployed to Uno Q Linux)
PROJECT_ROOT   = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
AUDIO_DIR      = os.path.join(PROJECT_ROOT, "audio")
DATA_DIR       = os.path.join(PROJECT_ROOT, "data")
DB_PATH        = os.path.join(DATA_DIR, "sleep_log.db")
EXPORTS_DIR    = os.path.join(DATA_DIR, "exports")

# ═══════════════════════════════════════════════════════════════════════════════
# 2. HARDWARE / SERIAL
# ═══════════════════════════════════════════════════════════════════════════════

# Serial port where STM32 sends bridge data to Qualcomm
# On Arduino Uno Q Linux side, the STM32 internal UART typically appears as:
STM32_SERIAL_PORT  = "/dev/ttyS1"      # adjust to actual port
STM32_SERIAL_BAUD  = 115200

# ═══════════════════════════════════════════════════════════════════════════════
# 3. BLE SETTINGS (Palno ESP32 → Qualcomm)
# ═══════════════════════════════════════════════════════════════════════════════

BLE_DEVICE_NAME    = "Palno-ESP32"
BLE_SERVICE_UUID   = "a1b2c3d4-e5f6-7890-abcd-ef1234567890"

# Optional explicit MAC address for Palno ESP32 (e.g. "AA:BB:CC:DD:EE:FF")
# Leave empty string for auto-discovery by name and service UUID
PALNO_BLE_MAC      = os.environ.get("PALNO_BLE_MAC", "")

# Optional explicit Bluetooth A2DP Speaker MAC address (e.g. "41:42:00:00:1B:66")
BT_SPEAKER_MAC     = os.environ.get("BT_SPEAKER_MAC", "")

# Load cached hardware configuration from bluetooth_config.json if available
BT_CONFIG_PATH = os.path.join(DATA_DIR, "bluetooth_config.json")
if os.path.exists(BT_CONFIG_PATH):
    try:
        import json as _json
        with open(BT_CONFIG_PATH, "r", encoding="utf-8") as _f:
            _bt_data = _json.load(_f)
            if not PALNO_BLE_MAC:
                PALNO_BLE_MAC = _bt_data.get("palno_mac", "")
            if not BT_SPEAKER_MAC:
                BT_SPEAKER_MAC = _bt_data.get("speaker_mac", "")
    except Exception:
        pass

BLE_CHAR_BIOMETRICS = "a1b2c3d4-e5f6-7890-abcd-ef1234560001"
BLE_CHAR_MOTION     = "a1b2c3d4-e5f6-7890-abcd-ef1234560002"
BLE_CHAR_ALARM      = "a1b2c3d4-e5f6-7890-abcd-ef1234560003"
BLE_CHAR_CONFIG     = "a1b2c3d4-e5f6-7890-abcd-ef1234560004"

# Reconnect backoff: first=5s, doubles each attempt up to max
BLE_RECONNECT_INITIAL_S = 5
BLE_RECONNECT_MAX_S     = 30

# ═══════════════════════════════════════════════════════════════════════════════
# 4. RADAR / BREATH ALGORITHM
# ═══════════════════════════════════════════════════════════════════════════════

# Breath detection thresholds
BREATH_BASELINE          = 15       # noise floor (energy units 0–100)
BREATH_ADAPTIVE          = True     # use adaptive baseline (10th-pct rolling)
BREATH_ADAPTIVE_WINDOW_S = 60       # rolling window for adaptive baseline

BREATH_MIN_ZERO_GAP      = 25       # min consecutive sub-baseline samples between breaths
BREATH_MIN_TRIGGER_ENERGY = 100     # energy level that triggers session start/stop
BREATH_TRIGGER_DURATION_S = 3.0     # how long energy must be at trigger level

# Distance normalisation (production algorithm)
BREATH_DIST_REF_CM       = 100      # reference distance (cm)
BREATH_DIST_ALPHA        = 1.2      # distance compensation exponent

# Disturbance index blend
DISTURBANCE_BETA         = 0.6      # weight for moving energy vs gate average
DISTURBANCE_YELLOW_THRESH = 25      # green→yellow boundary
DISTURBANCE_RED_THRESH    = 70      # yellow→red boundary

# ═══════════════════════════════════════════════════════════════════════════════
# 5. SLEEP STAGE CLASSIFIER
# ═══════════════════════════════════════════════════════════════════════════════

EPOCH_SECONDS             = 30      # PSG-standard epoch duration

# Wake detection
WAKE_DISTURBANCE_THRESH   = 50.0
WAKE_ACCEL_THRESH         = 0.10    # g — dynamic acceleration
WAKE_MOTION_RATIO         = 0.30    # fraction of epoch with movement → Wake

# NREM vs REM split (respiratory regularity)
RESP_REGULARITY_SPLIT     = 0.12    # CoV boundary: ≤ = regular (NREM), > = irregular

# REM vs N1 scoring
REM_SCORE_THRESH          = 4       # score ≥ this → REM
REM_TWITCH_ACCEL_THRESH   = 0.03    # g — min spike for a REM twitch
REM_TWITCH_DURATION_MAX_S = 0.5     # max duration of a twitch

# N3 vs N2 depth scoring
N3_DEPTH_THRESH           = 4       # depth score ≥ this → N3
RESP_COV_DEEP             = 0.05    # very regular breathing (N3 indicator)

# Temporal smoothing
SMOOTHING_WINDOW_EPOCHS   = 5       # majority vote window (5 × 30 s = 2.5 min)

# Sleep cycle expected duration
SLEEP_CYCLE_MIN           = 95      # minutes per cycle

# ═══════════════════════════════════════════════════════════════════════════════
# 6. ALARM SETTINGS
# ═══════════════════════════════════════════════════════════════════════════════

# User alarm window (HH:MM strings — overridden at runtime via web UI)
ALARM_TARGET_TIME         = "07:00"
ALARM_WINDOW_MIN          = 30       # alarm can fire up to this many minutes early

# Audio volume control
AUDIO_START_VOL_PCT       = 10       # initial volume %
AUDIO_MAX_VOL_PCT         = 60       # maximum volume %
AUDIO_RAMP_DURATION_S     = 120      # time to ramp from start to max vol (seconds)
AUDIO_CROSSFADE_S         = 10       # seconds to crossfade between alpha→beta tracks
AUDIO_FADE_OUT_S          = 1        # fade to 0 on dismiss

# Shake-dismiss
SHAKE_DISMISS_COUNT       = 10       # shakes required to dismiss alarm

# ═══════════════════════════════════════════════════════════════════════════════
# 7. AUDIO FILES
# ═══════════════════════════════════════════════════════════════════════════════

AUDIO_FILES = {
    # Key: logical name → filename in audio/
    "sleep_delta":  "sleep_delta_2hz.wav",    # 200 Hz | 202 Hz  → 2 Hz beat
    "sleep_theta":  "sleep_theta_4hz.wav",    # 200 Hz | 204 Hz  → 4 Hz beat
    "wake_alpha":   "wake_alpha_10hz.wav",    # 250 Hz | 260 Hz  → 10 Hz beat
    "wake_beta":    "wake_beta_14hz.wav",     # 250 Hz | 264 Hz  → 14 Hz beat
}

# Audio generation parameters
AUDIO_SAMPLE_RATE   = 44100     # Hz
AUDIO_DURATION_S    = 600       # 10-minute files (looped by mpv)
AUDIO_CARRIER_L     = { "sleep_delta": 200, "sleep_theta": 200,
                         "wake_alpha": 250, "wake_beta":  250 }
AUDIO_CARRIER_R     = { "sleep_delta": 202, "sleep_theta": 204,
                         "wake_alpha": 260, "wake_beta":  264 }

# ═══════════════════════════════════════════════════════════════════════════════
# 8. WEB SERVER
# ═══════════════════════════════════════════════════════════════════════════════

WEB_HOST            = "0.0.0.0"
WEB_PORT            = 8080
WEB_HISTORY_HOURS   = 8         # default history window for graphs

# ═══════════════════════════════════════════════════════════════════════════════
# 9. DATA LOGGING
# ═══════════════════════════════════════════════════════════════════════════════

DB_BATCH_INSERT_S   = 1.0       # batch inserts every 1 second
DB_WAL_MODE         = True      # use SQLite WAL for crash safety

# ═══════════════════════════════════════════════════════════════════════════════
# 11. SLEEP SCORE WEIGHTS
# ═══════════════════════════════════════════════════════════════════════════════

SCORE_W_DURATION    = 0.25
SCORE_W_EFFICIENCY  = 0.25
SCORE_W_DEEP        = 0.20
SCORE_W_CYCLES      = 0.15
SCORE_W_WAKE_EVENTS = 0.15

SCORE_TARGET_HOURS  = 7.5       # ideal sleep duration
SCORE_TARGET_N3_PCT = 0.20      # ideal fraction of sleep in N3
SCORE_TARGET_CYCLES = 5         # ideal number of complete cycles
SCORE_WAKE_PENALTY  = 15        # points deducted per mid-night awakening
