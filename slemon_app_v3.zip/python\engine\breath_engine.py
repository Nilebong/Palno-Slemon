"""
breath_engine.py — Production Breath Detection Engine
Palno & Slemon Sleep Tracking System

Upgraded from ld2410_plotter.py BreathCounter for continuous overnight use:

Changes from test-mode algorithm:
  - Auto-presence arming: arms when LD2410 target_state > 0 for >= 2s
  - Continuous session: no manual stop signal; runs all night
  - Saturation (E=100): flagged as gross movement, NOT a session stopper
  - Adaptive baseline: 10th-percentile of 60-second rolling window
  - Distance-normalised breath intensity: I = E * (D/D_ref)^alpha / Baseline
"""

import collections
import logging
import math
import time
from typing import Optional

from engine.config import (
    BREATH_BASELINE, BREATH_ADAPTIVE, BREATH_ADAPTIVE_WINDOW_S,
    BREATH_MIN_ZERO_GAP, BREATH_MIN_TRIGGER_ENERGY,
    BREATH_DIST_REF_CM, BREATH_DIST_ALPHA,
    DISTURBANCE_BETA, DISTURBANCE_YELLOW_THRESH, DISTURBANCE_RED_THRESH,
)

logger = logging.getLogger(__name__)


class ProductionBreathEngine:
    """
    Continuous breath detection engine for overnight sleep monitoring.

    Receives radar telemetry frames from the serial bridge and maintains:
      - breath_count       : total breaths detected this session
      - breath_bpm         : instantaneous breathing rate (breaths/min)
      - breath_intensity   : distance-normalised intensity of last breath
      - disturbance        : rolling disturbance index (0–100)
      - disturbance_colour : "GREEN" | "YELLOW" | "RED"
      - session_active     : whether a sleep session is running
      - gross_movement     : True when E=100 (person moving in bed)
    """

    # Session state machine
    STATE_WAITING  = "WAITING"    # waiting for presence to arm
    STATE_ACTIVE   = "ACTIVE"     # monitoring breaths
    STATE_MOVEMENT = "MOVEMENT"   # gross movement detected (E=100)

    def __init__(self):
        self._state           = self.STATE_WAITING

        # Breath counting
        self.breath_count     = 0
        self.breath_bpm       = 0.0
        self.breath_intensity = 0.0
        self._last_breath_ts  = 0.0
        self._zero_gap        = 0       # consecutive sub-baseline samples
        self._above_baseline  = False   # was last sample above baseline?
        self._in_breath       = False   # currently inside a breath peak

        # Adaptive baseline
        self._baseline        = float(BREATH_BASELINE)
        self._energy_history: collections.deque = collections.deque()
        self._adaptive_start  = time.time()

        # Auto-arm: need target_state > 0 for 2 continuous seconds
        self._presence_ts     = 0.0     # when presence first detected
        self._ARM_DURATION_S  = 2.0

        # Disturbance
        self.disturbance         = 0.0
        self.disturbance_colour  = "GREEN"
        self._dist_history: collections.deque = collections.deque(maxlen=20)

        # Session info
        self.session_active   = False
        self.session_start_ts = 0.0
        self.gross_movement   = False

        # Breath interval history for CoV (used by sleep classifier)
        self._breath_intervals: collections.deque = collections.deque(maxlen=20)

        # Callbacks
        self._on_breath: Optional[callable] = None

    def set_on_breath(self, callback: callable):
        """Register callback called on each detected breath: cb(breath_num, bpm, intensity)"""
        self._on_breath = callback

    # ─── Adaptive baseline ───────────────────────────────────────────────────

    def _update_adaptive_baseline(self, energy: float):
        """Maintain a 60-second window of energy values; baseline = 10th pct."""
        now = time.time()
        self._energy_history.append((now, energy))
        # Prune entries older than BREATH_ADAPTIVE_WINDOW_S
        cutoff = now - BREATH_ADAPTIVE_WINDOW_S
        while self._energy_history and self._energy_history[0][0] < cutoff:
            self._energy_history.popleft()

        if len(self._energy_history) >= 10:
            vals = sorted(v for _, v in self._energy_history)
            p10_idx = max(0, int(len(vals) * 0.10) - 1)
            self._baseline = max(5.0, vals[p10_idx])

    def get_baseline(self) -> float:
        return self._baseline

    def set_baseline_override(self, value: float):
        """Manual baseline override (from web UI slider)."""
        self._baseline = max(1.0, float(value))
        logger.info("[BREATH] Manual baseline set to %.1f", self._baseline)

    # ─── Disturbance index ───────────────────────────────────────────────────

    def _compute_disturbance(self, mov_energy: float, mg: list) -> float:
        """
        D[k] = beta * E_moving + (1-beta) * mean(gate_energies)
        """
        gate_mean = sum(mg) / len(mg) if mg else 0.0
        dist = DISTURBANCE_BETA * mov_energy + (1.0 - DISTURBANCE_BETA) * gate_mean
        self._dist_history.append(dist)
        avg_dist = sum(self._dist_history) / len(self._dist_history)
        return avg_dist

    def _classify_disturbance(self, d: float) -> str:
        if d >= DISTURBANCE_RED_THRESH:    return "RED"
        if d >= DISTURBANCE_YELLOW_THRESH: return "YELLOW"
        return "GREEN"

    # ─── Distance-normalised breath intensity ────────────────────────────────

    def _breath_intensity(self, energy: float, dist_cm: float) -> float:
        """
        I = E * (D / D_ref)^alpha / Baseline
        """
        if dist_cm <= 0:
            dist_cm = BREATH_DIST_REF_CM
        ratio    = dist_cm / BREATH_DIST_REF_CM
        baseline = max(1.0, self._baseline)
        return (energy * (ratio ** BREATH_DIST_ALPHA)) / baseline

    # ─── Main update (call per radar frame, ~20 Hz) ──────────────────────────

    def update(self, frame: dict) -> dict:
        """
        Process one radar telemetry frame.
        Returns a status dict with current engine state.

        frame keys (from serial_bridge): target_state, mov_dist_cm,
            mov_energy, sta_dist_cm, sta_energy, det_dist_cm, mg, sg, ts
        """
        now        = frame.get("ts",         time.time())
        state_val  = frame.get("target_state", 0)
        energy     = frame.get("mov_energy",    0.0)
        dist_cm    = frame.get("mov_dist_cm",   BREATH_DIST_REF_CM)
        mg         = frame.get("mg",            [0.0] * 9)

        # Clamp energy
        energy = min(100.0, max(0.0, float(energy)))

        # Update adaptive baseline
        if BREATH_ADAPTIVE and energy < BREATH_MIN_TRIGGER_ENERGY:
            self._update_adaptive_baseline(energy)

        # Compute disturbance regardless of state
        self.disturbance        = self._compute_disturbance(energy, mg)
        self.disturbance_colour = self._classify_disturbance(self.disturbance)

        # ── Gross movement check ─────────────────────────────────────────────
        self.gross_movement = (energy >= BREATH_MIN_TRIGGER_ENERGY)

        # ── State machine ─────────────────────────────────────────────────────
        if self._state == self.STATE_WAITING:
            # Auto-arm: need target_state > 0 continuously for _ARM_DURATION_S
            if state_val > 0 and energy < BREATH_MIN_TRIGGER_ENERGY:
                if self._presence_ts == 0.0:
                    self._presence_ts = now
                elif (now - self._presence_ts) >= self._ARM_DURATION_S:
                    self._state           = self.STATE_ACTIVE
                    self.session_active   = True
                    self.session_start_ts = now
                    self.breath_count     = 0
                    self._last_breath_ts  = now
                    self._zero_gap        = 0
                    self._in_breath       = False
                    logger.info("[BREATH] Session ARMED — presence detected")
            else:
                self._presence_ts = 0.0

        elif self._state == self.STATE_ACTIVE:
            if self.gross_movement:
                # Treat E=100 as gross movement — do NOT freeze; log and continue
                self._state     = self.STATE_MOVEMENT
                self._zero_gap  = 0
                self._in_breath = False
                logger.debug("[BREATH] Gross movement (E=100)")
            else:
                self._process_breath_sample(energy, dist_cm, now)

        elif self._state == self.STATE_MOVEMENT:
            if not self.gross_movement:
                # Energy dropped below saturation — resume monitoring
                self._state    = self.STATE_ACTIVE
                self._zero_gap = 0
                logger.debug("[BREATH] Movement ended — resuming")
            # While in movement state, don't count breaths

        return self._status_dict()

    def _process_breath_sample(self, energy: float, dist_cm: float, ts: float):
        """Core breath detection logic."""
        baseline = self._baseline

        if energy > baseline:
            # Above baseline — potential breath peak
            if not self._above_baseline:
                # Rising edge — new peak is starting
                self._above_baseline = True

                # A breath is registered when:
                #   - we had >= MIN_ZERO_GAP consecutive sub-baseline samples
                #   - we haven't already counted this breath
                if self._zero_gap >= BREATH_MIN_ZERO_GAP and not self._in_breath:
                    self._in_breath = True
                    self._register_breath(energy, dist_cm, ts)

            # Else: still above baseline from a previous peak — ignore
        else:
            # Below baseline — silent gap
            self._above_baseline = False
            self._in_breath      = False
            self._zero_gap      += 1

    def _register_breath(self, energy: float, dist_cm: float, ts: float):
        """Record a detected breath."""
        self.breath_count    += 1
        intensity             = self._breath_intensity(energy, dist_cm)
        self.breath_intensity = intensity

        if self._last_breath_ts > 0:
            interval_s = ts - self._last_breath_ts
            if 1.0 < interval_s < 30.0:    # physiologically plausible range
                self.breath_bpm = 60.0 / interval_s
                self._breath_intervals.append(interval_s)
        self._last_breath_ts = ts

        logger.debug("[BREATH] #%d | BPM=%.1f | intensity=%.1f | gap=%d",
                     self.breath_count, self.breath_bpm,
                     intensity, self._zero_gap)
        self._zero_gap = 0

        if self._on_breath:
            self._on_breath(self.breath_count, self.breath_bpm, intensity)

    def _status_dict(self) -> dict:
        return {
            "state":              self._state,
            "session_active":     self.session_active,
            "breath_count":       self.breath_count,
            "breath_bpm":         round(self.breath_bpm, 2),
            "breath_intensity":   round(self.breath_intensity, 2),
            "baseline":           round(self._baseline, 1),
            "disturbance":        round(self.disturbance, 2),
            "disturbance_colour": self.disturbance_colour,
            "gross_movement":     self.gross_movement,
        }

    # ─── Features for sleep classifier ──────────────────────────────────────

    def get_resp_stats(self) -> dict:
        """
        Compute respiration rate and variability over recent breath intervals.
        Used by the sleep classifier every 30-second epoch.
        """
        intervals = list(self._breath_intervals)
        if len(intervals) < 2:
            return {"mean_bpm": self.breath_bpm, "cov": 0.0, "n": len(intervals)}

        bpm_vals = [60.0 / t for t in intervals if t > 0]
        if not bpm_vals:
            return {"mean_bpm": 0.0, "cov": 0.0, "n": 0}

        mean_bpm = sum(bpm_vals) / len(bpm_vals)
        variance = sum((v - mean_bpm) ** 2 for v in bpm_vals) / len(bpm_vals)
        std_bpm  = math.sqrt(variance)
        cov      = std_bpm / mean_bpm if mean_bpm > 0 else 0.0

        return {
            "mean_bpm": round(mean_bpm, 2),
            "cov":      round(cov, 4),
            "n":        len(bpm_vals),
        }

    def reset_session(self):
        """Reset for a new night's session."""
        self._state           = self.STATE_WAITING
        self.breath_count     = 0
        self.breath_bpm       = 0.0
        self.breath_intensity = 0.0
        self.session_active   = False
        self.session_start_ts = 0.0
        self._zero_gap        = 0
        self._in_breath       = False
        self._above_baseline  = False
        self._presence_ts     = 0.0
        self._breath_intervals.clear()
        logger.info("[BREATH] Session reset")
