"""
bluetooth_manager.py — Bluetooth Connection & Pairing Assistant
Palno & Slemon Sleep Tracking System

Manages:
  1. Palno ESP32 BLE GATT connection and address caching
  2. Bluetooth Classic A2DP audio speaker pairing, trust, and connection via BlueZ
  3. PulseAudio / PipeWire default audio sink routing for A2DP
  4. Persistent configuration storage in data/bluetooth_config.json
"""

import os
import sys
import json
import time
import logging
import subprocess
from typing import Optional, Dict, Any, List

logger = logging.getLogger("BluetoothManager")

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR     = os.path.join(PROJECT_ROOT, "data")
CONFIG_PATH  = os.path.join(DATA_DIR, "bluetooth_config.json")


def load_bluetooth_config() -> Dict[str, str]:
    """Load cached Bluetooth configuration from data/bluetooth_config.json."""
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logger.warning("[BT] Failed to read config %s: %s", CONFIG_PATH, e)
    return {"palno_mac": "", "speaker_mac": "", "audio_mode": "bt"}


def save_bluetooth_config(palno_mac: Optional[str] = None,
                          speaker_mac: Optional[str] = None,
                          audio_mode: Optional[str] = None) -> bool:
    """Save Bluetooth configuration to data/bluetooth_config.json."""
    cfg = load_bluetooth_config()
    if palno_mac is not None:
        cfg["palno_mac"] = palno_mac.strip()
    if speaker_mac is not None:
        cfg["speaker_mac"] = speaker_mac.strip()
    if audio_mode is not None:
        cfg["audio_mode"] = audio_mode.strip()

    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
        logger.info("[BT] Saved config: %s", cfg)
        return True
    except Exception as e:
        logger.error("[BT] Failed to write config %s: %s", CONFIG_PATH, e)
        return False


def run_system_cmd(cmd_list: List[str], timeout: float = 10.0) -> str:
    """Run a system command and return stripped stdout."""
    try:
        res = subprocess.run(cmd_list, capture_output=True, text=True, timeout=timeout)
        return (res.stdout or "").strip()
    except Exception as e:
        logger.debug("[BT] Command %s failed: %s", cmd_list, e)
        return ""


class BluetoothManager:
    """
    Central manager for Palno ESP32 BLE and Bluetooth Classic A2DP Audio.
    Handles device discovery, pairing, trust, and PulseAudio A2DP routing.
    """

    def __init__(self):
        self.config = load_bluetooth_config()

    def get_palno_mac(self) -> str:
        return self.config.get("palno_mac", "")

    def get_speaker_mac(self) -> str:
        return self.config.get("speaker_mac", "")

    def get_audio_mode(self) -> str:
        return self.config.get("audio_mode", "bt")

    def set_palno_mac(self, mac: str) -> bool:
        self.config["palno_mac"] = mac.strip()
        return save_bluetooth_config(palno_mac=mac)

    def set_speaker_mac(self, mac: str) -> bool:
        self.config["speaker_mac"] = mac.strip()
        return save_bluetooth_config(speaker_mac=mac)

    def set_audio_mode(self, mode: str) -> bool:
        self.config["audio_mode"] = mode.strip()
        return save_bluetooth_config(audio_mode=mode)

    # ─── Bluetooth A2DP Audio Speaker ──────────────────────────────────────────

    def detect_a2dp_sink(self, target_mac: Optional[str] = None) -> Optional[str]:
        """
        Check PulseAudio/PipeWire for an active Bluetooth A2DP audio sink.
        Returns the sink name (e.g. 'bluez_sink.41_42_00_00_1B_66.a2dp_sink').
        """
        if os.name == "nt":
            return None

        mac = target_mac or self.get_speaker_mac()
        sinks_out = run_system_cmd(["pactl", "list", "sinks", "short"], timeout=2.0)
        if not sinks_out:
            return None

        mac_pattern = mac.replace(":", "_").upper() if mac else ""
        for line in sinks_out.splitlines():
            parts = line.split()
            if len(parts) >= 2:
                sink_name = parts[1]
                if "bluez_sink" in sink_name.lower():
                    if not mac_pattern or mac_pattern in sink_name.upper():
                        return sink_name
                    # If any bluez sink is active and matches a2dp, return it
                    if "a2dp" in sink_name.lower():
                        return sink_name
        return None

    def connect_a2dp_speaker(self, mac: str) -> Dict[str, Any]:
        """
        Pair, trust, and connect an external Bluetooth A2DP speaker via BlueZ / bluetoothctl.
        Configures PulseAudio default sink upon successful connection.
        """
        mac = mac.strip().upper()
        if not mac:
            return {"success": False, "message": "No MAC address specified"}

        if os.name == "nt":
            # On Windows, Bluetooth pairing is managed by Windows OS
            self.set_speaker_mac(mac)
            return {
                "success": True,
                "message": f"Saved speaker MAC {mac}. On Windows, pair device via Windows Settings > Bluetooth.",
                "sink": "wasapi"
            }

        logger.info("[BT] Connecting Bluetooth A2DP speaker: %s", mac)
        # 1. Enable adapter and default agent
        run_system_cmd(["bluetoothctl", "power", "on"], timeout=3.0)
        run_system_cmd(["bluetoothctl", "agent", "on"], timeout=2.0)
        run_system_cmd(["bluetoothctl", "default-agent"], timeout=2.0)

        # 2. Trust device (auto-reconnect on boot)
        run_system_cmd(["bluetoothctl", "trust", mac], timeout=3.0)

        # 3. Pair device
        pair_out = run_system_cmd(["bluetoothctl", "pair", mac], timeout=8.0)
        logger.info("[BT] Pair result: %s", pair_out)

        # 4. Connect device
        conn_out = run_system_cmd(["bluetoothctl", "connect", mac], timeout=8.0)
        logger.info("[BT] Connect result: %s", conn_out)

        # Save MAC to persistent config
        self.set_speaker_mac(mac)

        # 5. Wait for PulseAudio bluez sink to register
        time.sleep(1.5)
        sink = self.detect_a2dp_sink(mac)
        if sink:
            run_system_cmd(["pactl", "set-default-sink", sink], timeout=2.0)
            logger.info("[BT] Audio routed to Bluetooth A2DP sink: %s", sink)
            return {
                "success": True,
                "sink": sink,
                "mac": mac,
                "message": f"Successfully connected and routed A2DP audio to {sink}"
            }
        else:
            return {
                "success": True,
                "sink": None,
                "mac": mac,
                "message": f"Bluetooth connected to {mac}. Waiting for A2DP audio sink..."
            }

    def get_speaker_status(self) -> Dict[str, Any]:
        """Get live status of the Bluetooth speaker."""
        mac = self.get_speaker_mac()
        sink = self.detect_a2dp_sink(mac)
        if os.name == "nt":
            return {
                "connected": True,
                "mac": mac,
                "sink": "wasapi (Windows Audio)",
                "mode": self.get_audio_mode()
            }

        connected = False
        if mac:
            info_out = run_system_cmd(["bluetoothctl", "info", mac], timeout=2.0)
            connected = "Connected: yes" in info_out

        return {
            "connected": connected or (sink is not None),
            "mac": mac,
            "sink": sink or "None (Default / System)",
            "mode": self.get_audio_mode()
        }

    def scan_nearby_devices(self, scan_duration: float = 6.0) -> List[Dict[str, str]]:
        """
        Scan for nearby Bluetooth devices using bluetoothctl (Linux) or Bleak.
        Returns a list of dicts: [{'name': '...', 'mac': '...', 'type': 'audio|ble|unknown'}]
        """
        devices = []
        if os.name != "nt":
            try:
                run_system_cmd(["bluetoothctl", "power", "on"], timeout=2.0)
                # Run scan in background
                proc = subprocess.Popen(["bluetoothctl", "scan", "on"],
                                        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                time.sleep(scan_duration)
                proc.terminate()
            except Exception as e:
                logger.warning("[BT] Scan process error: %s", e)

            # Read discovered devices
            out = run_system_cmd(["bluetoothctl", "devices"], timeout=3.0)
            for line in out.splitlines():
                # Format: "Device AA:BB:CC:DD:EE:FF Device Name"
                parts = line.split(maxsplit=2)
                if len(parts) >= 3 and parts[0] == "Device":
                    d_mac  = parts[1].strip()
                    d_name = parts[2].strip()
                    d_type = "audio" if any(w in d_name.lower() for w in ["speaker", "sound", "jbl", "anker", "headphone", "audio", "boat", "sony"]) else "bt"
                    devices.append({"mac": d_mac, "name": d_name, "type": d_type})
        return devices
