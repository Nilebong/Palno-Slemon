/*******************************************************************************
 * motion.h — MPU6050 Accelerometer/Gyroscope + Shake Detection for Palno
 *
 * Based on the register-level pattern from mpu6050_acc_gyro.ino:
 *   - I2C address 0x68, SDA=21, SCL=22 (shared bus with MAX30102)
 *   - Accel: ±2g  → divide raw by 16384.0
 *   - Gyro:  ±250°/s → divide raw by 131.0
 *
 * Shake Detection Algorithm:
 *   1. Sample at 50 Hz (20 ms interval)
 *   2. Compute gyro magnitude: ω_mag = sqrt(gx² + gy² + gz²)
 *   3. A half-cycle is registered when ω_mag ≥ 300 °/s AND a sign
 *      reversal occurs in the dominant axis within ≤ 300 ms
 *   4. When 10 half-cycles accumulate in a 4-second sliding window,
 *      the alarm is dismissed
 ******************************************************************************/
#ifndef MOTION_H_
#define MOTION_H_

#include <Arduino.h>
#include <Wire.h>
#include <math.h>

// ─── MPU6050 configuration ──────────────────────────────────────────────────
#define MPU6050_ADDR    0x68
#define MPU6050_SDA     21
#define MPU6050_SCL     22

// ─── Shake detection parameters ─────────────────────────────────────────────
#define SHAKE_GYRO_THRESH       300.0f   // deg/s — minimum ω_mag for a shake
#define SHAKE_HALF_CYCLES_REQ   10       // half-cycles to dismiss alarm
#define SHAKE_WINDOW_MS         4000     // sliding window in ms
#define SHAKE_REVERSAL_MAX_MS   300      // max time between sign reversals

// ─── Raw and converted readings ─────────────────────────────────────────────
static float motion_ax = 0, motion_ay = 0, motion_az = 0;    // accel in g
static float motion_gx = 0, motion_gy = 0, motion_gz = 0;    // gyro in °/s
static float motion_temp = 0;                                  // MPU temp in °C

// ─── Shake detection state ──────────────────────────────────────────────────
// Circular buffer of shake half-cycle timestamps
#define SHAKE_BUF_SIZE 20
static uint32_t shakeTimestamps[SHAKE_BUF_SIZE];
static uint8_t  shakeWriteIdx     = 0;
static uint8_t  shakeTotalLogged  = 0;   // total ever logged (for counting in window)

// Sign-reversal tracking on dominant axis
static float    lastDominantSign  = 0;
static uint32_t lastReversalTime  = 0;
static bool     aboveThreshold    = false;
static bool     alarmDismissed    = false;

// ─── I2C helpers (same pattern as mpu6050_acc_gyro.ino) ─────────────────────

static void mpu_write_reg(byte reg, byte value) {
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(reg);
  Wire.write(value);
  Wire.endTransmission();
}

static int16_t mpu_read16(byte reg) {
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(reg);
  Wire.endTransmission(false);

  Wire.requestFrom((uint8_t)MPU6050_ADDR, (uint8_t)2);
  if (Wire.available() < 2) return 0;

  uint16_t value = (uint16_t)Wire.read() << 8;
  value |= Wire.read();
  return (int16_t)value;
}

// ─── Burst read: read 14 bytes (accel XYZ + temp + gyro XYZ) in one shot ───
static void mpu_read_all() {
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(0x3B);  // start at ACCEL_XOUT_H
  Wire.endTransmission(false);

  Wire.requestFrom((uint8_t)MPU6050_ADDR, (uint8_t)14);
  if (Wire.available() < 14) return;

  int16_t axRaw = (int16_t)((Wire.read() << 8) | Wire.read());
  int16_t ayRaw = (int16_t)((Wire.read() << 8) | Wire.read());
  int16_t azRaw = (int16_t)((Wire.read() << 8) | Wire.read());
  int16_t tmpRw = (int16_t)((Wire.read() << 8) | Wire.read());
  int16_t gxRaw = (int16_t)((Wire.read() << 8) | Wire.read());
  int16_t gyRaw = (int16_t)((Wire.read() << 8) | Wire.read());
  int16_t gzRaw = (int16_t)((Wire.read() << 8) | Wire.read());

  motion_ax   = axRaw / 16384.0f;
  motion_ay   = ayRaw / 16384.0f;
  motion_az   = azRaw / 16384.0f;
  motion_gx   = gxRaw / 131.0f;
  motion_gy   = gyRaw / 131.0f;
  motion_gz   = gzRaw / 131.0f;
  motion_temp = tmpRw / 340.0f + 36.53f;
}

// ─── Initialisation ─────────────────────────────────────────────────────────
/**
 * Call once from setup() AFTER Wire.begin(SDA, SCL).
 */
inline void motion_init() {
  // Wake up MPU6050 (clear sleep bit in PWR_MGMT_1)
  mpu_write_reg(0x6B, 0x00);
  delay(100);

  // Optional: set gyro range to ±500°/s for better shake detection
  // Register 0x1B, value 0x08 = ±500°/s (divide raw by 65.5)
  // For now keep ±250°/s (default, divide by 131.0) as per reference sketch

  // Clear shake state
  memset(shakeTimestamps, 0, sizeof(shakeTimestamps));
  shakeWriteIdx    = 0;
  shakeTotalLogged = 0;
  lastDominantSign = 0;
  lastReversalTime = 0;
  aboveThreshold   = false;
  alarmDismissed   = false;

  Serial.println("[MOT] MPU6050 initialised");
}

// ─── Read sensors (call at 50 Hz = every 20 ms) ────────────────────────────
/**
 * Reads all 6 axes plus temperature in a single I2C burst.
 */
inline void motion_read() {
  mpu_read_all();
}

// ─── Shake detection (call after motion_read) ──────────────────────────────
/**
 * Processes the latest gyro readings for shake half-cycle detection.
 * Returns the number of valid shakes within the 4-second window.
 *
 * A shake half-cycle is logged when:
 *   1. ω_mag ≥ SHAKE_GYRO_THRESH
 *   2. The dominant gyro axis has reversed sign since the last crossing
 *   3. The reversal happened within SHAKE_REVERSAL_MAX_MS
 */
inline uint8_t motion_detect_shakes() {
  uint32_t now = millis();
  float omega_mag = sqrtf(motion_gx * motion_gx +
                          motion_gy * motion_gy +
                          motion_gz * motion_gz);

  if (omega_mag >= SHAKE_GYRO_THRESH) {
    // Find the dominant axis
    float absGx = fabsf(motion_gx);
    float absGy = fabsf(motion_gy);
    float absGz = fabsf(motion_gz);

    float dominantVal;
    if (absGx >= absGy && absGx >= absGz)      dominantVal = motion_gx;
    else if (absGy >= absGx && absGy >= absGz) dominantVal = motion_gy;
    else                                        dominantVal = motion_gz;

    float currentSign = (dominantVal >= 0) ? 1.0f : -1.0f;

    if (!aboveThreshold) {
      // First time crossing the threshold — record sign
      aboveThreshold   = true;
      lastDominantSign = currentSign;
      lastReversalTime = now;
    } else if (currentSign != lastDominantSign) {
      // Sign reversal detected
      uint32_t elapsed = now - lastReversalTime;

      if (elapsed <= SHAKE_REVERSAL_MAX_MS) {
        // Valid half-cycle! Log it
        shakeTimestamps[shakeWriteIdx] = now;
        shakeWriteIdx = (shakeWriteIdx + 1) % SHAKE_BUF_SIZE;
        if (shakeTotalLogged < 255) shakeTotalLogged++;
      }

      lastDominantSign = currentSign;
      lastReversalTime = now;
    }
  } else {
    aboveThreshold = false;
  }

  // Count shakes within the sliding window
  uint8_t count = 0;
  uint8_t entries = (shakeTotalLogged < SHAKE_BUF_SIZE)
                    ? shakeTotalLogged : SHAKE_BUF_SIZE;
  for (uint8_t i = 0; i < entries; i++) {
    if ((now - shakeTimestamps[i]) <= SHAKE_WINDOW_MS) {
      count++;
    }
  }

  return count;
}

/**
 * Reset the shake counter (call after alarm dismissal is handled).
 */
inline void motion_reset_shakes() {
  memset(shakeTimestamps, 0, sizeof(shakeTimestamps));
  shakeWriteIdx    = 0;
  shakeTotalLogged = 0;
  aboveThreshold   = false;
  alarmDismissed   = false;
}

// ─── Getters ────────────────────────────────────────────────────────────────
inline float motion_get_ax()   { return motion_ax;   }
inline float motion_get_ay()   { return motion_ay;   }
inline float motion_get_az()   { return motion_az;   }
inline float motion_get_gx()   { return motion_gx;   }
inline float motion_get_gy()   { return motion_gy;   }
inline float motion_get_gz()   { return motion_gz;   }
inline float motion_get_temp() { return motion_temp; }
inline bool  motion_is_alarm_dismissed() { return alarmDismissed; }

// Compute dynamic acceleration magnitude (gravity-removed)
inline float motion_get_dynamic_accel() {
  float mag = sqrtf(motion_ax * motion_ax +
                    motion_ay * motion_ay +
                    motion_az * motion_az);
  return fabsf(mag - 1.0f);   // subtract 1g (gravity)
}

#endif /* MOTION_H_ */
