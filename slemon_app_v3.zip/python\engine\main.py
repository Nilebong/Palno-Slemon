"""
main.py — Async Main Engine Orchestrator
Palno & Slemon Sleep Tracking System

Starts and coordinates all subsystems:
  - SerialBridge  : reads radar + temp from STM32
  - BLEClient     : receives HR/SpO2/motion from Palno ESP32
  - BreathEngine  : processes radar frames → breath count/BPM
  - SleepClassifier: classifies 30-second epochs
  - AlarmManager  : manages binaural beat alarm
  - DataLogger    : persists all data to SQLite
  - WebServer     : FastAPI dashboard on :8080

Run:
    python -m engine.main
"""

import asyncio
import logging
import signal
import time
from datetime import datetime
from typing import Optional

from engine.config import (
    ALARM_TARGET_TIME, ALARM_WINDOW_MIN,
    EPOCH_SECONDS,
)
from engine.serial_bridge    import SerialBridge
from engine.ble_client       import BLEClient
from engine.breath_engine    import ProductionBreathEngine
from engine.sleep_classifier import SleepClassifier
from engine.alarm_manager    import AlarmManager, ensure_audio_files
from engine.data_logger      import DataLogger

# Import web server (starts as sub-task)
from engine.web.server import create_app, start_web_server

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("engine.main")


class PalnoSleepEngine:
    """
    Central orchestrator. Wires together all subsystems via callbacks
    and an asyncio event loop.
    """

    def __init__(self):
        # ── Subsystem instances ───────────────────────────────────────────────
        self.data_logger      = DataLogger()
        self.breath_engine    = ProductionBreathEngine()
        self.sleep_classifier = SleepClassifier()
        self.alarm_manager    = AlarmManager()

        # BLE client (Palno ESP32)
        self.ble_client = BLEClient(
            on_biometrics = self._on_biometrics,
            on_motion     = self._on_motion,
            on_alarm      = self._on_alarm_event,
        )

        # Serial bridge (STM32 → Qualcomm)
        self.serial_bridge = SerialBridge(
            on_radar = self._on_radar,
            on_temp  = self._on_temp,
            on_event = self._on_stm32_event,
        )

        # ── Shared state (read by web server via shared reference) ────────────
        self.state = {
            # Radar
            "radar_state":     0,
            "mov_dist_cm":     0.0,
            "mov_energy":      0.0,
            # Breath
            "breath_count":    0,
            "breath_bpm":      0.0,
            "breath_intensity": 0.0,
            "disturbance":     0.0,
            "disturbance_colour": "GREEN",
            # HR / SpO2
            "hr":              -999,
            "hr_valid":        False,
            "spo2":            -999,
            "spo2_valid":      False,
            # Motion
            "accel_mag":       0.0,
            "gyro_mag":        0.0,
            # Temperature
            "room_temp_c":     None,
            # Sleep stage
            "sleep_stage":     "WAKE",
            "sleep_stage_num": 4,
            "cycle_count":     0,
            "sleep_score":     0,
            # Alarm
            "alarm_active":    False,
            "alarm_window_active": False,
            "time_to_alarm_min":   0,
            # Connectivity
            "ble_connected":   False,
            # Session
            "session_active":  False,
            "session_start":   None,
        }

        # ── Session tracking ──────────────────────────────────────────────────
        self._session_start_ts: Optional[float] = None
        self._running = False

        # ── Wire callbacks ────────────────────────────────────────────────────
        self.breath_engine.set_on_breath(self._on_breath_detected)
        self.sleep_classifier.set_on_epoch(self._on_epoch_classified)
        self.alarm_manager.set_on_dismissed(self._on_alarm_dismissed)

    # =========================================================================
    # RADAR / BREATH callbacks
    # =========================================================================

    def _on_radar(self, frame: dict):
        """Called at 20 Hz from SerialBridge with each parsed radar frame."""
        # Run breath engine
        result = self.breath_engine.update(frame)

        # Update shared state
        self.state.update({
            "radar_state":        frame.get("target_state", 0),
            "mov_dist_cm":        frame.get("mov_dist_cm",  0.0),
            "mov_energy":         frame.get("mov_energy",   0.0),
            "breath_count":       result["breath_count"],
            "breath_bpm":         result["breath_bpm"],
            "breath_intensity":   result["breath_intensity"],
            "disturbance":        result["disturbance"],
            "disturbance_colour": result["disturbance_colour"],
            "session_active":     result["session_active"],
        })

        # Feed classifier
        self.sleep_classifier.add_radar(result["disturbance"])
        self.sleep_classifier.ble_connected = self.state["ble_connected"]

        # Log to DB (batched)
        self.data_logger.log_radar(frame)

        # Check alarm window
        self._check_alarm_window()

        # Classifier tick
        epoch = self.sleep_classifier.tick()
        if epoch:
            self._on_epoch_classified(epoch)

    def _on_breath_detected(self, breath_num: int, bpm: float, intensity: float):
        """Called by BreathEngine each time a breath is detected."""
        ts = time.time()

        # Add breath interval to classifier
        if self.breath_engine._last_breath_ts > 0 and bpm > 0:
            interval_s = 60.0 / bpm
            self.sleep_classifier.add_breath_interval(interval_s)

        # Log breath event
        self.data_logger.log_breath_event(
            ts, breath_num, intensity,
            self.breath_engine._zero_gap, bpm,
        )

    # =========================================================================
    # TEMPERATURE callback
    # =========================================================================

    def _on_temp(self, frame: dict):
        temp_c = frame.get("temp_c")
        if temp_c is not None and temp_c != -999.0:
            self.state["room_temp_c"] = temp_c
            self.sleep_classifier.add_temperature(temp_c)
            self.data_logger.log_temperature(frame)
            self.lv_bridge.update_state(room_temp_c=temp_c)

    # =========================================================================
    # BIOMETRICS / MOTION callbacks (from BLE)
    # =========================================================================

    def _on_biometrics(self, data: dict):
        """Called ~1 Hz from BLEClient with HR/SpO2 data with physiological sanity filter."""
        raw_hr = data.get("hr", -999)
        raw_spo2 = data.get("spo2", -999)
        raw_hr_v = bool(data.get("hr_valid", False))
        raw_spo2_v = bool(data.get("spo2_valid", False))

        # Physiological Filter: human SpO2 is 70% to 100%
        if raw_spo2_v and (70 <= raw_spo2 <= 100):
            filtered_spo2 = int(raw_spo2)
            spo2_valid = True
        else:
            filtered_spo2 = self.state.get("spo2", 98)
            spo2_valid = False

        # Physiological Filter: human resting sleep HR is 40 to 180 BPM
        if raw_hr_v and (40 <= raw_hr <= 180):
            filtered_hr = int(raw_hr)
            hr_valid = True
        else:
            filtered_hr = self.state.get("hr", 68)
            hr_valid = False

        self.state.update({
            "hr":         filtered_hr,
            "hr_valid":   hr_valid,
            "spo2":       filtered_spo2,
            "spo2_valid": spo2_valid,
            "ble_connected": True,
        })

        hr_cls   = filtered_hr   if hr_valid   else None
        spo2_cls = filtered_spo2 if spo2_valid else None
        self.sleep_classifier.add_biometrics(hr_cls, spo2_cls)
        self.data_logger.log_biometrics(data)

        self.lv_bridge.update_state(
            hr_bpm    = filtered_hr,
            hr_valid  = int(hr_valid),
            spo2      = filtered_spo2,
            spo2_valid= int(spo2_valid),
            ble_connected = True,
        )

    def _on_motion(self, data: dict):
        """Called ~20 Hz from BLEClient with accel/gyro data."""
        import math
        ax, ay, az = data.get("ax",0), data.get("ay",0), data.get("az",1)
        gx, gy, gz = data.get("gx",0), data.get("gy",0), data.get("gz",0)

        dyn_accel = abs(math.sqrt(ax**2 + ay**2 + az**2) - 1.0)
        gyro_mag  = math.sqrt(gx**2 + gy**2 + gz**2)

        self.state["accel_mag"] = round(dyn_accel, 4)
        self.state["gyro_mag"]  = round(gyro_mag,  2)

        self.sleep_classifier.add_motion(dyn_accel)
        self.data_logger.log_motion(data)
        self.lv_bridge.update_state(mpu_accel_mag=dyn_accel)

    def _on_alarm_event(self, event: str):
        """Called from BLEClient when Palno sends shake/dismiss events."""
        logger.info("[MAIN] BLE alarm event: %s", event)
        if "ALARM_DISMISSED" in event:
            self.alarm_manager.dismiss_alarm(source="shake")
        elif event.startswith("SHAKE:"):
            try:
                count = int(event.split(":")[1].split(",")[0])
                self.lv_bridge.update_state(mpu_shake_count=count)
            except ValueError:
                pass

    # =========================================================================
    # STM32 event callback
    # =========================================================================

    def _on_stm32_event(self, frame: dict):
        evt = frame.get("event_type", "")
        logger.info("[MAIN] STM32 event: %s | %s", evt, frame.get("detail",""))
        if evt == "SESSION_READY":
            self.data_logger.log_event("STM32_READY")

    # =========================================================================
    # EPOCH classification callback
    # =========================================================================

    def _on_epoch_classified(self, epoch: dict):
        """Called every 30 seconds when a sleep epoch is classified."""
        stage = epoch.get("stage", "WAKE")

        self.state.update({
            "sleep_stage":     stage,
            "sleep_stage_num": {"WAKE":4,"N1":3,"REM":2,"N2":1,"N3":0}.get(stage, 4),
            "cycle_count":     epoch.get("cycle_count", 0),
        })

        self.lv_bridge.update_state(
            sleep_stage         = stage,
            sleep_stage_numeric = self.state["sleep_stage_num"],
            cycle_count         = epoch.get("cycle_count", 0),
            resp_cov            = epoch.get("resp_cov")   or 0.0,
            hr_cov              = epoch.get("hr_cov")     or 0.0,
        )

        self.data_logger.log_sleep_epoch(epoch)

        # Stage-reactive audio
        self.alarm_manager.update_stage_audio(stage)

        # Send display update to STM32
        temp_c   = self.state.get("room_temp_c") or -999.0
        time_str = datetime.now().strftime("%H:%M")
        cmd = (
            f"CMD,DISPLAY,SLEEP,"
            f"{epoch.get('avg_resp_bpm') or 0:.1f},"
            f"{self.state['hr']},"
            f"{self.state['spo2']},"
            f"{temp_c:.1f},"
            f"{stage},"
            f"{time_str}"
        )
        asyncio.create_task(self.serial_bridge.send_command(cmd))

    # =========================================================================
    # ALARM WINDOW LOGIC
    # =========================================================================

    def _check_alarm_window(self):
        """Check if we're in the alarm window and stage is optimal."""
        now    = datetime.now()
        target = datetime.strptime(ALARM_TARGET_TIME, "%H:%M").replace(
            year=now.year, month=now.month, day=now.day
        )
        from datetime import timedelta
        window_start = target - timedelta(minutes=ALARM_WINDOW_MIN)

        in_window = window_start <= now <= target
        self.state["alarm_window_active"] = in_window

        mins_to_alarm = max(0, int((target - now).total_seconds() / 60))
        self.state["time_to_alarm_min"] = mins_to_alarm
        self.lv_bridge.update_state(
            alarm_window_active = in_window,
            time_to_alarm_min   = mins_to_alarm,
        )

        if (in_window
                and not self.alarm_manager.alarm_active
                and self.sleep_classifier.is_optimal_wake_stage()):
            logger.info("[MAIN] Optimal wake window! Firing alarm in stage: %s",
                        self.state["sleep_stage"])
            self.alarm_manager.start_alarm()
            self.state["alarm_active"] = True
            self.data_logger.log_event("ALARM_START",
                                        f"stage={self.state['sleep_stage']}")
            self.lv_bridge.update_state(alarm_active=True)

            # Arm ESP32 shake detection
            asyncio.create_task(self.ble_client.write_config("ALARM_ARM"))

            # Send alarm display to STM32
            score_cmd = (
                f"CMD,DISPLAY,ALARM,"
                f"{now.strftime('%H:%M')},"
                f"{self.state['sleep_score']}"
            )
            asyncio.create_task(self.serial_bridge.send_command(score_cmd))

        elif in_window and now >= target and not self.alarm_manager.alarm_active:
            # Deadline reached — fire alarm regardless of stage
            logger.warning("[MAIN] Alarm deadline reached — firing (stage: %s)",
                           self.state["sleep_stage"])
            self.alarm_manager.start_alarm()
            self.state["alarm_active"] = True

    def _on_alarm_dismissed(self, source: str):
        """Called when alarm is dismissed (shake or manual)."""
        logger.info("[MAIN] Alarm dismissed — source: %s", source)
        self.state["alarm_active"] = False
        self.lv_bridge.update_state(alarm_active=False)
        self.data_logger.log_event("ALARM_DISMISSED", f"source={source}")
        asyncio.create_task(self.ble_client.write_config("ALARM_DISARM"))

        # Generate morning summary
        if self._session_start_ts:
            summary = self.data_logger.get_night_summary(self._session_start_ts)
            score   = self.sleep_classifier.compute_sleep_score(
                self._session_start_ts, summary
            )
            self.state["sleep_score"] = score
            self.lv_bridge.update_state(sleep_score=score)
            self.data_logger.log_event("SESSION_END", f"score={score}")
            self.data_logger.export_csv()

            # Send summary to STM32 display
            dur    = summary.get("duration_min", 0)
            abr    = summary.get("avg_breath",   0.0) or 0.0
            ahr    = summary.get("avg_hr",       0)   or 0
            aspo2  = summary.get("avg_spo2",     0)   or 0
            mnT    = summary.get("min_temp",     0.0) or 0.0
            mxT    = summary.get("max_temp",     0.0) or 0.0
            cyc    = summary.get("cycle_count",  0)
            cmd = (
                f"CMD,DISPLAY,SUMMARY,"
                f"{dur},{score},{abr:.1f},{ahr},{aspo2},"
                f"{mnT:.1f},{mxT:.1f},{cyc}"
            )
            asyncio.create_task(self.serial_bridge.send_command(cmd))

    # =========================================================================
    # STARTUP
    # =========================================================================

    async def start(self):
        """Initialise all subsystems and launch async tasks."""
        logger.info("╔══════════════════════════════════════════════╗")
        logger.info("║  Palno & Slemon — Sleep Engine Starting      ║")
        logger.info("╚══════════════════════════════════════════════╝")

        # Pre-generate audio files if missing
        ensure_audio_files()

        # Session start
        self._session_start_ts = time.time()
        self.data_logger.log_event("SESSION_START")

        # Enable stage-reactive sleep audio (optional — change in config)
        self.alarm_manager.enable_sleep_audio(False)   # off by default

        # Launch all concurrent tasks
        tasks = [
            asyncio.create_task(self.data_logger.run(),      name="data_logger"),
            asyncio.create_task(self.serial_bridge.run(),    name="serial_bridge"),
            asyncio.create_task(self.ble_client.run(),       name="ble_client"),
            asyncio.create_task(start_web_server(self.state, self), name="web_server"),
        ]

        logger.info("[MAIN] All subsystems launched")
        logger.info("[MAIN] Web dashboard:  http://0.0.0.0:8080")

        # Wait for all tasks (run forever until SIGINT)
        try:
            await asyncio.gather(*tasks)
        except asyncio.CancelledError:
            pass
        finally:
            await self.stop()

    async def stop(self):
        """Graceful shutdown."""
        logger.info("[MAIN] Shutting down...")
        self.alarm_manager.stop_all()
        await self.ble_client.stop()
        await self.serial_bridge.stop()
        await self.data_logger.stop()
        logger.info("[MAIN] Shutdown complete")


# =============================================================================
# ENTRY POINT
# =============================================================================

async def _main():
    engine = PalnoSleepEngine()

    loop = asyncio.get_event_loop()

    def _shutdown():
        logger.info("[MAIN] SIGINT received — stopping")
        for task in asyncio.all_tasks(loop):
            task.cancel()

    loop.add_signal_handler(signal.SIGINT,  _shutdown)
    loop.add_signal_handler(signal.SIGTERM, _shutdown)

    await engine.start()


if __name__ == "__main__":
    asyncio.run(_main())
