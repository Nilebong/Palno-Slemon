"""
sleep_classifier.py — 30-Second Epoch Sleep Stage Classifier
Palno & Slemon Sleep Tracking System

Implements the rule-based hierarchical classifier from the sleep stage plan:
  Wake → Sleep → NREM/REM → N1/N2/N3

Uses features from all available sensors per 30-second epoch.
Applies 5-epoch majority-vote smoothing and transition legality filter.
"""

import collections
import logging
import math
import time
from typing import Optional

from engine.config import (
    EPOCH_SECONDS,
    WAKE_DISTURBANCE_THRESH, WAKE_ACCEL_THRESH, WAKE_MOTION_RATIO,
    RESP_REGULARITY_SPLIT,
    REM_SCORE_THRESH, REM_TWITCH_ACCEL_THRESH, REM_TWITCH_DURATION_MAX_S,
    N3_DEPTH_THRESH, RESP_COV_DEEP,
    SMOOTHING_WINDOW_EPOCHS, SLEEP_CYCLE_MIN,
)

logger = logging.getLogger(__name__)

# Transition legality table: stage → set of legal next stages
LEGAL_TRANSITIONS = {
    "WAKE":  {"WAKE", "N1"},
    "N1":    {"N1", "N2", "WAKE"},
    "N2":    {"N2", "N3", "REM", "WAKE"},
    "N3":    {"N3", "N2"},
    "REM":   {"REM", "N1", "WAKE"},
}

# Numeric mapping for hypnogram display
STAGE_NUMERIC = {"WAKE": 4, "N1": 3, "REM": 2, "N2": 1, "N3": 0}


class EpochBuffer:
    """
    Accumulates sensor samples over a 30-second window and computes
    aggregate features at the end of each epoch.
    """

    def __init__(self):
        self.start_ts  = time.time()
        self.samples   = 0

        # Disturbance
        self._dist:     list = []

        # MPU motion
        self._dyn_accel: list = []
        self._twitch_candidates: list = []   # (ts, dyn_accel) spikes

        # Heart rate
        self._hr:       list = []

        # SpO2
        self._spo2:     list = []

        # Temperature
        self._temp:     list = []

        # Respiration (populated by BreathEngine at breath events)
        self._breath_intervals: list = []    # seconds between breaths

    def add_radar(self, disturbance: float):
        self._dist.append(disturbance)
        self.samples += 1

    def add_motion(self, dyn_accel: float, ts: float):
        self._dyn_accel.append(dyn_accel)
        # Track potential twitches (short spikes)
        if dyn_accel >= REM_TWITCH_ACCEL_THRESH:
            self._twitch_candidates.append((ts, dyn_accel))

    def add_biometrics(self, hr: Optional[int], spo2: Optional[int]):
        if hr is not None and hr > 0:
            self._hr.append(float(hr))
        if spo2 is not None and spo2 > 0:
            self._spo2.append(float(spo2))

    def add_temperature(self, temp_c: float):
        if temp_c != -999.0:
            self._temp.append(temp_c)

    def add_breath_interval(self, interval_s: float):
        if 1.0 < interval_s < 30.0:
            self._breath_intervals.append(interval_s)

    def _mean(self, lst: list) -> Optional[float]:
        return (sum(lst) / len(lst)) if lst else None

    def _cov(self, lst: list) -> Optional[float]:
        """Coefficient of variation."""
        if len(lst) < 2:
            return None
        mean = sum(lst) / len(lst)
        if mean <= 0:
            return None
        var  = sum((v - mean) ** 2 for v in lst) / len(lst)
        return math.sqrt(var) / mean

    def _count_twitches(self) -> int:
        """
        Count isolated spikes (duration < REM_TWITCH_DURATION_MAX_S,
        separated by > 2 s of stillness) — characteristic of REM phasic activity.
        """
        if not self._twitch_candidates:
            return 0

        twitches = 0
        last_twitch_ts = -999.0
        for ts, val in sorted(self._twitch_candidates):
            gap = ts - last_twitch_ts
            if gap > 2.0:   # at least 2 s of stillness before spike
                twitches += 1
                last_twitch_ts = ts
        return twitches

    def extract_features(self) -> dict:
        """Compute all epoch features. Call at end of 30-second window."""
        end_ts = time.time()
        duration = end_ts - self.start_ts

        # Respiration features
        resp_bpms = [60.0 / t for t in self._breath_intervals if t > 0]
        mean_resp = self._mean(resp_bpms)
        resp_cov  = self._cov(resp_bpms)

        # HR features
        mean_hr  = self._mean(self._hr)
        hr_cov   = self._cov(self._hr)
        hr_trend = 0.0
        if len(self._hr) >= 4:
            n  = len(self._hr)
            xs = list(range(n))
            xm = sum(xs) / n
            ym = sum(self._hr) / n
            num  = sum((xs[i] - xm) * (self._hr[i] - ym) for i in range(n))
            denom = sum((xs[i] - xm) ** 2 for i in range(n))
            hr_trend = num / denom if denom != 0 else 0.0

        # Motion features
        mean_dist = self._mean(self._dist)
        max_dist  = max(self._dist) if self._dist else 0.0
        mean_dyn  = self._mean(self._dyn_accel)
        max_dyn   = max(self._dyn_accel) if self._dyn_accel else 0.0
        twitch_n  = self._count_twitches()

        # Motion fraction (fraction of samples with dyn_accel > WAKE_ACCEL_THRESH)
        motion_frac = (
            sum(1 for v in self._dyn_accel if v > WAKE_ACCEL_THRESH) / len(self._dyn_accel)
            if self._dyn_accel else 0.0
        )

        return {
            "epoch_start":   self.start_ts,
            "epoch_end":     end_ts,
            "duration_s":    duration,
            # Respiration
            "mean_resp_bpm": mean_resp,
            "resp_cov":      resp_cov,
            "breath_count":  len(resp_bpms),
            # Heart rate
            "mean_hr":       mean_hr,
            "hr_cov":        hr_cov,
            "hr_trend":      hr_trend,
            "hr_rising":     hr_trend > 0.05,
            # SpO2
            "mean_spo2":     self._mean(self._spo2),
            # Disturbance (radar)
            "mean_dist":     mean_dist,
            "max_dist":      max_dist,
            # MPU motion
            "mean_dyn_accel": mean_dyn,
            "max_dyn_accel":  max_dyn,
            "motion_frac":    motion_frac,
            "twitch_count":   twitch_n,
            # Temperature
            "room_temp":     self._mean(self._temp),
        }


class SleepClassifier:
    """
    Rule-based hierarchical sleep stage classifier.

    Call:
        classifier.add_*()          — add samples from each sensor
        classifier.tick(ts)         — called every second; returns epoch
                                      dict when a 30-s epoch is complete
        classifier.current_stage    — most recent smoothed stage label
        classifier.hypnogram        — list of (ts, stage) tuples
    """

    def __init__(self):
        self._epoch_buf   = EpochBuffer()
        self._last_tick   = time.time()

        # Raw classifications (before smoothing)
        self._raw_history: collections.deque = collections.deque(
            maxlen=SMOOTHING_WINDOW_EPOCHS
        )

        # Smoothed output
        self.current_stage   = "WAKE"
        self.prev_stage      = "WAKE"
        self.hypnogram:      list = []    # [(ts, stage), ...]
        self.epoch_count     = 0
        self.sleep_onset_ts: Optional[float] = None
        self.cycle_count     = 0

        # Personal calibration (learned after first 2 cycles)
        self._personal_hr_floor: Optional[float] = None
        self._hr_floor_samples:  list = []

        # BLE / motion connection flags (for degraded mode)
        self.ble_connected   = False

        # Callbacks
        self._on_epoch: Optional[callable] = None   # cb(epoch_dict)

    def set_on_epoch(self, callback: callable):
        """Register callback called when each 30-s epoch is classified."""
        self._on_epoch = callback

    # ─── Sample ingestion ────────────────────────────────────────────────────

    def add_radar(self, disturbance: float):
        self._epoch_buf.add_radar(disturbance)

    def add_motion(self, dyn_accel: float, ts: Optional[float] = None):
        self._epoch_buf.add_motion(dyn_accel, ts or time.time())

    def add_biometrics(self, hr: Optional[int], spo2: Optional[int]):
        self._epoch_buf.add_biometrics(hr, spo2)
        if hr and hr > 0:
            self._hr_floor_samples.append(float(hr))

    def add_temperature(self, temp_c: float):
        self._epoch_buf.add_temperature(temp_c)

    def add_breath_interval(self, interval_s: float):
        self._epoch_buf.add_breath_interval(interval_s)

    # ─── Tick (call every ~1 second from main loop) ──────────────────────────

    def tick(self, ts: Optional[float] = None) -> Optional[dict]:
        """
        Check if a full 30-second epoch has elapsed.
        If so, classify it and return the epoch dict. Otherwise returns None.
        """
        now = ts or time.time()
        elapsed = now - self._epoch_buf.start_ts

        if elapsed < EPOCH_SECONDS:
            return None

        # Extract features and classify
        features  = self._epoch_buf.extract_features()
        raw_stage = self._classify(features)

        # Apply smoothing + legality filter
        self._raw_history.append(raw_stage)
        smoothed = self._smooth_and_filter(raw_stage)

        # Track sleep onset + cycles.
        # A new sleep cycle begins whenever we emerge from a REM episode
        # (transition from REM to N1, N2, or WAKE after ≥1 REM epoch).
        if smoothed != "WAKE" and self.sleep_onset_ts is None:
            self.sleep_onset_ts = now
            logger.info("[CLASSIFIER] Sleep onset detected")

        if self.prev_stage == "REM" and smoothed in ("N1", "N2", "WAKE"):
            self.cycle_count += 1
            logger.info("[CLASSIFIER] Cycle %d detected (REM -> %s)", self.cycle_count, smoothed)

        self.prev_stage    = self.current_stage
        self.current_stage = smoothed
        self.epoch_count  += 1
        self.hypnogram.append((now, smoothed))

        # Calibrate personal HR floor
        self._calibrate_hr_floor()

        # Build epoch record
        epoch = {
            **features,
            "stage":         smoothed,
            "raw_stage":     raw_stage,
            "epoch_number":  self.epoch_count,
            "cycle_count":   self.cycle_count,
            "avg_resp_bpm":  features.get("mean_resp_bpm"),
            "resp_cov":      features.get("resp_cov"),
            "avg_hr":        features.get("mean_hr"),
            "hr_cov":        features.get("hr_cov"),
            "avg_spo2":      features.get("mean_spo2"),
            "disturbance":   features.get("mean_dist"),
            "mpu_motion":    features.get("mean_dyn_accel"),
        }

        logger.info("[CLASSIFIER] Epoch %d: %s (raw: %s) | resp=%.1f bpm | hr=%s",
                    self.epoch_count, smoothed, raw_stage,
                    features.get("mean_resp_bpm") or 0,
                    features.get("mean_hr") or "--")

        if self._on_epoch:
            self._on_epoch(epoch)

        # Reset buffer for next epoch
        self._epoch_buf = EpochBuffer()

        return epoch

    # ─── Decision tree ───────────────────────────────────────────────────────

    def _classify(self, f: dict) -> str:
        """Apply the hierarchical rule-based decision tree."""

        mean_dist  = f.get("mean_dist")   or 0.0
        motion_frac = f.get("motion_frac") or 0.0
        mean_dyn   = f.get("mean_dyn_accel") or 0.0
        resp_cov   = f.get("resp_cov")
        mean_resp  = f.get("mean_resp_bpm")
        mean_hr    = f.get("mean_hr")
        hr_cov     = f.get("hr_cov")
        hr_rising  = f.get("hr_rising",   False)
        twitch_n   = f.get("twitch_count", 0)
        breath_cnt = f.get("breath_count", 0)

        # ── Step 1: Wake detection ────────────────────────────────────────────
        if (mean_dist    >= WAKE_DISTURBANCE_THRESH or
                mean_dyn >= WAKE_ACCEL_THRESH       or
                motion_frac >= WAKE_MOTION_RATIO):
            return "WAKE"

        # ── Step 2: No-signal fallback ────────────────────────────────────────
        if breath_cnt < 2 and not self.ble_connected:
            return "WAKE"

        # ── Step 3: NREM vs REM split (respiratory regularity) ───────────────
        if resp_cov is None:
            # No breath data — use motion-only 3-class
            if mean_dyn < 0.01 and mean_dist < 10:
                return "N3"
            if mean_dyn < 0.05:
                return "N2"
            return "N1"

        if resp_cov > RESP_REGULARITY_SPLIT:
            # Irregular breathing → REM or N1
            return self._classify_rem_vs_n1(f)
        else:
            # Regular breathing → N2 or N3
            return self._classify_n2_vs_n3(f)

    def _classify_rem_vs_n1(self, f: dict) -> str:
        """Discriminate REM from N1 using weak-signal voting."""
        score = 0

        twitch_n    = f.get("twitch_count", 0)
        hr_cov      = f.get("hr_cov") or 0.0
        hr_rising   = f.get("hr_rising", False)
        mean_dist   = f.get("mean_dist") or 0.0
        mean_dyn    = f.get("mean_dyn_accel") or 0.0

        if twitch_n >= 2:          score += 2   # muscle twitches
        if hr_cov   > 0.04:        score += 1   # HR variability
        if hr_rising:              score += 1   # sympathetic surge
        if mean_dist < 10.0:       score += 1   # body very still (REM atonia)
        if mean_dyn  < 0.02:       score += 1   # absolute stillness

        # Timing bonus: REM more likely after 60+ min of sleep
        if self.sleep_onset_ts:
            mins_asleep = (time.time() - self.sleep_onset_ts) / 60.0
            if mins_asleep > 60:   score += 1
            if mins_asleep > 120:  score += 1   # later cycles have more REM

        return "REM" if score >= REM_SCORE_THRESH else "N1"

    def _classify_n2_vs_n3(self, f: dict) -> str:
        """Discriminate N3 (deep) from N2 (light) using depth scoring."""
        score = 0

        mean_resp  = f.get("mean_resp_bpm") or 16.0
        resp_cov   = f.get("resp_cov")      or 0.1
        mean_hr    = f.get("mean_hr")
        hr_cov     = f.get("hr_cov")        or 0.0
        mean_dist  = f.get("mean_dist")     or 0.0
        mean_dyn   = f.get("mean_dyn_accel") or 0.0

        if mean_resp < 14.0:        score += 1
        if resp_cov  < RESP_COV_DEEP: score += 1

        # Use personal HR floor if calibrated, otherwise use absolute threshold
        if mean_hr is not None:
            floor = self._personal_hr_floor or 58.0   # default floor: typical resting HR
            if mean_hr <= floor:    score += 1

        if hr_cov > 0.06:           score += 1   # high HRV = parasympathetic
        if mean_dist < 5.0:         score += 1
        if mean_dyn  < 0.01:        score += 1

        # Stillness streak bonus
        recent = list(self._raw_history)[-5:]
        still_epochs = sum(1 for s in recent if s in ("N2", "N3"))
        if still_epochs >= 4:       score += 1

        return "N3" if score >= N3_DEPTH_THRESH else "N2"

    # ─── Smoothing ───────────────────────────────────────────────────────────

    def _smooth_and_filter(self, raw_stage: str) -> str:
        """
        1. 5-epoch majority vote.
        2. Transition legality enforcement with stage-stepping.

        If the majority-voted stage is not directly reachable from the current
        stage, we step one hop toward it via the legal transition graph rather
        than staying stuck forever.  This prevents the classifier from getting
        locked in WAKE when the patient has fallen asleep.

        Legal graph (from plan):
            WAKE  → {WAKE, N1}
            N1    → {N1, N2, WAKE}
            N2    → {N2, N3, REM, WAKE}
            N3    → {N3, N2}
            REM   → {REM, N1, WAKE}
        """
        history = list(self._raw_history)
        if not history:
            return raw_stage

        # Majority vote across the smoothing window
        counts = {}
        for s in history:
            counts[s] = counts.get(s, 0) + 1
        voted = max(counts, key=counts.get)

        # If the voted stage is directly reachable, return it
        legal = LEGAL_TRANSITIONS.get(self.current_stage, set())
        if voted in legal:
            return voted

        # Voted stage is illegal from current stage.
        # Step one hop toward the voted stage along the shortest legal path
        # rather than staying stuck.
        # Depth-order used to find the best intermediate.
        STEP_TOWARD = {
            # (current, target): best_intermediate
            ("WAKE",  "N2"):  "N1",
            ("WAKE",  "N3"):  "N1",
            ("WAKE",  "REM"): "N1",
            ("N1",   "N3"):   "N2",
            ("N1",   "REM"):  "N2",
            ("N3",   "WAKE"): "N2",
            ("N3",   "N1"):   "N2",
            ("N3",   "REM"):  "N2",
            ("REM",  "N2"):   "N1",
            ("REM",  "N3"):   "N1",
        }
        intermediate = STEP_TOWARD.get((self.current_stage, voted))
        if intermediate and intermediate in LEGAL_TRANSITIONS.get(self.current_stage, set()):
            return intermediate

        # Final fallback: stay in current stage
        return self.current_stage

    # ─── Personal HR calibration ─────────────────────────────────────────────

    def _calibrate_hr_floor(self):
        """After 2 cycles (~3 hours), set personal HR floor to 5th percentile."""
        if self._personal_hr_floor is not None:
            return
        if self.cycle_count >= 2 and len(self._hr_floor_samples) >= 60:
            vals = sorted(self._hr_floor_samples)
            p5   = vals[max(0, int(len(vals) * 0.05))]
            self._personal_hr_floor = p5
            logger.info("[CLASSIFIER] Personal HR floor calibrated: %.1f bpm", p5)

    # ─── Optimal wake evaluation ─────────────────────────────────────────────

    def is_optimal_wake_stage(self) -> bool:
        """Returns True if current stage is ideal for waking (N1 or N2)."""
        return self.current_stage in ("N1", "N2")

    # ─── Sleep score (computed at end of session) ─────────────────────────────

    def compute_sleep_score(self, session_start_ts: float,
                             summary: dict) -> int:
        """
        Compute 0–100 sleep quality score using weighted formula from plan.
        """
        from engine.config import (
            SCORE_W_DURATION, SCORE_W_EFFICIENCY, SCORE_W_DEEP,
            SCORE_W_CYCLES,   SCORE_W_WAKE_EVENTS,
            SCORE_TARGET_HOURS, SCORE_TARGET_N3_PCT,
            SCORE_TARGET_CYCLES, SCORE_WAKE_PENALTY,
        )

        dur_min     = summary.get("duration_min", 0)
        stage_cnts  = summary.get("stage_counts", {})
        cycle_cnt   = summary.get("cycle_count",  0)
        wake_events = stage_cnts.get("WAKE", 0)
        total_epochs = summary.get("total_epochs", 1) or 1

        target_min = SCORE_TARGET_HOURS * 60

        # Component scores (0–100 each)
        s_dur  = min(100.0, (dur_min / target_min) * 100)

        # Sleep efficiency: fraction of non-wake epochs
        non_wake = total_epochs - wake_events
        s_eff    = min(100.0, (non_wake / total_epochs) * 100)

        n3_frac  = stage_cnts.get("N3", 0) / total_epochs
        s_deep   = min(100.0, (n3_frac / SCORE_TARGET_N3_PCT) * 100)

        s_cycles = min(100.0, (cycle_cnt / SCORE_TARGET_CYCLES) * 100)

        s_wake   = max(0.0, 100.0 - SCORE_WAKE_PENALTY * wake_events)

        score = (
            SCORE_W_DURATION    * s_dur   +
            SCORE_W_EFFICIENCY  * s_eff   +
            SCORE_W_DEEP        * s_deep  +
            SCORE_W_CYCLES      * s_cycles +
            SCORE_W_WAKE_EVENTS * s_wake
        )

        return int(round(min(100, max(0, score))))

    def reset(self):
        """Reset for a new night."""
        self._epoch_buf      = EpochBuffer()
        self._raw_history.clear()
        self.current_stage   = "WAKE"
        self.prev_stage      = "WAKE"
        self.hypnogram.clear()
        self.epoch_count     = 0
        self.sleep_onset_ts  = None
        self.cycle_count     = 0
        self._personal_hr_floor  = None
        self._hr_floor_samples   = []
        logger.info("[CLASSIFIER] Reset for new session")
