/*******************************************************************************
 * ble_service.h — BLE GATT Service Definitions for Palno (ESP32)
 *
 * Defines UUIDs, characteristic handles, and helper functions for the
 * BLE GATT server that transmits biometric + motion data to Slemon.
 *
 * Service UUID: a1b2c3d4-e5f6-7890-abcd-ef1234567890
 * Characteristics:
 *   0001 - Biometrics (HR, SpO2)         Notify  @ 1 Hz
 *   0002 - Motion     (accel, gyro)      Notify  @ 20 Hz
 *   0003 - Alarm      (shake events)     Notify  on-event
 *   0004 - Config     (arm/disarm alarm) Write
 ******************************************************************************/
#ifndef BLE_SERVICE_H_
#define BLE_SERVICE_H_

#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

// ─── UUIDs ──────────────────────────────────────────────────────────────────
#define SERVICE_UUID              "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
#define CHAR_BIOMETRICS_UUID      "a1b2c3d4-e5f6-7890-abcd-ef1234560001"
#define CHAR_MOTION_UUID          "a1b2c3d4-e5f6-7890-abcd-ef1234560002"
#define CHAR_ALARM_UUID           "a1b2c3d4-e5f6-7890-abcd-ef1234560003"
#define CHAR_CONFIG_UUID          "a1b2c3d4-e5f6-7890-abcd-ef1234560004"

// ─── Globals (set during ble_init) ──────────────────────────────────────────
static BLEServer*         pServer          = nullptr;
static BLECharacteristic* pBiometricsChar  = nullptr;
static BLECharacteristic* pMotionChar      = nullptr;
static BLECharacteristic* pAlarmChar       = nullptr;
static BLECharacteristic* pConfigChar      = nullptr;
static bool               bleDeviceConnected    = false;
static bool               bleOldDeviceConnected = false;

// ─── Alarm state (written by Slemon via Config characteristic) ──────────────
static volatile bool alarmArmed = false;

// ─── Server Callbacks ───────────────────────────────────────────────────────
class PalnoServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* s) override {
    bleDeviceConnected = true;
    Serial.println("[BLE] Client connected successfully!");
  }
  void onDisconnect(BLEServer* s) override {
    bleDeviceConnected = false;
    Serial.println("[BLE] Client disconnected - restarting advertising");
    BLEDevice::startAdvertising();
  }
};

// ─── Config Characteristic Callbacks (Write from Slemon) ────────────────────
class ConfigCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic* pChar) override {
    String val = pChar->getValue().c_str();
    val.trim();
    Serial.print("[BLE] Config received: ");
    Serial.println(val);

    if (val == "ALARM_ARM") {
      alarmArmed = true;
      Serial.println("[BLE] Alarm ARMED");
    } else if (val == "ALARM_DISARM") {
      alarmArmed = false;
      Serial.println("[BLE] Alarm DISARMED");
    }
  }
};

// ─── Initialisation ─────────────────────────────────────────────────────────
/**
 * Call once from setup(). Initialises BLE, creates service and 4
 * characteristics, starts advertising.
 */
inline void ble_init(const char* deviceName = "Palno-ESP32") {
  BLEDevice::init(deviceName);

  pServer = BLEDevice::createServer();
  pServer->setCallbacks(new PalnoServerCallbacks());

  BLEService* pService = pServer->createService(SERVICE_UUID);

  // --- Biometrics (Notify, 1 Hz) ---
  pBiometricsChar = pService->createCharacteristic(
    CHAR_BIOMETRICS_UUID,
    BLECharacteristic::PROPERTY_NOTIFY
  );
  pBiometricsChar->addDescriptor(new BLE2902());

  // --- Motion (Notify, 20 Hz) ---
  pMotionChar = pService->createCharacteristic(
    CHAR_MOTION_UUID,
    BLECharacteristic::PROPERTY_NOTIFY
  );
  pMotionChar->addDescriptor(new BLE2902());

  // --- Alarm Events (Notify, on-event) ---
  pAlarmChar = pService->createCharacteristic(
    CHAR_ALARM_UUID,
    BLECharacteristic::PROPERTY_NOTIFY
  );
  pAlarmChar->addDescriptor(new BLE2902());

  // --- Config (Write from Slemon) ---
  pConfigChar = pService->createCharacteristic(
    CHAR_CONFIG_UUID,
    BLECharacteristic::PROPERTY_WRITE
  );
  pConfigChar->setCallbacks(new ConfigCallbacks());

  pService->start();

  BLEAdvertising* pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(SERVICE_UUID);
  pAdvertising->setScanResponse(true);
  pAdvertising->setMinPreferred(0x06);   // helps with iPhone connections
  pAdvertising->setMinPreferred(0x12);
  BLEDevice::startAdvertising();

  Serial.println("[BLE] GATT server started, advertising...");
  Serial.print("[BLE] Device Name: ");
  Serial.println(deviceName);
  Serial.print("[BLE] Device MAC Address: ");
  Serial.println(BLEDevice::getAddress().toString().c_str());
  Serial.print("[BLE] Service UUID: ");
  Serial.println(SERVICE_UUID);
}

// ─── Handle reconnection (call from loop) ───────────────────────────────────
inline void ble_handle_reconnect() {
  // If a device just disconnected, restart advertising after a short delay
  if (!bleDeviceConnected && bleOldDeviceConnected) {
    delay(500);
    BLEDevice::startAdvertising();
    Serial.println("[BLE] Restarting advertising...");
    bleOldDeviceConnected = false;
  }
  if (bleDeviceConnected && !bleOldDeviceConnected) {
    bleOldDeviceConnected = true;
  }
}

// ─── Notify helpers ─────────────────────────────────────────────────────────

/**
 * Send biometrics data: "HR:<bpm>,SPO2:<pct>,HR_V:<0|1>,SPO2_V:<0|1>"
 */
inline void ble_notify_biometrics(int32_t heartRate, int8_t hrValid,
                                   int32_t spo2,      int8_t spo2Valid) {
  if (!bleDeviceConnected) return;

  char buf[64];
  snprintf(buf, sizeof(buf), "HR:%ld,SPO2:%ld,HR_V:%d,SPO2_V:%d",
           (long)heartRate, (long)spo2, (int)hrValid, (int)spo2Valid);
  pBiometricsChar->setValue(buf);
  pBiometricsChar->notify();
}

/**
 * Send motion data:
 *   "AX:<g>,AY:<g>,AZ:<g>,GX:<d/s>,GY:<d/s>,GZ:<d/s>"
 */
inline void ble_notify_motion(float ax, float ay, float az,
                               float gx, float gy, float gz) {
  if (!bleDeviceConnected) return;

  char buf[96];
  snprintf(buf, sizeof(buf),
           "AX:%.3f,AY:%.3f,AZ:%.3f,GX:%.1f,GY:%.1f,GZ:%.1f",
           ax, ay, az, gx, gy, gz);
  pMotionChar->setValue(buf);
  pMotionChar->notify();
}

/**
 * Send alarm event (e.g. "SHAKE:10,ALARM_DISMISSED")
 */
inline void ble_notify_alarm(const char* event) {
  if (!bleDeviceConnected) return;

  pAlarmChar->setValue(event);
  pAlarmChar->notify();
  Serial.print("[BLE] Alarm event sent: ");
  Serial.println(event);
}

#endif /* BLE_SERVICE_H_ */
