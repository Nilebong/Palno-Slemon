"""
main.py — Slemon Arduino Uno Q Main Application
Palno & Slemon Sleep Tracking System

Dual-processor coordination:
- Qualcomm QRB2210 MPU (Linux):
    - Runs this Python application
    - Hosts Socket.IO Web UI on port 7000
    - Executes production breath detection algorithm
    - Executes 30-second epoch sleep stage classifier
    - Manages smart alarm and vitals telemetry
- STM32U585 MCU (Zephyr Sketch):
    - Handles real-time HLK-LD2410 mmWave radar over Serial2 (256000 baud)
    - Reads MAX30208 temperature sensor over I2C (addr 0x50)
    - Controls 3.5" 4-color E-ink display (GDEM035F51) over SPI
    - Communicates with MPU via Arduino_RouterBridge RPC
"""

import sys
import os
import time
import json
import math
import logging
import datetime
import threading
import collections
from typing import Optional, Dict, Any, List

# Ensure D-Bus system bus socket is correctly routed inside Docker container
_dbus_candidates = ["/app/system_bus_socket", "/var/run/dbus/system_bus_socket"]
try:
    import glob
    _dbus_candidates.extend(glob.glob("/home/arduino/ArduinoApps/*/system_bus_socket"))
except Exception:
    pass

for _dbus_path in _dbus_candidates:
    if os.path.exists(_dbus_path):
        os.environ["DBUS_SYSTEM_BUS_ADDRESS"] = f"unix:path={_dbus_path}"
        break

# Ensure local and repo paths are available for imports
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", ".."))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# Arduino Uno Q app framework (with mock fallback for offline/desktop development)
try:
    from arduino.app_utils import *
    from arduino.app_bricks.web_ui import WebUI
except ImportError:
    logger.warning("[APP] arduino.app_utils not found. Running in desktop mock mode.")
    class _MockBridge:
        @staticmethod
        def call(name, *args, **kwargs):
            return None
        @staticmethod
        def provide(name, fn):
            pass
    class _MockLeds:
        @staticmethod
        def set_led1_color(r, g, b): pass
        @staticmethod
        def set_led2_color(r, g, b): pass
    class _MockApp:
        @staticmethod
        def run():
            while True:
                time.sleep(1.0)
        @staticmethod
        def on_update(*args, **kwargs): pass
    class _MockWebUI:
        def on_message(self, *args, **kwargs): pass
        def send_message(self, *args, **kwargs): pass

    Bridge = _MockBridge()
    Leds = _MockLeds()
    App = _MockApp()
    WebUI = _MockWebUI

# Core subsystems
import asyncio
from engine.sleep_classifier import SleepClassifier
from engine.data_logger import DataLogger
from engine.alarm_manager import AlarmManager
from engine.ble_client import BLEClient
from engine.bluetooth_manager import (
    BluetoothManager, load_bluetooth_config, save_bluetooth_config
)
from engine.labview_bridge import LabVIEWBridge

bt_mgr = BluetoothManager()
lv_bridge = LabVIEWBridge(host="0.0.0.0", port=5005)
lv_bridge.start()

# ─── Configure Logging ────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("SlemonApp")

# ─── Configuration Constants ──────────────────────────────────────────────────
BREATH_BASELINE_DEFAULT    = 15.0     # Default energy noise floor (0-100)
BREATH_ADAPTIVE_WINDOW_S   = 60.0     # Rolling window for 10th-percentile baseline
BREATH_MIN_ZERO_GAP        = 15       # Minimum consecutive sub-baseline samples between breaths
BREATH_SATURATION_ENERGY   = 100.0    # Saturated moving energy (gross movement)
BREATH_DIST_REF_CM         = 100.0    # Distance normalization reference (cm)
BREATH_DIST_ALPHA          = 1.2      # Distance exponent
DISTURBANCE_BETA           = 0.6      # Moving energy weight vs gate energy
DISTURBANCE_YELLOW_THRESH  = 25.0
DISTURBANCE_RED_THRESH     = 70.0

POLL_INTERVAL_S            = 0.050    # 50 ms polling (20 Hz)
TEMP_POLL_INTERVAL_S       = 10.0     # Temperature read every 10 seconds
UI_PUSH_INTERVAL_S         = 0.100    # 100 ms telemetry push to browser (10 Hz)
EINK_REFRESH_INTERVAL_S    = 60.0     # Refresh e-ink every 60 seconds during sleep

# ─── WebUI Instance ───────────────────────────────────────────────────────────
ui = WebUI()


# ═══════════════════════════════════════════════════════════════════════════════
# Production Breath Detection Engine (Inline)
# ═══════════════════════════════════════════════════════════════════════════════
class InlineBreathEngine:
    """
    Production-grade contactless breath detection engine.
    - Continuous auto-presence arming (state > 0 for 2s)
    - Adaptive 10th-percentile noise-floor baseline
    - Distance-normalized breath intensity
    - Gross movement flagging (saturation at E=100)
    - Accurate BPM derived from breath-to-breath time deltas
    """

    STATE_WAITING  = "WAITING"
    STATE_ACTIVE   = "ACTIVE"
    STATE_MOVEMENT = "MOVEMENT"

    def __init__(self):
        self.state = self.STATE_WAITING
        self.session_active = False
        self.session_start_ts = 0.0

        # Breath counters & metrics
        self.breath_count = 0
        self.breath_bpm = 0.0
        self.breath_intensity = 0.0
        self.last_breath_ts = 0.0

        # Detection state
        self._zero_gap = 0
        self._above_baseline = False
        self._in_breath = False
        self.gross_movement = False

        # Adaptive baseline
        self.baseline = BREATH_BASELINE_DEFAULT
        self.manual_baseline_override: Optional[float] = None
        self._energy_history: collections.deque = collections.deque()

        # Auto-presence arming timer
        self._presence_ts = 0.0
        self._arm_duration_s = 2.0

        # Movement Disturbance index
        self.disturbance = 0.0
        self.disturbance_colour = "GREEN"
        self._dist_history: collections.deque = collections.deque(maxlen=20)

        # Recent breath intervals for variability
        self.breath_intervals: collections.deque = collections.deque(maxlen=20)

        # Callbacks
        self._on_breath_callback = None

    def set_on_breath(self, cb):
        self._on_breath_callback = cb

    def set_baseline_override(self, val: Optional[float]):
        if val is not None and val > 0:
            self.manual_baseline_override = float(val)
            self.baseline = float(val)
            logger.info("[BREATH] Manual baseline override set to %.1f", self.baseline)
        else:
            self.manual_baseline_override = None
            logger.info("[BREATH] Baseline set to auto-adaptive mode")

    def _update_adaptive_baseline(self, energy: float, now: float):
        if self.manual_baseline_override is not None:
            self.baseline = self.manual_baseline_override
            return

        self._energy_history.append((now, energy))
        cutoff = now - BREATH_ADAPTIVE_WINDOW_S
        while self._energy_history and self._energy_history[0][0] < cutoff:
            self._energy_history.popleft()

        if len(self._energy_history) >= 10:
            vals = sorted(v for _, v in self._energy_history)
            p10_idx = max(0, int(len(vals) * 0.10) - 1)
            self.baseline = max(5.0, vals[p10_idx])

    def _compute_disturbance(self, mov_energy: float, mg: List[float]) -> float:
        gate_mean = sum(mg) / len(mg) if mg else 0.0
        dist = DISTURBANCE_BETA * mov_energy + (1.0 - DISTURBANCE_BETA) * gate_mean
        self._dist_history.append(dist)
        avg_dist = sum(self._dist_history) / len(self._dist_history)
        return avg_dist

    def _classify_disturbance(self, d: float) -> str:
        if d >= DISTURBANCE_RED_THRESH:
            return "RED"
        if d >= DISTURBANCE_YELLOW_THRESH:
            return "YELLOW"
        return "GREEN"

    def _calc_intensity(self, energy: float, dist_cm: float) -> float:
        if dist_cm <= 0:
            dist_cm = BREATH_DIST_REF_CM
        ratio = dist_cm / BREATH_DIST_REF_CM
        base = max(1.0, self.baseline)
        return (energy * (ratio ** BREATH_DIST_ALPHA)) / base

    def update(self, frame: Dict[str, Any]) -> Dict[str, Any]:
        now = time.time()
        target_state = frame.get("target_state", 0)
        mov_energy = float(frame.get("mov_energy", 0.0))
        dist_cm = float(frame.get("mov_dist_cm", BREATH_DIST_REF_CM))
        mg = frame.get("mg", [0.0] * 9)

        mov_energy = min(100.0, max(0.0, mov_energy))

        # Update adaptive baseline when not saturated
        if mov_energy < BREATH_SATURATION_ENERGY:
            self._update_adaptive_baseline(mov_energy, now)

        # Disturbance calculation
        self.disturbance = self._compute_disturbance(mov_energy, mg)
        self.disturbance_colour = self._classify_disturbance(self.disturbance)

        # Saturation is flagged as gross movement
        self.gross_movement = (mov_energy >= BREATH_SATURATION_ENERGY)

        # State machine
        if self.state == self.STATE_WAITING:
            if target_state > 0 and not self.gross_movement:
                if self._presence_ts == 0.0:
                    self._presence_ts = now
                elif (now - self._presence_ts) >= self._arm_duration_s:
                    self.state = self.STATE_ACTIVE
                    self.session_active = True
                    self.session_start_ts = now
                    self.breath_count = 0
                    self.last_breath_ts = now
                    self._zero_gap = 0
                    self._in_breath = False
                    logger.info("[BREATH] Target presence verified. Sleep session ARMED!")
            else:
                self._presence_ts = 0.0

        elif self.state == self.STATE_ACTIVE:
            if self.gross_movement:
                self.state = self.STATE_MOVEMENT
                self._zero_gap = 0
                self._in_breath = False
            else:
                self._process_sample(mov_energy, dist_cm, now)

        elif self.state == self.STATE_MOVEMENT:
            if not self.gross_movement:
                self.state = self.STATE_ACTIVE
                self._zero_gap = 0

        return {
            "state": self.state,
            "session_active": self.session_active,
            "breath_count": self.breath_count,
            "breath_bpm": round(self.breath_bpm, 1),
            "breath_intensity": round(self.breath_intensity, 2),
            "baseline": round(self.baseline, 1),
            "disturbance": round(self.disturbance, 1),
            "disturbance_colour": self.disturbance_colour,
            "gross_movement": self.gross_movement
        }

    def _process_sample(self, energy: float, dist_cm: float, now: float):
        if energy > self.baseline:
            if not self._above_baseline:
                self._above_baseline = True
                if self._zero_gap >= BREATH_MIN_ZERO_GAP and not self._in_breath:
                    self._in_breath = True
                    self._register_breath(energy, dist_cm, now)
        else:
            self._above_baseline = False
            self._in_breath = False
            self._zero_gap += 1

    def _register_breath(self, energy: float, dist_cm: float, now: float):
        self.breath_count += 1
        self.breath_intensity = self._calc_intensity(energy, dist_cm)

        if self.last_breath_ts > 0.0:
            interval = now - self.last_breath_ts
            if 1.0 < interval < 30.0:
                self.breath_bpm = 60.0 / interval
                self.breath_intervals.append(interval)
                if self._on_breath_callback:
                    self._on_breath_callback(interval, self.breath_bpm)

        self.last_breath_ts = now
        self._zero_gap = 0

    def reset(self):
        self.state = self.STATE_WAITING
        self.session_active = False
        self.session_start_ts = 0.0
        self.breath_count = 0
        self.breath_bpm = 0.0
        self.breath_intensity = 0.0
        self.last_breath_ts = 0.0
        self._zero_gap = 0
        self._above_baseline = False
        self._in_breath = False
        self._presence_ts = 0.0
        self._dist_history.clear()
        self.breath_intervals.clear()
        logger.info("[BREATH] Engine session reset.")


# ═══════════════════════════════════════════════════════════════════════════════
# Application State & Managers
# ═══════════════════════════════════════════════════════════════════════════════
class SlemonAppManager:
    def __init__(self):
        self.breath_engine = InlineBreathEngine()
        self.sleep_classifier = SleepClassifier()

        # Connect breath events to sleep classifier
        self.breath_engine.set_on_breath(self._on_breath_event)

        # Core hardware & network subsystems
        self.data_logger = DataLogger()
        self.alarm_manager = AlarmManager()
        self.alarm_manager.set_on_dismissed(self._on_alarm_dismissed_cb)

        # BLE Client for Palno ESP32
        self.ble_client = BLEClient(
            on_biometrics = self._on_ble_biometrics,
            on_motion     = self._on_ble_motion,
            on_alarm      = self._on_ble_alarm,
        )

        # Environmental & Vitals Cache
        self.room_temp_c = 21.5
        self.heart_rate = 65
        self.hr_valid = False
        self.spo2 = 98
        self.spo2_valid = False

        # Sleep stages & hypnogram
        self.current_stage = "WAKE"
        self.cycle_count = 0
        self.sleep_score = 85
        self.hypnogram_records: List[Dict[str, Any]] = []

        # Alarm Configuration
        self.alarm_enabled = True
        self.alarm_time_str = "07:00"        # HH:MM
        self.alarm_window_min = 30           # Minutes before target for smart wake
        self.alarm_triggered = False
        self.alarm_testing = False
        self._shake_count = 0
        self._last_shake_ts = 0.0
        self.test_alarm_until = 0.0
        self.sleep_audio_enabled = True

        # Polling & Dispatch timers
        self.last_poll_ts = 0.0
        self.last_temp_ts = 0.0
        self.last_ui_push_ts = 0.0
        self.last_classifier_tick_ts = 0.0
        self.last_eink_update_ts = 0.0

        # Stats tracking for morning summary
        self.temp_readings: List[float] = []

        # Raw radar metrics cache (3 raw data points)
        self.last_radar_mov_dist = 0.0
        self.last_radar_mov_energy = 0.0
        self.last_radar_stat_energy = 0.0

        # Raw MPU6050 accelerometer cache
        self.last_accel_x = 0.0
        self.last_accel_y = 0.0
        self.last_accel_z = 1.0
        self.last_accel_mag = 0.0

    def _on_breath_event(self, interval_s: float, bpm: float):
        self.sleep_classifier.add_breath_interval(interval_s)
        try:
            self.data_logger.log_breath(interval_s, bpm, self.breath_engine.breath_intensity)
        except Exception:
            pass

    def _on_ble_biometrics(self, data: dict):
        raw_hr = data.get("hr", -999)
        raw_spo2 = data.get("spo2", -999)
        raw_hr_v = bool(data.get("hr_valid", False))
        raw_spo2_v = bool(data.get("spo2_valid", False))

        # ── Physiological Sanity Filter ─────────────────────────────
        # Filter SpO2: Human blood oxygen range is 70% to 100% (healthy is 94-99%).
        # Suppress -99, -999, 0, or disconnected sensor noise.
        if raw_spo2_v and (70 <= raw_spo2 <= 100):
            self.spo2 = int(raw_spo2)
            self.spo2_valid = True
        else:
            self.spo2_valid = False
            # Retain last clean valid SpO2 reading (defaults to 98% if no valid reading yet)

        # Filter Heart Rate: Plausible resting sleep range is 40 to 180 BPM.
        # Suppress -999, -99, 0, or optical motion spikes > 180 BPM.
        if raw_hr_v and (40 <= raw_hr <= 180):
            # Smooth optical flutter using Exponential Moving Average (30% new, 70% historical)
            if self.heart_rate >= 40:
                self.heart_rate = int(round(0.3 * raw_hr + 0.7 * self.heart_rate))
            else:
                self.heart_rate = int(raw_hr)
            self.hr_valid = True
        else:
            self.hr_valid = False

        self.sleep_classifier.add_biometrics(
            self.heart_rate if self.hr_valid else None,
            self.spo2 if self.spo2_valid else None
        )
        try:
            self.data_logger.log_biometrics(self.heart_rate, self.spo2, self.hr_valid, self.spo2_valid)
        except Exception:
            pass

    def _on_ble_motion(self, data: dict):
        ax = float(data.get("ax", 0.0))
        ay = float(data.get("ay", 0.0))
        az = float(data.get("az", 1.0))
        mag = math.sqrt(ax * ax + ay * ay + az * az)
        dyn_accel = abs(mag - 1.0)

        self.last_accel_x = ax
        self.last_accel_y = ay
        self.last_accel_z = az
        self.last_accel_mag = dyn_accel

        self.sleep_classifier.add_motion(dyn_accel)

        # Direct MPU6050 Hand Shake Detection for Alarm Dismissal (10 shakes)
        if self.alarm_triggered:
            now = time.time()
            if dyn_accel > 0.40:
                if (now - self._last_shake_ts) > 0.15:
                    self._shake_count += 1
                    self._last_shake_ts = now
                    logger.info("[ALARM] Hand shake detected: %d/10 (accel mag=%.2f)", self._shake_count, dyn_accel)
                    try:
                        ui.send_message("alarm_shake_progress", {"count": self._shake_count, "target": 10})
                    except Exception:
                        pass
                    if self._shake_count >= 10:
                        logger.info("[ALARM] 10 Hand shakes registered! SNOOZE / DISMISSING ALARM NOW!")
                        self._shake_count = 0
                        self.dismiss_alarm()
            elif (now - self._last_shake_ts) > 5.0 and self._shake_count > 0:
                self._shake_count = 0
        try:
            self.data_logger.log_motion(data)
        except Exception:
            pass

    def _on_ble_alarm(self, event_str: str):
        logger.info("[BLE] Alarm event notification from Palno: %s", event_str)
        if "SHAKE" in event_str or "DISMISS" in event_str:
            logger.info("[ALARM] MPU6050 shake-dismissal triggered from Palno ESP32!")
            self.dismiss_alarm()

    def _on_alarm_dismissed_cb(self):
        logger.info("[ALARM] AlarmManager dismissal callback acknowledged.")

    def set_alarm_config(self, time_str: str, window_min: int, enabled: bool = True):
        self.alarm_time_str = time_str
        self.alarm_window_min = max(5, min(60, int(window_min)))
        self.alarm_enabled = enabled
        logger.info("[ALARM] Configured: time=%s, window=%d min, enabled=%s",
                    self.alarm_time_str, self.alarm_window_min, self.alarm_enabled)

    def check_smart_alarm(self, now: float):
        if not self.alarm_enabled or self.alarm_triggered:
            return

        # Check test alarm timeout
        if self.alarm_testing:
            if now >= self.test_alarm_until:
                self.alarm_testing = False
                self.alarm_triggered = False
                self._stop_alarm_hardware()
                self._shake_count = 0
                try:
                    self.ble_client.disarm_alarm()
                except Exception:
                    pass
                logger.info("[ALARM] Test alarm ended.")
            return
        now_dt = datetime.datetime.now()
        try:
            target_h, target_m = map(int, self.alarm_time_str.split(":"))
        except Exception:
            return

        target_dt = now_dt.replace(hour=target_h, minute=target_m, second=0, microsecond=0)
        window_start_dt = target_dt - datetime.timedelta(minutes=self.alarm_window_min)

        # Smart wake logic: light sleep in window or deadline reached
        trigger = False
        if window_start_dt <= now_dt <= target_dt:
            if self.current_stage in ("N1", "N2", "WAKE"):
                trigger = True
                logger.info("[ALARM] Smart Wake triggered: user in %s during window!", self.current_stage)
        elif now_dt >= target_dt and now_dt < (target_dt + datetime.timedelta(minutes=10)):
            trigger = True
            logger.info("[ALARM] Deadline reached at %s. Triggering alarm!", self.alarm_time_str)

        if trigger:
            self.trigger_alarm()

    def trigger_alarm(self, is_test: bool = False, duration_s: float = 10.0):
        self.alarm_triggered = True
        now = time.time()
        time_str = datetime.datetime.now().strftime("%H:%M")

        if is_test:
            self.alarm_testing = True
            self.test_alarm_until = now + duration_s

        logger.info("[ALARM] >>> ALARM ACTIVE <<<")
        self._shake_count = 0
        self._last_shake_ts = 0.0
        try:
            self.ble_client.arm_alarm()
        except Exception as e:
            logger.warning("[BLE] Arm alarm failed: %s", e)

        # 1. Update web UI
        ui.send_message("alarm_triggered", {
            "time": time_str,
            "score": self.sleep_score,
            "is_test": is_test
        })

        # 2. STM32 alarm LED indicator
        try:
            Bridge.call("set_alarm_active", True)
        except Exception as e:
            logger.warning("Bridge set_alarm_active failed: %s", e)

        # 3. Qualcomm MPU LED red
        try:
            Leds.set_led1_color(True, False, False)
        except Exception:
            pass

        # 4. Update E-ink display with ALARM screen
        try:
            payload = json.dumps({"time": time_str, "score": self.sleep_score})
            Bridge.call("show_display", "ALARM", payload)
        except Exception as e:
            logger.warning("Bridge show_display ALARM failed: %s", e)

        # 5. Start binaural beat alarm audio playback
        try:
            self.alarm_manager.play_alarm()
        except Exception as e:
            logger.warning("[AUDIO] Could not start alarm audio: %s", e)

        # 6. Log alarm trigger event
        try:
            self.data_logger.log_event("ALARM_TRIGGERED", f"time={time_str},score={self.sleep_score},test={is_test}")
        except Exception:
            pass

    def dismiss_alarm(self):
        self.alarm_triggered = False
        self.alarm_testing = False
        self._stop_alarm_hardware()

        # Stop binaural beat alarm audio
        try:
            self.alarm_manager.dismiss()
        except Exception as e:
            logger.warning("[AUDIO] Could not stop alarm audio: %s", e)

        # Log alarm dismissed event
        try:
            self.data_logger.log_event("ALARM_DISMISSED", "user_or_palno_shake")
        except Exception:
            pass

        logger.info("[ALARM] Alarm dismissed.")

        # Show morning summary on E-ink
        self.show_morning_summary()

    def _stop_alarm_hardware(self):
        try:
            Bridge.call("set_alarm_active", False)
        except Exception as e:
            logger.warning("Bridge set_alarm_active(False) failed: %s", e)

        try:
            Leds.set_led1_color(False, True, False)  # Return to green
        except Exception:
            pass

    def calculate_sleep_score(self) -> int:
        if not self.hypnogram_records:
            return 80

        # Stage scoring
        counts = collections.Counter(r["stage"] for r in self.hypnogram_records)
        total = len(self.hypnogram_records)
        if total == 0:
            return 80

        pct_deep = (counts.get("N3", 0) / total) * 100
        pct_rem  = (counts.get("REM", 0) / total) * 100
        pct_wake = (counts.get("WAKE", 0) / total) * 100

        # Ideal: ~20% deep, ~20% REM, <10% wake
        score = 80.0
        score += min(10.0, pct_deep * 0.5)
        score += min(10.0, pct_rem * 0.5)
        score -= min(25.0, pct_wake * 0.8)
        return max(30, min(100, int(round(score))))

    def show_morning_summary(self):
        duration_min = 480
        if self.breath_engine.session_start_ts > 0:
            duration_min = int((time.time() - self.breath_engine.session_start_ts) / 60.0)

        min_t = min(self.temp_readings) if self.temp_readings else self.room_temp_c
        max_t = max(self.temp_readings) if self.temp_readings else self.room_temp_c

        # Sample up to 24 representative stage points for the e-ink visual hypnogram graph
        hypno_list = [r["stage"] for r in self.hypnogram_records]
        if not hypno_list:
            hypno_str = "W,N1,N2,N3,N3,N2,REM,N2,N3,N2,REM,N2,N3,N2,REM,N2,W"
        else:
            step = max(1, len(hypno_list) // 20)
            sampled = hypno_list[::step]
            hypno_str = ",".join(sampled[:24])

        summary_data = {
            "duration_min": duration_min,
            "score": self.sleep_score,
            "avg_breath": round(self.breath_engine.breath_bpm or 14.5, 1),
            "avg_hr": int(self.heart_rate or 65),
            "avg_spo2": int(self.spo2 or 98),
            "min_temp": round(min_t, 1),
            "max_temp": round(max_t, 1),
            "cycles": self.cycle_count,
            "hypnogram": hypno_str
        }

        def _do_summary():
            try:
                Bridge.call("show_display", "SUMMARY", json.dumps(summary_data))
            except Exception as e:
                logger.warning("Bridge show_display SUMMARY failed: %s", e)
        threading.Thread(target=_do_summary, daemon=True).start()

    def refresh_sleep_eink(self):
        time_str = datetime.datetime.now().strftime("%H:%M")
        data = {
            "bpm": round(self.breath_engine.breath_bpm, 1),
            "hr": int(self.heart_rate),
            "spo2": int(self.spo2),
            "temp": round(self.room_temp_c, 1),
            "stage": self.current_stage,
            "time": time_str,
            "hr_valid": self.hr_valid,
            "spo2_valid": self.spo2_valid
        }
        def _do_eink():
            try:
                Bridge.call("show_display", "SLEEP", json.dumps(data))
                logger.info("[EINK] Sleep screen refreshed (%s)", time_str)
            except Exception as e:
                logger.warning("Bridge show_display SLEEP failed: %s", e)
        threading.Thread(target=_do_eink, daemon=True).start()

    def get_telemetry_payload(self, now: float) -> dict:
        return {
            "ts": now,
            "clock": datetime.datetime.now().strftime("%H:%M:%S"),
            "breath_bpm": round(self.breath_engine.breath_bpm, 1),
            "breath_count": self.breath_engine.breath_count,
            "breath_intensity": round(self.breath_engine.breath_intensity, 2),
            "baseline": round(self.breath_engine.baseline, 1),
            "heart_rate": int(self.heart_rate),
            "hr_valid": self.hr_valid,
            "spo2": int(self.spo2),
            "spo2_valid": self.spo2_valid,
            "temp_c": round(self.room_temp_c, 1),
            "disturbance": round(self.breath_engine.disturbance, 1),
            "disturbance_colour": self.breath_engine.disturbance_colour,
            "gross_movement": self.breath_engine.gross_movement,
            "stage": self.current_stage,
            "cycle_count": self.cycle_count,
            "sleep_score": self.sleep_score,
            "session_active": self.breath_engine.session_active,
            "alarm_active": self.alarm_triggered,
            "alarm_time": self.alarm_time_str,
            "alarm_window": self.alarm_window_min,
            # Raw radar metrics
            "radar_mov_dist": round(self.last_radar_mov_dist, 1),
            "radar_mov_energy": round(self.last_radar_mov_energy, 1),
            "radar_stat_energy": round(self.last_radar_stat_energy, 1),
            # Raw accelerometer metrics
            "accel_x": round(self.last_accel_x, 3),
            "accel_y": round(self.last_accel_y, 3),
            "accel_z": round(self.last_accel_z, 3),
            "ble_connected": self.ble_client.state.get("connected", False),
            "speaker_connected": bt_mgr.get_speaker_status().get("connected", False),
            "palno_mac": bt_mgr.get_palno_mac(),
            "speaker_mac": bt_mgr.get_speaker_mac(),
            "hypnogram": self.hypnogram_records[-40:] if self.hypnogram_records else []
        }

    def get_labview_payload(self, now: float) -> dict:
        """
        Generates a flat, strictly-typed telemetry JSON for NI LabVIEW Unflatten From JSON.
        Contains both standard and legacy field names (hr_bpm, room_temp_c, sleep_stage, etc.)
        guaranteeing immediate compatibility with LabVIEW Type Clusters.
        """
        stage_map = {"N3": 0, "N2": 1, "REM": 2, "N1": 3, "WAKE": 4}
        return {
            "ts": round(now, 2),
            "breath_bpm": round(self.breath_engine.breath_bpm, 1),
            "hr_bpm": int(self.heart_rate),
            "heart_rate": int(self.heart_rate),
            "hr_valid": int(self.hr_valid),
            "spo2": int(self.spo2),
            "spo2_valid": int(self.spo2_valid),
            "room_temp_c": round(self.room_temp_c, 2),
            "temp_c": round(self.room_temp_c, 2),
            "disturbance": round(self.breath_engine.disturbance, 1),
            "sleep_stage": self.current_stage,
            "stage": self.current_stage,
            "sleep_stage_numeric": stage_map.get(self.current_stage, 4),
            "alarm_active": bool(self.alarm_triggered),
            "ble_connected": bool(self.ble_client.state.get("connected", False)),
            "sleep_score": int(self.sleep_score),
            # Raw mmWave Radar metrics
            "radar_mov_dist": round(self.last_radar_mov_dist, 1),
            "radar_mov_energy": round(self.last_radar_mov_energy, 1),
            "radar_stat_energy": round(self.last_radar_stat_energy, 1),
            # Raw MPU6050 Accelerometer metrics
            "accel_x": round(self.last_accel_x, 3),
            "accel_y": round(self.last_accel_y, 3),
            "accel_z": round(self.last_accel_z, 3)
        }


app_mgr = SlemonAppManager()


# ═══════════════════════════════════════════════════════════════════════════════
# Web UI Event Handlers
# ═══════════════════════════════════════════════════════════════════════════════
def handle_set_alarm(client_id, message: dict = None):
    data = message if message is not None else (client_id if isinstance(client_id, dict) else {})
    time_str = data.get("time", "07:00")
    enabled = data.get("enabled", True)
    app_mgr.set_alarm_config(time_str, app_mgr.alarm_window_min, enabled)
    ui.send_message("alarm_status", {
        "time": app_mgr.alarm_time_str,
        "window": app_mgr.alarm_window_min,
        "enabled": app_mgr.alarm_enabled
    })

def handle_set_config(client_id, message: dict = None):
    data = message if message is not None else (client_id if isinstance(client_id, dict) else {})
    alarm_time = data.get("alarm_time", app_mgr.alarm_time_str)
    alarm_window = int(data.get("alarm_window", app_mgr.alarm_window_min))
    baseline_override = data.get("baseline", None)
    sleep_audio = data.get("sleep_audio", app_mgr.sleep_audio_enabled)

    app_mgr.set_alarm_config(alarm_time, alarm_window, True)
    app_mgr.sleep_audio_enabled = bool(sleep_audio)

    if baseline_override is not None and str(baseline_override).strip() != "":
        try:
            b_val = float(baseline_override)
            app_mgr.breath_engine.set_baseline_override(b_val)
        except ValueError:
            pass
    else:
        app_mgr.breath_engine.set_baseline_override(None)

    ui.send_message("config_applied", {"status": "ok"})

def handle_dismiss_alarm(client_id, message: dict = None):
    app_mgr.dismiss_alarm()
    ui.send_message("alarm_dismissed", {"status": "ok"})

def handle_test_alarm(client_id, message: dict = None):
    logger.info("[ALARM] Test alarm requested from WebUI")
    app_mgr.trigger_alarm(is_test=True, duration_s=10.0)

def handle_reset_session(client_id, message: dict = None):
    logger.info("[SESSION] Session reset requested from WebUI")
    app_mgr.breath_engine.reset()
    app_mgr.sleep_classifier = SleepClassifier()
    app_mgr.breath_engine.set_on_breath(app_mgr._on_breath_event)
    app_mgr.hypnogram_records.clear()
    app_mgr.current_stage = "WAKE"
    app_mgr.cycle_count = 0
    app_mgr.sleep_score = 85
    ui.send_message("session_reset", {"status": "ok"})

def handle_test_audio(client_id, message: dict = None):
    key = message.get("key", "wake_beta") if message else "wake_beta"
    logger.info("[AUDIO] WebUI test audio requested: %s", key)
    try:
        if key == "wake_beta":
            app_mgr.alarm_manager.start_alarm()
        elif key == "sleep_delta":
            app_mgr.alarm_manager._mpv.play("sleep_delta", 35.0)
        else:
            app_mgr.alarm_manager._mpv.play(key, 35.0)
        ui.send_message("audio_status", {"playing": True, "key": key})
    except Exception as e:
        logger.warning("[AUDIO] Play failed: %s", e)

def handle_stop_audio(client_id, message: dict = None):
    logger.info("[AUDIO] WebUI stop audio requested")
    try:
        app_mgr.alarm_manager.stop_all()
        ui.send_message("audio_status", {"playing": False})
    except Exception as e:
        logger.warning("[AUDIO] Stop failed: %s", e)

def handle_set_volume(client_id, message: dict = None):
    vol = float(message.get("volume", 50)) if message else 50.0
    logger.info("[AUDIO] WebUI set volume: %d%%", int(vol))
    try:
        app_mgr.alarm_manager.set_volume(vol)
        ui.send_message("volume_applied", {"volume": vol})
    except Exception as e:
        logger.warning("[AUDIO] Set volume failed: %s", e)

def handle_reconnect_ble(client_id, message: dict = None):
    mac = message.get("mac", "") if message else ""
    mac = mac.strip()
    logger.info("[BLE] Reconnect requested from WebUI, target MAC: %s", mac or "Auto-scan")
    if mac:
        bt_mgr.set_palno_mac(mac)
    app_mgr.ble_client.trigger_reconnect(mac)
    ui.send_message("ble_status", {
        "status": "scanning",
        "mac": mac or bt_mgr.get_palno_mac(),
        "connected": app_mgr.ble_client.state.get("connected", False)
    })

def handle_connect_speaker(client_id, message: dict = None):
    mac = message.get("mac", "") if message else ""
    mac = mac.strip().upper()
    logger.info("[AUDIO] WebUI connect A2DP speaker requested: %s", mac)
    if not mac:
        ui.send_message("speaker_status", {
            "connected": False,
            "message": "Please enter a valid Bluetooth Speaker MAC address."
        })
        return

    def _do_connect():
        res = bt_mgr.connect_a2dp_speaker(mac)
        ui.send_message("speaker_status", {
            "connected": res.get("success", False),
            "mac": mac,
            "sink": res.get("sink", ""),
            "message": res.get("message", "")
        })
    threading.Thread(target=_do_connect, daemon=True).start()

def handle_scan_bt_devices(client_id, message: dict = None):
    logger.info("[BT] WebUI scan for nearby Bluetooth devices requested")
    def _do_scan():
        devs = bt_mgr.scan_nearby_devices(scan_duration=6.0)
        ui.send_message("bt_devices_found", {"devices": devs})
    threading.Thread(target=_do_scan, daemon=True).start()

def handle_get_hw_config(client_id, message: dict = None):
    cfg = load_bluetooth_config()
    spk_status = bt_mgr.get_speaker_status()
    ui.send_message("hw_config", {
        "palno_mac": cfg.get("palno_mac", ""),
        "speaker_mac": cfg.get("speaker_mac", ""),
        "audio_mode": cfg.get("audio_mode", "bt"),
        "ble_connected": app_mgr.ble_client.state.get("connected", False),
        "speaker_connected": spk_status.get("connected", False),
        "speaker_sink": spk_status.get("sink", "")
    })

# Register WebUI events
ui.on_message("set_alarm", handle_set_alarm)
ui.on_message("set_config", handle_set_config)
ui.on_message("dismiss_alarm", handle_dismiss_alarm)
ui.on_message("test_alarm", handle_test_alarm)
ui.on_message("reset_session", handle_reset_session)
ui.on_message("test_audio", handle_test_audio)
ui.on_message("stop_audio", handle_stop_audio)
ui.on_message("set_volume", handle_set_volume)
ui.on_message("reconnect_ble", handle_reconnect_ble)
ui.on_message("connect_speaker", handle_connect_speaker)
ui.on_message("scan_bt_devices", handle_scan_bt_devices)
ui.on_message("get_hw_config", handle_get_hw_config)


# ═══════════════════════════════════════════════════════════════════════════════
# Main Polling & Processing Loop (50 ms / 20 Hz)
# ═══════════════════════════════════════════════════════════════════════════════
def poll_and_process():
    now = time.time()

    # ── 1. Poll mmWave Radar via RouterBridge ─────────────────────────────────
    radar_frame = None
    try:
        raw_radar_str = Bridge.call("get_radar_json")
        if raw_radar_str and isinstance(raw_radar_str, str) and raw_radar_str.startswith("{"):
            radar_frame = json.loads(raw_radar_str)
    except Exception as e:
        # Avoid flood logging
        pass

    if radar_frame and radar_frame.get("valid", False):
        app_mgr.last_radar_mov_dist = float(radar_frame.get("mov_dist_cm", 0.0))
        app_mgr.last_radar_mov_energy = float(radar_frame.get("mov_energy", 0.0))
        app_mgr.last_radar_stat_energy = float(radar_frame.get("sta_energy", 0.0))

        # Run production breath detection
        b_res = app_mgr.breath_engine.update(radar_frame)

        # Feed disturbance into sleep classifier buffer
        app_mgr.sleep_classifier.add_radar(b_res["disturbance"])

        # Persist radar frame to SQLite data log
        try:
            app_mgr.data_logger.log_radar(radar_frame)
        except Exception:
            pass

        # Update Qualcomm status LED color
        try:
            if b_res["gross_movement"]:
                Leds.set_led1_color(True, True, False)   # Yellow
            elif b_res["session_active"]:
                Leds.set_led1_color(False, True, False)  # Green
            else:
                Leds.set_led1_color(False, False, True)  # Blue
        except Exception:
            pass

    # ── 2. Poll MAX30208 Temperature every 10 seconds ─────────────────────────
    if (now - app_mgr.last_temp_ts) >= TEMP_POLL_INTERVAL_S:
        app_mgr.last_temp_ts = now
        try:
            temp_val = Bridge.call("get_temp")
            if temp_val is not None:
                t_float = float(temp_val)
                # Filter Room Temperature: Plausible room range is 10.0 °C to 42.0 °C
                # Suppress -999.0 °C, 0.0 °C, or disconnected sensor noise
                if 10.0 <= t_float <= 42.0:
                    app_mgr.room_temp_c = round(t_float, 2)
                    app_mgr.temp_readings.append(app_mgr.room_temp_c)
                    app_mgr.sleep_classifier.add_temperature(app_mgr.room_temp_c)
                    try:
                        app_mgr.data_logger.log_temp(app_mgr.room_temp_c)
                    except Exception:
                        pass
        except Exception as e:
            pass

    # ── 3. Tick Sleep Classifier (evaluates 30-second epochs) ──────────────────
    if (now - app_mgr.last_classifier_tick_ts) >= 1.0:
        app_mgr.last_classifier_tick_ts = now
        epoch = app_mgr.sleep_classifier.tick(now)
        if epoch:
            app_mgr.current_stage = epoch["stage"]
            app_mgr.cycle_count = epoch.get("cycle_count", app_mgr.cycle_count)
            app_mgr.sleep_score = app_mgr.calculate_sleep_score()

            rec = {
                "time": datetime.datetime.fromtimestamp(epoch["epoch_start"]).strftime("%H:%M"),
                "stage": epoch["stage"],
                "numeric": {"N3": 0, "N2": 1, "REM": 2, "N1": 3, "WAKE": 4}.get(epoch["stage"], 4)
            }
            app_mgr.hypnogram_records.append(rec)
            if len(app_mgr.hypnogram_records) > 240:
                app_mgr.hypnogram_records.pop(0)

            try:
                app_mgr.data_logger.log_epoch(epoch)
            except Exception:
                pass

            logger.info("[STAGE] New epoch classified: %s | Cycles: %d | Score: %d",
                        epoch["stage"], app_mgr.cycle_count, app_mgr.sleep_score)

        # Check smart alarm timing every second
        app_mgr.check_smart_alarm(now)

    # ── 4. Periodic E-ink Display Refresh (every 60s during active sleep) ──────
    if app_mgr.breath_engine.session_active and not app_mgr.alarm_triggered:
        if (now - app_mgr.last_eink_update_ts) >= EINK_REFRESH_INTERVAL_S:
            app_mgr.last_eink_update_ts = now
            app_mgr.refresh_sleep_eink()

    # Telemetry is handled by dedicated non-blocking telemetry_worker thread


# ═══════════════════════════════════════════════════════════════════════════════
# Dedicated Non-Blocking Telemetry & LabVIEW Worker (10 Hz)
# ═══════════════════════════════════════════════════════════════════════════════
def telemetry_worker():
    logger.info("[TELEMETRY] Dedicated 10 Hz telemetry and LabVIEW TCP broadcast started.")
    while True:
        try:
            now = time.time()
            telemetry_payload = app_mgr.get_telemetry_payload(now)
            ui.send_message("telemetry", telemetry_payload)

            labview_payload = app_mgr.get_labview_payload(now)
            lv_bridge.broadcast(labview_payload)
        except Exception as e:
            logger.warning("[TELEMETRY] Broadcast error: %s", e)
        time.sleep(UI_PUSH_INTERVAL_S)

telemetry_thread = threading.Thread(target=telemetry_worker, daemon=True)
telemetry_thread.start()

# ═══════════════════════════════════════════════════════════════════════════════
# Periodic Polling Worker Setup (STM32 Sensor Polling)
# ═══════════════════════════════════════════════════════════════════════════════
def polling_worker():
    logger.info("[WORKER] Background sensor polling loop started.")
    while True:
        try:
            poll_and_process()
        except Exception as e:
            logger.warning("[WORKER] Poll error: %s", e)
        time.sleep(POLL_INTERVAL_S)

# Start background thread for sensor polling
worker_thread = threading.Thread(target=polling_worker, daemon=True)
worker_thread.start()

# ═══════════════════════════════════════════════════════════════════════════════
# Async Background Worker: BLE Client (Palno ESP32)
# ═══════════════════════════════════════════════════════════════════════════════
def async_worker():
    logger.info("[ASYNC] Background asyncio loop starting for Palno BLE client...")
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    async def run_subsystems():
        t_ble = asyncio.create_task(app_mgr.ble_client.run())
        await asyncio.gather(t_ble, return_exceptions=True)

    try:
        loop.run_until_complete(run_subsystems())
    except Exception as e:
        logger.warning("[ASYNC] Subsystems loop exited: %s", e)

async_thread = threading.Thread(target=async_worker, daemon=True)
async_thread.start()

# ═══════════════════════════════════════════════════════════════════════════════
# Async Background Worker: Auto-Connect A2DP Speaker on Startup
# ═══════════════════════════════════════════════════════════════════════════════
def auto_connect_speaker_worker():
    time.sleep(4.0)  # Allow bt_host_agent and dbus proxy to initialize
    spk_mac = bt_mgr.get_speaker_mac() or "30:21:44:62:2C:58"
    if spk_mac:
        logger.info("[AUDIO] Initiating auto-connection to Bluetooth speaker: %s", spk_mac)
        res = bt_mgr.connect_a2dp_speaker(spk_mac)
        logger.info("[AUDIO] Startup speaker connection result: %s", res)

speaker_init_thread = threading.Thread(target=auto_connect_speaker_worker, daemon=True)
speaker_init_thread.start()

# Also register with App.on_update if supported by the runtime
try:
    App.on_update(poll_and_process, 50)
except TypeError:
    try:
        App.on_update(poll_and_process)
    except Exception:
        pass
except Exception:
    pass

# Show initial splash / IDLE display on E-ink
try:
    Bridge.call("show_display", "IDLE", json.dumps({"ip": "Uno Q", "ble": False}))
except Exception:
    pass

# Initialize Qualcomm LED to ready state
try:
    Leds.set_led1_color(False, False, True)  # Blue = Standby
except Exception:
    pass

logger.info("[INIT] Slemon Uno Q App Initialized. Starting App.run()...")

# ═══════════════════════════════════════════════════════════════════════════════
# Start Arduino Event Loop (MUST be the last line)
# ═══════════════════════════════════════════════════════════════════════════════
App.run()
