"""
ble_client.py — BLE GATT Subscriber for Palno ESP32 → Qualcomm (Python/bleak)

Connects to the Palno ESP32 BLE GATT server and subscribes to:
  - Biometrics characteristic (HR, SpO2) at ~1 Hz
  - Motion characteristic (accel, gyro) at ~20 Hz
  - Alarm characteristic (shake events, dismissal) on-event

Writes config commands to the Config characteristic (arm/disarm alarm).

Features:
  - Auto-reconnect with exponential backoff (5 s → 10 s → 20 s → 30 s max)
  - Thread-safe shared state dict updated on every notification
  - asyncio-native using bleak >= 0.21
  - Falls back gracefully when BLE is disconnected (engine uses radar-only mode)

Usage:
    from engine.ble_client import BLEClient
    client = BLEClient(on_biometrics=cb1, on_motion=cb2, on_alarm=cb3)
    asyncio.create_task(client.run())
"""

import asyncio
import logging
import time
from typing import Callable, Optional

try:
    from bleak import BleakClient, BleakScanner
    from bleak.exc import BleakError
    HAS_BLEAK = True
except ImportError:
    BleakClient = None
    BleakScanner = None
    BleakError = Exception
    HAS_BLEAK = False

from engine.config import (
    BLE_DEVICE_NAME, BLE_SERVICE_UUID,
    BLE_CHAR_BIOMETRICS, BLE_CHAR_MOTION,
    BLE_CHAR_ALARM, BLE_CHAR_CONFIG,
    BLE_RECONNECT_INITIAL_S, BLE_RECONNECT_MAX_S,
)

logger = logging.getLogger(__name__)


def _parse_biometrics(payload: str) -> dict:
    """
    Parse biometrics notification string.
    Expected format: "HR:68,SPO2:98,HR_V:1,SPO2_V:1"
    Returns dict with keys: hr, spo2, hr_valid, spo2_valid
    """
    result = {"hr": -999, "spo2": -999, "hr_valid": False, "spo2_valid": False}
    try:
        for part in payload.split(","):
            k, _, v = part.partition(":")
            k = k.strip()
            v = v.strip()
            if   k == "HR":      result["hr"]        = int(v)
            elif k == "SPO2":    result["spo2"]       = int(v)
            elif k == "HR_V":    result["hr_valid"]   = v == "1"
            elif k == "SPO2_V":  result["spo2_valid"] = v == "1"
    except Exception as e:
        logger.warning("Biometrics parse error: %s | payload: %r", e, payload)
    return result


def _parse_motion(payload: str) -> dict:
    """
    Parse motion notification string.
    Expected format: "AX:0.012,AY:-0.034,AZ:1.001,GX:1.2,GY:-0.5,GZ:0.3"
    Returns dict with keys: ax, ay, az, gx, gy, gz
    """
    result = {"ax": 0.0, "ay": 0.0, "az": 1.0,
              "gx": 0.0, "gy": 0.0, "gz": 0.0}
    try:
        for part in payload.split(","):
            k, _, v = part.partition(":")
            k = k.strip()
            result[k.lower()] = float(v.strip())
    except Exception as e:
        logger.warning("Motion parse error: %s | payload: %r", e, payload)
    return result


class BLEClient:
    """
    Manages the BLE connection to the Palno ESP32.

    Thread-safe state is exposed via the `state` dict:
        state["connected"]   → bool
        state["biometrics"]  → dict (hr, spo2, hr_valid, spo2_valid, ts)
        state["motion"]      → dict (ax, ay, az, gx, gy, gz, ts)
        state["alarm"]       → str | None (last alarm event string)
    """

    def __init__(
        self,
        on_biometrics: Optional[Callable[[dict], None]] = None,
        on_motion:     Optional[Callable[[dict], None]] = None,
        on_alarm:      Optional[Callable[[str],  None]] = None,
    ):
        self._on_biometrics = on_biometrics
        self._on_motion     = on_motion
        self._on_alarm      = on_alarm

        self.state = {
            "connected":   False,
            "biometrics":  {"hr": -999, "spo2": -999,
                            "hr_valid": False, "spo2_valid": False, "ts": 0.0},
            "motion":      {"ax": 0.0, "ay": 0.0, "az": 1.0,
                            "gx": 0.0, "gy": 0.0, "gz": 0.0, "ts": 0.0},
            "alarm":       None,
        }

        self._client:  Optional[BleakClient] = None
        self._address: Optional[str]         = None
        self._running  = False

    # ─── Notification handlers ────────────────────────────────────────────────

    def _handle_biometrics(self, _sender, data: bytearray):
        payload = data.decode("utf-8", errors="replace").strip()
        parsed  = _parse_biometrics(payload)
        parsed["ts"] = time.time()
        self.state["biometrics"] = parsed
        if self._on_biometrics:
            self._on_biometrics(parsed)

    def _handle_motion(self, _sender, data: bytearray):
        payload = data.decode("utf-8", errors="replace").strip()
        parsed  = _parse_motion(payload)
        parsed["ts"] = time.time()
        self.state["motion"] = parsed
        if self._on_motion:
            self._on_motion(parsed)

    def _handle_alarm(self, _sender, data: bytearray):
        payload = data.decode("utf-8", errors="replace").strip()
        self.state["alarm"] = payload
        logger.info("[BLE] Alarm event received: %s", payload)
        if self._on_alarm:
            self._on_alarm(payload)

    # ─── Device scanning ──────────────────────────────────────────────────────

    async def _scan_for_device(self) -> Optional[str]:
        """
        Scan for the Palno ESP32 by name.
        Returns BLE address string or None if not found within 10 seconds.
        """
        logger.info("[BLE] Scanning for '%s'...", BLE_DEVICE_NAME)
        try:
            device = await BleakScanner.find_device_by_name(
                BLE_DEVICE_NAME, timeout=10.0
            )
            if device:
                logger.info("[BLE] Found '%s' at %s", BLE_DEVICE_NAME, device.address)
                return device.address
        except BleakError as e:
            logger.error("[BLE] Scan error: %s", e)
        return None

    # ─── Connect + subscribe ──────────────────────────────────────────────────

    async def _connect_and_subscribe(self) -> bool:
        """
        Attempt one connection + subscription cycle.
        Returns True if successfully connected and subscribed.
        """
        if self._address is None:
            self._address = await self._scan_for_device()
        if self._address is None:
            return False

        try:
            self._client = BleakClient(
                self._address,
                disconnected_callback=self._on_disconnect_cb,
            )
            await self._client.connect()

            if not self._client.is_connected:
                return False

            # Subscribe to all three notify characteristics
            await self._client.start_notify(
                BLE_CHAR_BIOMETRICS, self._handle_biometrics
            )
            await self._client.start_notify(
                BLE_CHAR_MOTION, self._handle_motion
            )
            await self._client.start_notify(
                BLE_CHAR_ALARM, self._handle_alarm
            )

            self.state["connected"] = True
            logger.info("[BLE] Connected and subscribed to Palno")
            return True

        except BleakError as e:
            logger.warning("[BLE] Connection failed: %s", e)
            self._address = None    # rescan on next attempt
            return False

    def _on_disconnect_cb(self, _client):
        """Called by bleak when the remote device disconnects."""
        self.state["connected"] = False
        logger.warning("[BLE] Disconnected from Palno — will reconnect")

    # ─── Write config command to ESP32 ───────────────────────────────────────

    async def write_config(self, command: str):
        """
        Write a config command to the ESP32 Config characteristic.
        e.g. "ALARM_ARM", "ALARM_DISARM"
        """
        if not self._client or not self._client.is_connected:
            logger.warning("[BLE] Cannot write config — not connected")
            return
        try:
            await self._client.write_gatt_char(
                BLE_CHAR_CONFIG,
                command.encode("utf-8"),
                response=False,
            )
            logger.info("[BLE] Config written: %s", command)
        except BleakError as e:
            logger.error("[BLE] Config write failed: %s", e)

    # ─── Main run loop ────────────────────────────────────────────────────────

    async def run(self):
        """
        Persistent coroutine. Connects, maintains connection, and auto-reconnects
        with exponential backoff on disconnection or failure.

        Call as: asyncio.create_task(ble_client.run())
        """
        self._running  = True
        backoff        = BLE_RECONNECT_INITIAL_S

        if not HAS_BLEAK:
            logger.warning("[BLE] Bleak library not installed. BLE client running in dummy mode.")
            while self._running:
                await asyncio.sleep(10.0)
            return

        while self._running:
            connected = await self._connect_and_subscribe()

            if connected:
                backoff = BLE_RECONNECT_INITIAL_S   # reset backoff on success

                # Stay connected — poll the connection state every 2 seconds
                while self._running and self._client and self._client.is_connected:
                    await asyncio.sleep(2.0)

                # If we exit the inner loop, we've disconnected
                self.state["connected"] = False
                logger.warning("[BLE] Lost connection. Reconnecting in %ds...", backoff)

            else:
                logger.warning("[BLE] Connect attempt failed. Retrying in %ds...", backoff)

            # Wait with backoff before retrying
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, BLE_RECONNECT_MAX_S)

    async def stop(self):
        """Gracefully disconnect and stop the run loop."""
        self._running = False
        if self._client and self._client.is_connected:
            try:
                await self._client.disconnect()
            except BleakError:
                pass
        self.state["connected"] = False
        logger.info("[BLE] Client stopped")
