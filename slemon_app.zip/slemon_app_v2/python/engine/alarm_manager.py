"""
alarm_manager.py — Binaural Beat Audio Playback + Alarm Control
Palno & Slemon Sleep Tracking System

Responsibilities:
  1. Generate four binaural beat WAV files (delta/theta/alpha/beta)
     using numpy + scipy if they don't already exist in audio/
  2. Play, pause, stop audio via mpv subprocess
  3. Ramp volume from 10% to 60% over 2 minutes using mpv's IPC socket
  4. Crossfade alpha → beta after 3 minutes of alarm
  5. Fade to 0% on shake-dismiss or manual stop
  6. Stage-reactive background audio throughout the night (optional)

Audio chain: Python → mpv --ao=pulse → PulseAudio A2DP → Bluetooth speaker

Dependencies (on Uno Q Linux):
  pip install numpy scipy
  apt install mpv

Notes on Windows (dev): mpv must be in PATH, or set MPV_PATH in config.
  On Windows PulseAudio is not present; use --ao=wasapi for local testing.
"""

import asyncio
import json
import logging
import os
import struct
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Optional

import numpy as np

from engine.config import (
    AUDIO_DIR, AUDIO_FILES,
    AUDIO_SAMPLE_RATE, AUDIO_DURATION_S,
    AUDIO_CARRIER_L, AUDIO_CARRIER_R,
    AUDIO_START_VOL_PCT, AUDIO_MAX_VOL_PCT,
    AUDIO_RAMP_DURATION_S, AUDIO_CROSSFADE_S, AUDIO_FADE_OUT_S,
)

logger = logging.getLogger(__name__)

# ─── mpv IPC socket path ──────────────────────────────────────────────────────
MPV_SOCKET = "/tmp/palno_mpv.sock"      # Linux IPC socket
MPV_PATH   = os.environ.get("MPV_PATH", "mpv")   # override via env if needed


# =============================================================================
# WAV FILE GENERATION
# =============================================================================

def _write_wav(path: str, left: np.ndarray, right: np.ndarray, sample_rate: int):
    """Write a stereo 16-bit PCM WAV file."""
    # Interleave L and R channels
    stereo = np.empty((len(left) + len(right),), dtype=np.int16)
    stereo[0::2] = left
    stereo[1::2] = right

    num_samples   = len(left)
    num_channels  = 2
    bits_per_sample = 16
    byte_rate     = sample_rate * num_channels * bits_per_sample // 8
    block_align   = num_channels * bits_per_sample // 8
    data_size     = stereo.nbytes
    header_size   = 44

    with open(path, "wb") as f:
        # RIFF header
        f.write(b"RIFF")
        f.write(struct.pack("<I", header_size - 8 + data_size))
        f.write(b"WAVE")
        # fmt chunk
        f.write(b"fmt ")
        f.write(struct.pack("<I", 16))              # chunk size
        f.write(struct.pack("<H", 1))               # PCM format
        f.write(struct.pack("<H", num_channels))
        f.write(struct.pack("<I", sample_rate))
        f.write(struct.pack("<I", byte_rate))
        f.write(struct.pack("<H", block_align))
        f.write(struct.pack("<H", bits_per_sample))
        # data chunk
        f.write(b"data")
        f.write(struct.pack("<I", data_size))
        f.write(stereo.tobytes())


def generate_binaural_beat(
    filename: str,
    freq_l: float,
    freq_r: float,
    duration_s: int  = AUDIO_DURATION_S,
    sample_rate: int = AUDIO_SAMPLE_RATE,
    amplitude: float = 0.5,
) -> str:
    """
    Generate one binaural beat WAV file.

    Left ear:  pure sine at freq_l Hz
    Right ear: pure sine at freq_r Hz
    Beat frequency = |freq_r - freq_l| Hz (perceived in the brain)

    Returns the path to the written file.
    """
    os.makedirs(AUDIO_DIR, exist_ok=True)
    path = os.path.join(AUDIO_DIR, filename)

    logger.info(
        "[AUDIO] Generating %s (L=%.1f Hz, R=%.1f Hz, beat=%.1f Hz, %ds)...",
        filename, freq_l, freq_r, abs(freq_r - freq_l), duration_s,
    )

    t = np.linspace(0, duration_s, int(sample_rate * duration_s), endpoint=False)

    # Pure sine waves
    left_wave  = amplitude * np.sin(2 * np.pi * freq_l * t)
    right_wave = amplitude * np.sin(2 * np.pi * freq_r * t)

    # Gentle 1-second fade-in / fade-out to avoid clicks
    fade_samples = sample_rate   # 1 second
    fade_in  = np.linspace(0.0, 1.0, fade_samples)
    fade_out = np.linspace(1.0, 0.0, fade_samples)
    left_wave[:fade_samples]  *= fade_in
    left_wave[-fade_samples:] *= fade_out
    right_wave[:fade_samples]  *= fade_in
    right_wave[-fade_samples:] *= fade_out

    # Scale to int16 range
    left_i16  = (left_wave  * 32767).astype(np.int16)
    right_i16 = (right_wave * 32767).astype(np.int16)

    _write_wav(path, left_i16, right_i16, sample_rate)
    logger.info("[AUDIO] Written: %s (%.1f MB)", path,
                os.path.getsize(path) / 1e6)
    return path


def ensure_audio_files():
    """
    Check that all four binaural beat WAV files exist in audio/.
    Generate any that are missing. Called once at engine startup.
    """
    os.makedirs(AUDIO_DIR, exist_ok=True)
    for key, filename in AUDIO_FILES.items():
        path = os.path.join(AUDIO_DIR, filename)
        if os.path.exists(path):
            logger.info("[AUDIO] Found existing: %s", filename)
        else:
            generate_binaural_beat(
                filename,
                freq_l=AUDIO_CARRIER_L[key],
                freq_r=AUDIO_CARRIER_R[key],
            )


# =============================================================================
# MPV CONTROLLER
# =============================================================================

class MpvController:
    """
    Manages a single mpv subprocess with IPC socket for real-time volume control.

    mpv is launched with:
        mpv --no-video --loop --ao=pulse
            --input-ipc-server=<socket>
            --volume=<start_vol>
            <audio_file>

    Volume is controlled by sending JSON commands to the IPC socket.
    """

    def __init__(self):
        self._proc:    Optional[subprocess.Popen] = None
        self._current_file: Optional[str]         = None
        self._volume:  float                      = AUDIO_START_VOL_PCT

    def _build_mpv_cmd(self, audio_path: str, volume_pct: float) -> list:
        """Build the mpv command list."""
        # Detect OS: use wasapi on Windows for dev, pulse on Linux
        ao = "wasapi" if os.name == "nt" else "pulse"
        return [
            MPV_PATH,
            "--no-video",
            "--loop",
            f"--ao={ao}",
            f"--input-ipc-server={MPV_SOCKET}",
            f"--volume={int(volume_pct)}",
            audio_path,
        ]

    def _send_ipc(self, command: dict) -> bool:
        """Send a JSON command to mpv via IPC socket (Linux only)."""
        if os.name == "nt":
            # IPC socket not available on Windows — skip silently
            return True
        try:
            import socket
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.settimeout(1.0)
            sock.connect(MPV_SOCKET)
            msg = json.dumps(command) + "\n"
            sock.sendall(msg.encode())
            sock.close()
            return True
        except Exception as e:
            logger.debug("[AUDIO] IPC send failed: %s", e)
            return False

    def set_volume(self, pct: float):
        """Set mpv volume (0–100) via IPC."""
        pct = max(0.0, min(100.0, pct))
        self._volume = pct
        self._send_ipc({"command": ["set_property", "volume", pct]})

    def play(self, audio_key: str, volume_pct: Optional[float] = None):
        """
        Start or switch to an audio file.
        audio_key: one of 'sleep_delta', 'sleep_theta', 'wake_alpha', 'wake_beta'
        """
        if audio_key not in AUDIO_FILES:
            logger.error("[AUDIO] Unknown audio key: %s", audio_key)
            return

        audio_path = os.path.join(AUDIO_DIR, AUDIO_FILES[audio_key])
        if not os.path.exists(audio_path):
            logger.error("[AUDIO] File not found: %s", audio_path)
            return

        vol = volume_pct if volume_pct is not None else AUDIO_START_VOL_PCT

        # If already playing the same file, just adjust volume
        if (self._proc and self._proc.poll() is None
                and self._current_file == audio_key):
            self.set_volume(vol)
            return

        # Stop existing playback
        self.stop(fade=False)

        logger.info("[AUDIO] Playing %s at %d%%", AUDIO_FILES[audio_key], int(vol))
        cmd = self._build_mpv_cmd(audio_path, vol)

        try:
            self._proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            self._current_file = audio_key
            self._volume       = vol
        except FileNotFoundError:
            logger.error(
                "[AUDIO] mpv not found. Install mpv or set MPV_PATH env var."
            )

    def stop(self, fade: bool = True):
        """Stop playback. If fade=True, ramp volume to 0 first."""
        if self._proc and self._proc.poll() is None:
            if fade:
                # Quick fade to 0
                steps = 20
                step_vol = self._volume / steps
                for _ in range(steps):
                    self._volume = max(0.0, self._volume - step_vol)
                    self.set_volume(self._volume)
                    time.sleep(AUDIO_FADE_OUT_S / steps)

            self._proc.terminate()
            try:
                self._proc.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                self._proc.kill()

        self._proc         = None
        self._current_file = None
        self._volume       = 0.0
        logger.info("[AUDIO] Playback stopped")

    def is_playing(self) -> bool:
        return self._proc is not None and self._proc.poll() is None

    def current_volume(self) -> float:
        return self._volume


# =============================================================================
# ALARM MANAGER (High-level controller)
# =============================================================================

class AlarmManager:
    """
    High-level alarm and sleep-audio controller.

    Manages:
      - Background sleep audio (stage-reactive, optional)
      - Wake-up alarm sequence (alpha → beta ramp)
      - Volume ramping via asyncio task
      - Shake-dismiss handling
    """

    def __init__(self):
        self._mpv          = MpvController()
        self._alarm_active = False
        self._dismissed    = False
        self._ramp_task:   Optional[asyncio.Task] = None
        self._sleep_audio  = False   # enable stage-reactive night audio

        # Callbacks
        self._on_dismissed: Optional[callable] = None

    def set_on_dismissed(self, callback: callable):
        """Register a callback for when the alarm is shake-dismissed."""
        self._on_dismissed = callback

    def enable_sleep_audio(self, enabled: bool = True):
        """Enable or disable stage-reactive background audio during sleep."""
        self._sleep_audio = enabled

    # ─── Sleep-stage reactive audio ──────────────────────────────────────────

    def update_stage_audio(self, stage: str):
        """
        Adjust background audio based on current sleep stage.
        Only active when sleep_audio is enabled and no alarm is ringing.
        """
        if self._alarm_active or not self._sleep_audio:
            return

        stage_audio_map = {
            "WAKE":  ("sleep_theta", 15),   # help fall back asleep
            "N1":    ("sleep_theta", 10),
            "N2":    ("sleep_delta", 10),
            "N3":    ("sleep_delta",  5),
            "REM":   (None,           0),   # silence during REM
        }

        mapping = stage_audio_map.get(stage.upper())
        if mapping is None:
            return

        audio_key, vol = mapping
        if audio_key is None:
            self._mpv.stop(fade=True)
        else:
            self._mpv.play(audio_key, volume_pct=vol)

    # ─── Alarm sequence ───────────────────────────────────────────────────────

    async def _ramp_volume(self):
        """
        Coroutine: ramp volume from AUDIO_START_VOL_PCT to AUDIO_MAX_VOL_PCT
        over AUDIO_RAMP_DURATION_S seconds, then crossfade to beta.
        """
        try:
            start_vol  = float(AUDIO_START_VOL_PCT)
            target_vol = float(AUDIO_MAX_VOL_PCT)
            duration   = float(AUDIO_RAMP_DURATION_S)
            step_s     = 5.0   # update volume every 5 seconds
            steps      = int(duration / step_s)
            vol_step   = (target_vol - start_vol) / max(steps, 1)

            current_vol = start_vol
            self._mpv.set_volume(current_vol)

            for i in range(steps):
                if self._dismissed or not self._alarm_active:
                    return
                await asyncio.sleep(step_s)
                current_vol = min(target_vol, current_vol + vol_step)
                self._mpv.set_volume(current_vol)
                logger.debug("[AUDIO] Volume ramp: %.1f%%", current_vol)

            # Volume fully ramped — crossfade to beta track after CROSSFADE_S
            logger.info("[AUDIO] Volume at max; crossfading to wake_beta...")
            await asyncio.sleep(AUDIO_CROSSFADE_S)

            if not self._dismissed and self._alarm_active:
                self._mpv.play("wake_beta", volume_pct=target_vol)
                logger.info("[AUDIO] Now playing wake_beta at %.0f%%", target_vol)

        except asyncio.CancelledError:
            pass

    def start_alarm(self):
        """
        Begin the wake-up alarm sequence:
          1. Play wake_alpha at 10% volume
          2. Ramp volume to 60% over 2 minutes
          3. Crossfade to wake_beta
        """
        if self._alarm_active:
            return

        logger.info("[ALARM] Starting alarm sequence")
        self._alarm_active = True
        self._dismissed    = False

        # Stop any background sleep audio
        if self._mpv.is_playing():
            self._mpv.stop(fade=False)

        # Start with alpha track at low volume
        self._mpv.play("wake_alpha", volume_pct=AUDIO_START_VOL_PCT)

        # Launch async ramp task
        self._ramp_task = asyncio.create_task(self._ramp_volume())

    def dismiss_alarm(self, source: str = "shake"):
        """
        Dismiss the alarm: fade audio to 0, cancel ramp, fire callback.
        source: 'shake' | 'manual' | 'natural_wake'
        """
        if not self._alarm_active:
            return

        logger.info("[ALARM] Dismissed (source: %s)", source)
        self._dismissed    = True
        self._alarm_active = False

        # Cancel ramp task
        if self._ramp_task and not self._ramp_task.done():
            self._ramp_task.cancel()

        # Fade out and stop
        self._mpv.stop(fade=True)

        # Fire callback
        if self._on_dismissed:
            self._on_dismissed(source)

    def stop_all(self):
        """Hard stop everything (on engine shutdown)."""
        self._alarm_active = False
        self._dismissed    = True
        if self._ramp_task and not self._ramp_task.done():
            self._ramp_task.cancel()
        self._mpv.stop(fade=False)

    # ─── Properties ──────────────────────────────────────────────────────────

    @property
    def alarm_active(self) -> bool:
        return self._alarm_active

    @property
    def current_volume(self) -> float:
        return self._mpv.current_volume()


# =============================================================================
# CLI GENERATOR (standalone — run to pre-generate audio files)
# =============================================================================

if __name__ == "__main__":
    import sys
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")
    logger.info("Generating all binaural beat audio files...")
    ensure_audio_files()
    logger.info("Done. Files written to: %s", AUDIO_DIR)
    sys.exit(0)
