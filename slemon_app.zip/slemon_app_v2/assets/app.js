/**
 * app.js — Palno & Slemon WebUI Client
 * Connects via WebUI (Socket.IO) to the Arduino Uno Q Python backend.
 */

'use strict';

// ─── Constants & Stage Styling ────────────────────────────────────────────────
const MAX_CHART_POINTS = 60;      // Rolling window for signal charts (~6 seconds at 10Hz)
const MAX_HEATMAP_BARS = 180;     // Max bars shown in disturbance heatmap

const STAGE_CONFIG = {
  WAKE: { label: 'WAKE', className: 'stage-wake', color: '#8b949e', num: 4 },
  N1:   { label: 'N1',   className: 'stage-n1',   color: '#38bdf8', num: 3 },
  N2:   { label: 'N2',   className: 'stage-n2',   color: '#2563eb', num: 1 },
  N3:   { label: 'N3',   className: 'stage-n3',   color: '#1e3a8a', num: 0 },
  REM:  { label: 'REM',  className: 'stage-rem',  color: '#a855f7', num: 2 },
};

// ─── Initialize WebUI Client ──────────────────────────────────────────────────
const ui = new WebUI();

// ─── Chart.js Defaults ────────────────────────────────────────────────────────
Chart.defaults.color = '#8b949e';
Chart.defaults.borderColor = '#21262d';
Chart.defaults.font.family = "'Open Sans', -apple-system, sans-serif";

function createRollingChart(canvasId, label, color, yMin, yMax, unit = '') {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return null;

  return new Chart(ctx, {
    type: 'line',
    data: {
      labels: [],
      datasets: [{
        label: label,
        data: [],
        borderColor: color,
        backgroundColor: color + '22',
        borderWidth: 2,
        pointRadius: 0,
        tension: 0.3,
        fill: true,
      }]
    },
    options: {
      animation: false,
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (ctx) => `${ctx.parsed.y} ${unit}`
          }
        }
      },
      scales: {
        x: { display: false },
        y: {
          min: yMin,
          max: yMax,
          ticks: {
            font: { size: 10 },
            stepSize: (yMax - yMin) / 4
          },
          grid: { color: '#1f242c' }
        }
      }
    }
  });
}

function createMultiLineChart(canvasId, datasetsConfig, yMin, yMax, unit = '') {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return null;

  return new Chart(ctx, {
    type: 'line',
    data: {
      labels: [],
      datasets: datasetsConfig.map(cfg => ({
        label: cfg.label,
        data: [],
        borderColor: cfg.color,
        backgroundColor: cfg.color + '18',
        borderWidth: 2,
        pointRadius: 0,
        tension: 0.25,
        fill: cfg.fill !== undefined ? cfg.fill : false,
      }))
    },
    options: {
      animation: false,
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (ctx) => `${ctx.dataset.label}: ${ctx.parsed.y} ${unit}`
          }
        }
      },
      scales: {
        x: { display: false },
        y: {
          min: yMin,
          max: yMax,
          ticks: {
            font: { size: 10 },
            stepSize: (yMax - yMin) / 4
          },
          grid: { color: '#1f242c' }
        }
      }
    }
  });
}

function createHypnogramChart(canvasId) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return null;

  return new Chart(ctx, {
    type: 'line',
    data: {
      labels: [],
      datasets: [{
        label: 'Sleep Stage',
        data: [],
        borderColor: '#008184',
        backgroundColor: 'rgba(0, 129, 132, 0.15)',
        borderWidth: 2.5,
        stepped: true,
        fill: true,
        pointRadius: 3,
        pointBackgroundColor: [],
        tension: 0,
      }]
    },
    options: {
      animation: false,
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (ctx) => {
              const stages = ['N3 (Deep)', 'N2 (Light)', 'REM (Dream)', 'N1 (Drowsy)', 'WAKE'];
              const idx = Math.round(ctx.parsed.y);
              return stages[idx] || 'Unknown';
            }
          }
        }
      },
      scales: {
        x: {
          display: true,
          ticks: { maxTicksLimit: 8, font: { size: 9 }, color: '#6e7681' },
          grid: { display: false }
        },
        y: {
          min: -0.5,
          max: 4.5,
          ticks: {
            stepSize: 1,
            callback: (v) => {
              const map = { 0: 'N3', 1: 'N2', 2: 'REM', 3: 'N1', 4: 'WAKE' };
              return map[Math.round(v)] || '';
            },
            font: { size: 10, weight: 'bold' }
          },
          grid: { color: '#1f242c' }
        }
      }
    }
  });
}

// ─── Instantiate All Charts ───────────────────────────────────────────────────
// 4 Continuous Vitals Charts
const chartBreath      = createRollingChart('chart-breath', 'Breath BPM', '#38bdf8', 0, 30, 'BPM');
const chartHeartRate   = createRollingChart('chart-hr', 'Heart Rate', '#f85149', 40, 120, 'BPM');
const chartDisturbance = createRollingChart('chart-disturbance', 'Disturbance', '#d29922', 0, 100);
const chartTemperature = createRollingChart('chart-temp', 'Room Temp', '#f97316', 15, 32, '°C');
const chartHypnogram   = createHypnogramChart('hypnogram-chart');

// Dynamic Raw Movement & Energy Waveform Charts
const chartAccelMotion = createMultiLineChart(
  'chart-accel-motion',
  [
    { label: 'Accel X', color: '#06b6d4', fill: false },
    { label: 'Accel Y', color: '#f59e0b', fill: false },
    { label: 'Accel Z', color: '#a855f7', fill: false }
  ],
  -2.0, 2.0, 'g'
);

const chartRadarEnergy = createMultiLineChart(
  'chart-radar-energy',
  [
    { label: 'Moving Energy', color: '#f97316', fill: true },
    { label: 'Thoracic Energy', color: '#10b981', fill: true }
  ],
  0, 100, '%'
);

// ─── Helpers to Append Rolling Points ─────────────────────────────────────────
function appendPoint(chart, label, value) {
  if (!chart) return;
  const data = chart.data;
  data.labels.push(label);
  data.datasets[0].data.push(value);

  if (data.labels.length > MAX_CHART_POINTS) {
    data.labels.shift();
    data.datasets[0].data.shift();
  }
  chart.update();
}

function appendMultiPoint(chart, label, valuesArray) {
  if (!chart) return;
  const data = chart.data;
  data.labels.push(label);
  for (let i = 0; i < valuesArray.length; i++) {
    if (data.datasets[i]) {
      data.datasets[i].data.push(valuesArray[i]);
    }
  }

  if (data.labels.length > MAX_CHART_POINTS) {
    data.labels.shift();
    for (let i = 0; i < data.datasets.length; i++) {
      data.datasets[i].data.shift();
    }
  }
  chart.update();
}

function updateHypnogram(records) {
  if (!chartHypnogram || !records || records.length === 0) return;

  const labels = records.map(r => r.time || '');
  const data = records.map(r => r.numeric);
  const pointColors = records.map(r => {
    const cfg = STAGE_CONFIG[r.stage] || STAGE_CONFIG.WAKE;
    return cfg.color;
  });

  chartHypnogram.data.labels = labels;
  chartHypnogram.data.datasets[0].data = data;
  chartHypnogram.data.datasets[0].pointBackgroundColor = pointColors;
  chartHypnogram.update();
}

// ─── Disturbance Heatmap Track ───────────────────────────────────────────────
function appendHeatmapBar(distVal) {
  const track = document.getElementById('disturbance-heatmap');
  if (!track) return;

  const bar = document.createElement('div');
  bar.className = 'heatmap-bar';

  if (distVal >= 70) {
    bar.classList.add('red');
    bar.title = `Movement (${distVal.toFixed(0)})`;
  } else if (distVal >= 25) {
    bar.classList.add('yellow');
    bar.title = `Restless (${distVal.toFixed(0)})`;
  } else {
    bar.classList.add('green');
    bar.title = `Calm (${distVal.toFixed(0)})`;
  }

  track.appendChild(bar);

  // Keep max bars
  while (track.children.length > MAX_HEATMAP_BARS) {
    track.removeChild(track.firstChild);
  }
}

// ─── Connection Status Handling ──────────────────────────────────────────────
ui.on_connect(() => {
  const dot = document.getElementById('conn-dot');
  const txt = document.getElementById('conn-text');
  if (dot) {
    dot.className = 'status-dot dot-online';
  }
  if (txt) {
    txt.innerText = 'Connected';
  }
  addLogEntry('NETWORK', 'Connected to Arduino Uno Q WebUI Bridge', 'info');
  console.log('[WebUI] Connected to Uno Q');
});

ui.on_disconnect(() => {
  const dot = document.getElementById('conn-dot');
  const txt = document.getElementById('conn-text');
  if (dot) {
    dot.className = 'status-dot dot-offline';
  }
  if (txt) {
    txt.innerText = 'Disconnected';
  }
  addLogEntry('NETWORK', 'Disconnected from Arduino Uno Q backend', 'warning');
  console.log('[WebUI] Disconnected from Uno Q');
});

// ─── Live Animation State ───────────────────────────────────────────────────
let breathPhase = 0;

// ─── Telemetry Dispatcher ────────────────────────────────────────────────────
ui.on_message('telemetry', (data) => {
  if (!data) return;

  const timeLabel = data.clock || new Date().toLocaleTimeString();

  // 1. Clock & Footer
  const clockEl = document.getElementById('live-clock');
  if (clockEl && data.clock) {
    clockEl.innerText = data.clock;
  }
  const footerTs = document.getElementById('footer-update-ts');
  if (footerTs) {
    footerTs.innerText = `Last update: ${timeLabel}`;
  }

  // 2. Vital Cards with Live Animations
  // Breath BPM & Animated Chest Wave
  const valBpm = document.getElementById('val-breath-bpm');
  const valCnt = document.getElementById('val-breath-count');
  const valInt = document.getElementById('val-breath-intensity');
  const breathFill = document.getElementById('breath-pulse-fill');

  const curBpm = (data.breath_bpm && data.breath_bpm > 0) ? data.breath_bpm : 16.0;
  if (valBpm) valBpm.innerText = (data.breath_bpm && data.breath_bpm > 0) ? data.breath_bpm.toFixed(1) : '--';
  if (valCnt) valCnt.innerText = `Count: ${data.breath_count || 0}`;
  if (valInt) valInt.innerText = `Intensity: ${data.breath_intensity ? data.breath_intensity.toFixed(1) : '--'}`;

  if (breathFill) {
    breathPhase += 0.15;
    const breathOsc = 50 + 45 * Math.sin(breathPhase);
    breathFill.style.width = `${Math.max(10, Math.min(100, breathOsc))}%`;
  }

  // Heart Rate & Animated Pulse
  const valHR = document.getElementById('val-heart-rate');
  const valHRStatus = document.getElementById('val-hr-status');
  const heartIcon = document.getElementById('heart-pulse-icon');

  if (valHR) valHR.innerText = (data.heart_rate && data.heart_rate > 0) ? data.heart_rate : '--';
  if (valHRStatus) valHRStatus.innerText = data.hr_valid ? 'MAX30102 Verified' : 'Holding Baseline';

  if (heartIcon && data.heart_rate && data.heart_rate > 30) {
    const period = (60 / data.heart_rate).toFixed(2);
    heartIcon.style.animationDuration = `${period}s`;
  }

  // Blood Oxygen Saturation Progress Bar
  const valSpo2 = document.getElementById('val-spo2');
  const valSpo2Status = document.getElementById('val-spo2-status');
  const spo2Bar = document.getElementById('spo2-bar-fill');

  if (valSpo2) valSpo2.innerText = (data.spo2 && data.spo2 > 0) ? data.spo2 : '--';
  if (valSpo2Status) valSpo2Status.innerText = data.spo2_valid ? 'Pulse Oximeter Valid' : 'Stable Estimate';

  if (spo2Bar && data.spo2 && data.spo2 > 0) {
    const clampedSpo2 = Math.max(0, Math.min(100, data.spo2));
    spo2Bar.style.width = `${clampedSpo2}%`;
    if (clampedSpo2 < 90) {
      spo2Bar.className = 'spo2-bar-fill fill-red';
    } else if (clampedSpo2 < 95) {
      spo2Bar.className = 'spo2-bar-fill fill-yellow';
    } else {
      spo2Bar.className = 'spo2-bar-fill fill-green';
    }
  }

  // Room Temperature & Comfort Needle
  const valTemp = document.getElementById('val-room-temp');
  const valDisturbLevel = document.getElementById('val-disturb-level');
  const tempNeedle = document.getElementById('temp-comfort-needle');

  if (valTemp) valTemp.innerText = (data.temp_c && data.temp_c > -50) ? data.temp_c.toFixed(1) : '--';
  if (valDisturbLevel) {
    const dCol = data.disturbance_colour || 'GREEN';
    const textMap = { GREEN: 'Calm', YELLOW: 'Restless', RED: 'Gross Movement' };
    valDisturbLevel.innerText = `Disturbance: ${textMap[dCol] || dCol}`;
  }

  if (tempNeedle && data.temp_c) {
    // Map 15°C - 30°C to 0% - 100%
    const pct = Math.max(0, Math.min(100, ((data.temp_c - 15) / 15) * 100));
    tempNeedle.style.left = `${pct.toFixed(1)}%`;
  }

  // 3. Raw Hardware Telemetry
  const elRDist = document.getElementById('val-radar-dist');
  const elRMovE = document.getElementById('val-radar-mov-energy');
  const elRStaE = document.getElementById('val-radar-stat-energy');
  const elAccX  = document.getElementById('val-accel-x');
  const elAccY  = document.getElementById('val-accel-y');
  const elAccZ  = document.getElementById('val-accel-z');

  if (elRDist && data.radar_mov_dist !== undefined) elRDist.innerText = data.radar_mov_dist.toFixed(1);
  if (elRMovE && data.radar_mov_energy !== undefined) elRMovE.innerText = data.radar_mov_energy.toFixed(1);
  if (elRStaE && data.radar_stat_energy !== undefined) elRStaE.innerText = data.radar_stat_energy.toFixed(1);
  if (elAccX && data.accel_x !== undefined) elAccX.innerText = data.accel_x.toFixed(3);
  if (elAccY && data.accel_y !== undefined) elAccY.innerText = data.accel_y.toFixed(3);
  if (elAccZ && data.accel_z !== undefined) elAccZ.innerText = data.accel_z.toFixed(3);

  // 4. Update Dynamic Accelerometer Motion & Radar Energy Charts
  if (data.accel_x !== undefined && data.accel_y !== undefined && data.accel_z !== undefined) {
    appendMultiPoint(chartAccelMotion, timeLabel, [data.accel_x, data.accel_y, data.accel_z]);
  }

  if (data.radar_mov_energy !== undefined && data.radar_stat_energy !== undefined) {
    appendMultiPoint(chartRadarEnergy, timeLabel, [data.radar_mov_energy, data.radar_stat_energy]);
  }

  // 5. Sleep Stage Badge & Meta
  const stageBadge = document.getElementById('stage-badge');
  if (stageBadge && data.stage) {
    const stageKey = data.stage.toUpperCase();
    const cfg = STAGE_CONFIG[stageKey] || STAGE_CONFIG.WAKE;
    stageBadge.innerText = cfg.label;
    stageBadge.className = `stage-badge ${cfg.className}`;
  }

  const valCycle = document.getElementById('val-cycle-count');
  const valScore = document.getElementById('val-sleep-score');
  const valSession = document.getElementById('val-session-status');
  if (valCycle) valCycle.innerText = data.cycle_count || 0;
  if (valScore) valScore.innerText = data.sleep_score || '--';
  if (valSession) valSession.innerText = data.session_active ? 'Active' : 'Waiting';

  // Alarm pill
  const alarmPill = document.getElementById('meta-alarm-pill');
  if (alarmPill) {
    if (data.alarm_active) {
      alarmPill.className = 'meta-pill alarm-pill-active';
      alarmPill.innerText = 'ALARM RINGING!';
    } else {
      alarmPill.className = 'meta-pill alarm-pill-off';
      alarmPill.innerText = `Alarm: ${data.alarm_time || '07:00'}`;
    }
  }

  // BLE Wristband Status
  const bleConnected = Boolean(data.ble_connected);
  const bleHeaderPill = document.getElementById('header-ble-pill');
  const bleBadge = document.getElementById('ble-state-badge');
  if (bleHeaderPill) {
    bleHeaderPill.className = bleConnected ? 'header-pill pill-ble-connected' : 'header-pill pill-ble-disconnected';
    bleHeaderPill.innerHTML = bleConnected ? '<span class="pill-dot"></span><span>Wristband: <b>Connected</b></span>' : '<span class="pill-dot"></span><span>Wristband: <b>Searching...</b></span>';
  }
  if (bleBadge) {
    bleBadge.className = bleConnected ? 'badge-pill badge-green' : 'badge-pill badge-yellow';
    bleBadge.innerText = bleConnected ? 'BLE Connected' : 'BLE Scanning...';
  }

  // 6. Update Alarm Banner
  const alarmBanner = document.getElementById('alarm-banner');
  const alarmBannerTime = document.getElementById('alarm-banner-time');
  if (alarmBanner) {
    if (data.alarm_active) {
      alarmBanner.classList.remove('hidden');
      if (alarmBannerTime) alarmBannerTime.innerText = data.alarm_time || '07:00';
    } else {
      alarmBanner.classList.add('hidden');
    }
  }

  // 7. Append to Rolling Vitals Charts
  if (data.breath_bpm !== undefined) appendPoint(chartBreath, timeLabel, data.breath_bpm);
  if (data.heart_rate !== undefined) appendPoint(chartHeartRate, timeLabel, data.heart_rate);
  if (data.disturbance !== undefined) {
    appendPoint(chartDisturbance, timeLabel, data.disturbance);
    appendHeatmapBar(data.disturbance);
  }
  if (data.temp_c !== undefined) appendPoint(chartTemperature, timeLabel, data.temp_c);

  // 8. Update Hypnogram
  if (data.hypnogram && data.hypnogram.length > 0) {
    updateHypnogram(data.hypnogram);
  }
});

// ─── Real-Time Event & Diagnostics Console ────────────────────────────────────
const eventLogHistory = [];

function addLogEntry(tag, msg, level = 'info') {
  const stream = document.getElementById('log-console-stream');
  const countBadge = document.getElementById('log-count-badge');
  const now = new Date();
  const timeStr = now.toLocaleTimeString();

  const record = { time: timeStr, tag, msg, level };
  eventLogHistory.push(record);
  if (eventLogHistory.length > 200) eventLogHistory.shift();

  if (countBadge) {
    countBadge.innerText = `${eventLogHistory.length} events`;
  }

  if (stream) {
    const entry = document.createElement('div');
    entry.className = `log-entry log-entry-${level}`;
    entry.innerHTML = `<span class="log-ts">[${timeStr}]</span> <span class="log-tag tag-${tag.toLowerCase()}">${tag}</span> <span class="log-msg">${msg}</span>`;
    stream.appendChild(entry);
    stream.scrollTop = stream.scrollHeight;
  }
}

function clearEventLogs() {
  eventLogHistory.length = 0;
  const stream = document.getElementById('log-console-stream');
  if (stream) stream.innerHTML = '';
  const countBadge = document.getElementById('log-count-badge');
  if (countBadge) countBadge.innerText = '0 events';
  addLogEntry('SYSTEM', 'Diagnostic event console cleared.', 'info');
}

function exportLogsCSV() {
  if (eventLogHistory.length === 0) {
    alert('No events logged yet!');
    return;
  }
  let csvContent = 'Time,Source_Tag,Message,Level\n';
  eventLogHistory.forEach(r => {
    csvContent += `"${r.time}","${r.tag}","${r.msg.replace(/"/g, '""')}","${r.level}"\n`;
  });

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `slemon_system_log_${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

// ─── User Action Functions ───────────────────────────────────────────────────
function applySettings() {
  const alarmTime = document.getElementById('cfg-alarm-time')?.value || '07:00';
  const alarmWindow = parseInt(document.getElementById('cfg-alarm-window')?.value || '30', 10);
  const baseline = document.getElementById('cfg-baseline')?.value;
  const sleepAudio = document.getElementById('cfg-sleep-audio')?.checked || false;

  const payload = {
    alarm_time: alarmTime,
    alarm_window: alarmWindow,
    baseline: baseline,
    sleep_audio: sleepAudio
  };

  ui.send_message('set_config', payload);
  ui.send_message('set_alarm', { time: alarmTime, enabled: true });

  addLogEntry('CONFIG', `Smart alarm set to ${alarmTime} (Window: ${alarmWindow} min)`, 'info');
  alert('Configuration sent to Slemon!');
}

function testAlarm() {
  ui.send_message('test_alarm', {});
  addLogEntry('ALARM', 'Manual 10-second alarm test initiated from dashboard', 'warning');
}

function dismissAlarm() {
  ui.send_message('dismiss_alarm', {});
  const banner = document.getElementById('alarm-banner');
  if (banner) {
    banner.classList.add('hidden');
  }
  addLogEntry('ALARM', 'Alarm dismissed via dashboard button', 'info');
}

function resetSession() {
  if (confirm('Are you sure you want to reset the sleep monitoring session?')) {
    ui.send_message('reset_session', {});
    const track = document.getElementById('disturbance-heatmap');
    if (track) track.innerHTML = '';
    addLogEntry('SESSION', 'Sleep monitoring session reset to initial state', 'info');
  }
}

// ─── Hardware Assistant & Speaker Controls ───────────────────────────────────
function reconnectBLE() {
  ui.send_message('reconnect_ble', {});
  addLogEntry('PALNO', 'BLE GATT Re-Scan initiated for peripheral "Palno-ESP32"', 'info');
  const bleBadge = document.getElementById('ble-state-badge');
  if (bleBadge) {
    bleBadge.className = 'badge-pill badge-yellow';
    bleBadge.innerText = 'Scanning...';
  }
}

function setAudioMode(mode) {
  const btnUsb = document.getElementById('btn-mode-usb');
  const btnBt = document.getElementById('btn-mode-bt');
  if (mode === 'usb') {
    if (btnUsb) btnUsb.classList.add('active');
    if (btnBt) btnBt.classList.remove('active');
    addLogEntry('AUDIO', 'Audio output mode set to: USB Audio Adapter / DAC (Card 1)', 'info');
  } else {
    if (btnBt) btnBt.classList.add('active');
    if (btnUsb) btnUsb.classList.remove('active');
    addLogEntry('AUDIO', 'Audio output mode set to: Bluetooth A2DP Bedside Speaker', 'info');
  }
}

function updateSpeakerVolume(val) {
  const lbl = document.getElementById('val-speaker-volume');
  if (lbl) lbl.innerText = `${val}%`;
  ui.send_message('set_volume', { volume: Number(val) });
}

function testAudioSweep(key) {
  ui.send_message('test_audio', { key: key });
  const desc = key === 'wake_beta' ? 'Wake Alarm Sweep (10–18 Hz Alpha/Beta crescendo)' : 'Sleep Sweep (2.0 Hz Delta relaxation beat)';
  addLogEntry('AUDIO', `Audio playback started: ${desc}`, 'info');
  const spkBadge = document.getElementById('speaker-state-badge');
  if (spkBadge) {
    spkBadge.className = 'badge-pill badge-red';
    spkBadge.innerText = 'Playing Audio';
  }
}

function stopAudioSweep() {
  ui.send_message('stop_audio', {});
  addLogEntry('AUDIO', 'Audio playback stopped', 'info');
  const spkBadge = document.getElementById('speaker-state-badge');
  if (spkBadge) {
    spkBadge.className = 'badge-pill badge-green';
    spkBadge.innerText = 'Audio Ready';
  }
}
