/*******************************************************************************
 * biometrics.h — MAX30102 HR/SpO2 Integration Wrapper for Palno (ESP32)
 *
 * Wraps the unmodified Maxim algorithm.h/algorithm.cpp and max30102.h/max30102.cpp
 * library files. Implements the sliding-window pattern from BPM_spo2_sensor.ino:
 *   - 100-sample initial fill (4 seconds at 25 sps)
 *   - Shift oldest 25, fill newest 25, recalculate every ~1 second
 *
 * Pin assignments:
 *   INT_PIN = GPIO 4 (MAX30102 interrupt, active-low)
 *   LED_PIN = GPIO 2 (onboard LED toggles with each sample)
 ******************************************************************************/
#ifndef BIOMETRICS_H_
#define BIOMETRICS_H_

#include <Arduino.h>
#include <Wire.h>
#include "algorithm.h"
#include "max30102.h"

// ─── Pin definitions ────────────────────────────────────────────────────────
#define BIO_INT_PIN   4
#define BIO_LED_PIN   2

// ─── Buffers ────────────────────────────────────────────────────────────────
static uint32_t aun_ir_buffer[100];   // infrared LED sensor data
static uint32_t aun_red_buffer[100];  // red LED sensor data
static int32_t  n_ir_buffer_length;   // buffer length (always 100)

// ─── Results ────────────────────────────────────────────────────────────────
static int32_t  bio_spo2            = 98;
static int8_t   bio_spo2_valid      = 0;
static int32_t  bio_heart_rate      = 68;
static int8_t   bio_hr_valid        = 0;
static int32_t  last_clean_spo2     = 98;
static int32_t  last_clean_hr       = 68;

// ─── State ──────────────────────────────────────────────────────────────────
static bool     bio_initialised = false;

// ─── Initialise MAX30102 and fill initial 100-sample buffer ─────────────────
/**
 * Call once from setup() AFTER Wire.begin().
 * Resets the sensor, waits for user readiness, inits, then
 * fills the 100-sample buffer and runs the first HR/SpO2 calculation.
 *
 * NOTE: The original BPM_spo2_sensor.ino waited for a serial keypress.
 *       For Palno we skip that — the sensor starts immediately.
 */
inline void biometrics_init() {
  uint8_t uch_dummy;

  pinMode(BIO_INT_PIN, INPUT);
  pinMode(BIO_LED_PIN, OUTPUT);

  maxim_max30102_reset();
  delay(1000);

  // Clear any pending interrupt
  maxim_max30102_read_reg(REG_INTR_STATUS_1, &uch_dummy);

  // Initialise the sensor registers
  maxim_max30102_init();

  // Fill the first 100 samples (4 seconds @ 25 sps)
  n_ir_buffer_length = 100;
  Serial.println("[BIO] Filling initial 100-sample buffer...");
  for (int32_t i = 0; i < n_ir_buffer_length; i++) {
    while (digitalRead(BIO_INT_PIN) == 1);  // wait for interrupt
    maxim_max30102_read_fifo(&aun_red_buffer[i], &aun_ir_buffer[i]);
  }

  // Run first calculation
  maxim_heart_rate_and_oxygen_saturation(
    aun_ir_buffer, n_ir_buffer_length, aun_red_buffer,
    &bio_spo2, &bio_spo2_valid,
    &bio_heart_rate, &bio_hr_valid
  );

  bio_initialised = true;
  Serial.println("[BIO] Initial HR/SpO2 calculation complete.");
  Serial.print("[BIO] HR="); Serial.print(bio_heart_rate);
  Serial.print(" valid=");   Serial.print(bio_hr_valid);
  Serial.print("  SpO2=");   Serial.print(bio_spo2);
  Serial.print(" valid=");   Serial.println(bio_spo2_valid);
}

// ─── Sliding window update (call repeatedly from loop) ──────────────────────
/**
 * Reads 25 new samples (takes ~1 second at 25 sps), shifts the buffer,
 * then recalculates HR and SpO2.
 *
 * This is a BLOCKING call for ~1 second while it collects 25 samples.
 * Call it from the main loop's biometrics task slot.
 *
 * Returns true when new valid results are available.
 */
inline bool biometrics_update() {
  if (!bio_initialised) return false;

  int32_t i;

  // Shift oldest 25 out, move 75→top
  for (i = 25; i < 100; i++) {
    aun_red_buffer[i - 25] = aun_red_buffer[i];
    aun_ir_buffer[i - 25]  = aun_ir_buffer[i];
  }

  // Read 25 new samples into positions 75–99
  for (i = 75; i < 100; i++) {
    while (digitalRead(BIO_INT_PIN) == 1);  // wait for interrupt
    digitalWrite(BIO_LED_PIN, !digitalRead(BIO_LED_PIN));  // toggle LED
    maxim_max30102_read_fifo(&aun_red_buffer[i], &aun_ir_buffer[i]);
  }

  // Recalculate
  int32_t raw_spo2 = -999;
  int8_t  raw_spo2_v = 0;
  int32_t raw_hr = -999;
  int8_t  raw_hr_v = 0;

  maxim_heart_rate_and_oxygen_saturation(
    aun_ir_buffer, n_ir_buffer_length, aun_red_buffer,
    &raw_spo2, &raw_spo2_v,
    &raw_hr, &raw_hr_v
  );

  // Filter SpO2: only accept clean physiological range [70, 100]
  if (raw_spo2_v && raw_spo2 >= 70 && raw_spo2 <= 100) {
    bio_spo2 = raw_spo2;
    bio_spo2_valid = 1;
    last_clean_spo2 = raw_spo2;
  } else {
    bio_spo2 = last_clean_spo2;
    bio_spo2_valid = 0;
  }

  // Filter Heart Rate: only accept clean resting range [40, 180]
  if (raw_hr_v && raw_hr >= 40 && raw_hr <= 180) {
    bio_heart_rate = raw_hr;
    bio_hr_valid = 1;
    last_clean_hr = raw_hr;
  } else {
    bio_heart_rate = last_clean_hr;
    bio_hr_valid = 0;
  }

  return true;
}

// ─── Getters ────────────────────────────────────────────────────────────────
inline int32_t biometrics_get_hr()         { return bio_heart_rate; }
inline int8_t  biometrics_get_hr_valid()   { return bio_hr_valid;   }
inline int32_t biometrics_get_spo2()       { return bio_spo2;       }
inline int8_t  biometrics_get_spo2_valid() { return bio_spo2_valid; }

#endif /* BIOMETRICS_H_ */
