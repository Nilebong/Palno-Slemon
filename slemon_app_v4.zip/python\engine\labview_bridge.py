"""
labview_bridge.py — TCP Socket Server for NI LabVIEW Integration
Palno & Slemon Sleep Tracking System

Listens on TCP port 5005 (0.0.0.0:5005).
Broadcasts newline-delimited JSON telemetry to connected LabVIEW TCP clients:
  - Radar raw data points: radar_mov_dist, radar_mov_energy, radar_stat_energy
  - Accelerometer raw motion: accel_x, accel_y, accel_z
  - Vitals & stage: breath_bpm, heart_rate, spo2, stage, temp_c, sleep_score
"""

import socket
import threading
import json
import logging
import time
from typing import List

logger = logging.getLogger("LabVIEWBridge")

LABVIEW_HOST = "0.0.0.0"
LABVIEW_PORT = 5005

class LabVIEWBridge:
    def __init__(self, host: str = LABVIEW_HOST, port: int = LABVIEW_PORT):
        self.host = host
        self.port = port
        self.server_sock = None
        self.clients: List[socket.socket] = []
        self._lock = threading.Lock()
        self._running = False
        self._thread = None

    def start(self):
        """Start the background TCP server thread."""
        self._running = True
        self._thread = threading.Thread(target=self._run_server, daemon=True)
        self._thread.start()
        logger.info("[LabVIEW] TCP Bridge server starting on %s:%d", self.host, self.port)

    def _run_server(self):
        try:
            self.server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_sock.bind((self.host, self.port))
            self.server_sock.listen(5)
            self.server_sock.settimeout(1.0)
            logger.info("[LabVIEW] TCP Server listening on %s:%d", self.host, self.port)
        except Exception as e:
            logger.error("[LabVIEW] Failed to bind TCP server on %d: %s", self.port, e)
            return

        while self._running:
            try:
                client_sock, addr = self.server_sock.accept()
                with self._lock:
                    self.clients.append(client_sock)
                logger.info("[LabVIEW] Client connected from %s (total clients: %d)", addr, len(self.clients))
            except socket.timeout:
                continue
            except Exception as e:
                if self._running:
                    logger.debug("[LabVIEW] Accept error: %s", e)
                break

    def broadcast(self, data: dict):
        """Send a newline-delimited JSON payload to all connected LabVIEW instances."""
        if not self.clients:
            return

        try:
            # Clean single-line JSON with CRLF for robust LabVIEW TCP Unflatten compatibility
            payload = (json.dumps(data, ensure_ascii=True, allow_nan=False) + "\r\n").encode("utf-8")
        except Exception as e:
            logger.warning("[LabVIEW] JSON serialize error: %s", e)
            return

        dead_clients = []
        with self._lock:
            for client in self.clients:
                try:
                    client.sendall(payload)
                except Exception:
                    dead_clients.append(client)

            for dead in dead_clients:
                try:
                    dead.close()
                except Exception:
                    pass
                if dead in self.clients:
                    self.clients.remove(dead)

    def stop(self):
        self._running = False
        with self._lock:
            for c in self.clients:
                try:
                    c.close()
                except Exception:
                    pass
            self.clients.clear()
        if self.server_sock:
            try:
                self.server_sock.close()
            except Exception:
                pass
        logger.info("[LabVIEW] TCP Bridge server stopped")
